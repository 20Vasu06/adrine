import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { User as SupabaseUser, Session } from '@supabase/supabase-js';

// Frontend role type mapped from DB app_role
export type UserRole =
  | 'admin'
  | 'doctor'
  | 'nurse'
  | 'receptionist'
  | 'lab_technician'
  | 'pharmacist'
  | 'billing'
  | 'radiologist'
  | 'ot_coordinator'
  | 'inventory_manager'
  | 'emergency'
  | 'hr_manager'
  | 'scheduler'
  | 'dialysis_tech';

// Map DB roles to frontend roles
const DB_TO_FRONTEND_ROLE: Record<string, UserRole> = {
  super_admin: 'admin',
  org_admin: 'admin',
  doctor: 'doctor',
  nurse: 'nurse',
  receptionist: 'receptionist',
  lab_tech: 'lab_technician',
  pharmacist: 'pharmacist',
  billing_staff: 'billing',
  radiologist: 'radiologist',
  ot_coordinator: 'ot_coordinator',
  inventory_manager: 'inventory_manager',
  emergency_staff: 'emergency',
  hr_manager: 'hr_manager',
  scheduler: 'scheduler',
  dialysis_tech: 'dialysis_tech',
};

export interface AppUser {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  orgId: string;
  orgName?: string;
  branchId?: string;
  avatar?: string;
  department?: string;
}

interface AuthContextType {
  user: AppUser | null;
  session: Session | null;
  loading: boolean;
  availableRoles: UserRole[];
  activeRole: UserRole | null;
  enabledModules: string[];
  setActiveRole: (role: UserRole) => void;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  signup: (data: SignupData) => Promise<{ error?: string }>;
  logout: () => Promise<void>;
  canAccess: (module: string) => boolean;
}

interface SignupData {
  orgName: string;
  orgSlug: string;
  orgType: string;
  fullName: string;
  email: string;
  password: string;
  modules: string[];
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [availableRoles, setAvailableRoles] = useState<UserRole[]>([]);
  const [activeRole, setActiveRoleState] = useState<UserRole | null>(null);
  const [enabledModules, setEnabledModules] = useState<string[]>([]);

  // Load user profile + role from DB
  const loadUserProfile = useCallback(async (supaUser: SupabaseUser) => {
    try {
      // Get profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', supaUser.id)
        .single();

      if (!profile) {
        setUser(null);
        return;
      }

      // Get all roles for this user in this org
      const { data: roles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', supaUser.id)
        .eq('org_id', profile.org_id);

      // Get org name
      const { data: org } = await supabase
        .from('organizations')
        .select('name')
        .eq('id', profile.org_id)
        .single();

      // Get enabled modules for the org
      const { data: modules } = await supabase
        .from('org_modules')
        .select('module')
        .eq('org_id', profile.org_id)
        .eq('is_enabled', true);

      setEnabledModules((modules || []).map(m => m.module));

      const allFrontendRoles: UserRole[] = (roles || [])
        .map(r => DB_TO_FRONTEND_ROLE[r.role])
        .filter(Boolean) as UserRole[];

      if (allFrontendRoles.length === 0) allFrontendRoles.push('admin');

      setAvailableRoles(allFrontendRoles);

      // Use activeRole if already set, otherwise don't auto-pick (let role selection page handle it)
      const selectedRole = activeRole && allFrontendRoles.includes(activeRole)
        ? activeRole
        : allFrontendRoles[0];

      setUser({
        id: supaUser.id,
        name: profile.full_name,
        role: selectedRole,
        email: profile.email || supaUser.email || '',
        orgId: profile.org_id,
        orgName: org?.name,
        branchId: profile.branch_id || undefined,
        avatar: profile.avatar_url || undefined,
        department: profile.department || undefined,
      });
    } catch (err) {
      console.error('Error loading user profile:', err);
      setUser(null);
    }
  }, []);

  // Set up auth listener BEFORE getSession
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, newSession) => {
        setSession(newSession);
        if (newSession?.user) {
          // Use setTimeout to avoid deadlock with Supabase client
          setTimeout(() => loadUserProfile(newSession.user), 0);
        } else {
          setUser(null);
        }
        if (event === 'SIGNED_OUT') {
          setUser(null);
        }
      }
    );

    // Then check existing session
    supabase.auth.getSession().then(({ data: { session: existingSession } }) => {
      setSession(existingSession);
      if (existingSession?.user) {
        loadUserProfile(existingSession.user).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, [loadUserProfile]);

  const login = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };
    return {};
  }, []);

  const signup = useCallback(async (data: SignupData) => {
    try {
      const res = await supabase.functions.invoke('onboard-organization', {
        body: data,
      });

      if (res.error) {
        return { error: res.error.message };
      }

      if (res.data?.error) {
        return { error: res.data.error };
      }

      // Auto-login after signup
      const { error: loginError } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      });

      if (loginError) return { error: loginError.message };
      return {};
    } catch (err: any) {
      return { error: err.message || 'Signup failed' };
    }
  }, []);

  const setActiveRole = useCallback((role: UserRole) => {
    setActiveRoleState(role);
    if (user) {
      setUser({ ...user, role });
    }
  }, [user]);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setAvailableRoles([]);
    setActiveRoleState(null);
    setEnabledModules([]);
  }, []);

  const canAccess = useCallback((_module: string) => {
    return !!user;
  }, [user]);

  return (
    <AuthContext.Provider value={{ user, session, loading, availableRoles, activeRole, enabledModules, setActiveRole, login, signup, logout, canAccess }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
