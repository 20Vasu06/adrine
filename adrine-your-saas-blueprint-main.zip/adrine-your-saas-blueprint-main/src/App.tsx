import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth, UserRole } from "@/contexts/AuthContext";
import { HospitalProvider } from "@/stores/hospitalStore";
import LoginPage from "@/pages/LoginPage";
import DashboardPage from "@/pages/DashboardPage";
import AppLayout from "@/components/AppLayout";
import RolePlaceholder from "@/components/RolePlaceholder";
import RoleGuard from "@/components/RoleGuard";
import { ROLE_TABS, ROLE_BASE_PATH } from "@/config/roleNavigation";
import NotFound from "./pages/NotFound";
import RoleSelectionPage from "@/pages/RoleSelectionPage";

// Doctor pages
import DoctorDashboard from "@/pages/doctor/DoctorDashboard";
import DoctorPatients from "@/pages/doctor/DoctorPatients";
import DoctorQueue from "@/pages/doctor/DoctorQueue";
import DoctorSchedule from "@/pages/doctor/DoctorSchedule";
import DoctorLabs from "@/pages/doctor/DoctorLabs";
import DoctorIPD from "@/pages/doctor/DoctorIPD";
import DoctorAnalytics from "@/pages/doctor/DoctorAnalytics";
import DoctorPatientProfile from "@/pages/doctor/DoctorPatientProfile";
import DoctorIPDPatientProfile from "@/pages/doctor/DoctorIPDPatientProfile";
import DoctorConsultation from "@/pages/doctor/DoctorConsultation";
import DoctorRadiology from "@/pages/doctor/DoctorRadiology";

// Nurse pages
import NurseDashboard from "@/pages/nurse/NurseDashboard";
import NurseWard from "@/pages/nurse/NurseWard";
import NurseAdmissions from "@/pages/nurse/NurseAdmissions";
import NurseTasks from "@/pages/nurse/NurseTasks";
import NurseMedications from "@/pages/nurse/NurseMedications";
import NurseVitals from "@/pages/nurse/NurseVitals";
import NurseDischarge from "@/pages/nurse/NurseDischarge";
import NurseReports from "@/pages/nurse/NurseReports";

// Reception pages
import ReceptionDashboard from "@/pages/reception/ReceptionDashboard";
import ReceptionRegistration from "@/pages/reception/ReceptionRegistration";
import ReceptionAppointments from "@/pages/reception/ReceptionAppointments";
import ReceptionCheckIn from "@/pages/reception/ReceptionCheckIn";
import ReceptionQueue from "@/pages/reception/ReceptionQueue";
import ReceptionBilling from "@/pages/reception/ReceptionBilling";
import ReceptionBeds from "@/pages/reception/ReceptionBeds";
import ReceptionIPD from "@/pages/reception/ReceptionIPD";

// Lab pages
import LabDashboard from "@/pages/lab/LabDashboard";
import LabWorklist from "@/pages/lab/LabWorklist";
import LabSamples from "@/pages/lab/LabSamples";
import LabEntry from "@/pages/lab/LabEntry";
import LabVerification from "@/pages/lab/LabVerification";
import LabReports from "@/pages/lab/LabReports";

// Pharmacy pages
import PharmacyDashboard from "@/pages/pharmacy/PharmacyDashboard";
import PharmacyPrescriptions from "@/pages/pharmacy/PharmacyPrescriptions";
import PharmacyInventory from "@/pages/pharmacy/PharmacyInventory";
import PharmacyDrugs from "@/pages/pharmacy/PharmacyDrugs";
import PharmacyBilling from "@/pages/pharmacy/PharmacyBilling";
import PharmacySuppliers from "@/pages/pharmacy/PharmacySuppliers";
import PharmacyPurchase from "@/pages/pharmacy/PharmacyPurchase";
import PharmacyQueries from "@/pages/pharmacy/PharmacyQueries";
import PharmacyScheduleH from "@/pages/pharmacy/PharmacyScheduleH";

// Radiology pages
import RadiologyDashboard from "@/pages/radiology/RadiologyDashboard";
import RadiologyOrders from "@/pages/radiology/RadiologyOrders";
import RadiologyWorklist from "@/pages/radiology/RadiologyWorklist";
import RadiologyReports from "@/pages/radiology/RadiologyReports";
import RadiologySettings from "@/pages/radiology/RadiologySettings";

// Admin pages
import AdminDashboard from "@/pages/admin/AdminDashboard";
import AdminStaff from "@/pages/admin/AdminStaff";
import AdminDepartments from "@/pages/admin/AdminDepartments";
import AdminFinance from "@/pages/admin/AdminFinance";
import AdminExpenses from "@/pages/admin/AdminExpenses";
import AdminApprovals from "@/pages/admin/AdminApprovals";
import AdminClaims from "@/pages/admin/AdminClaims";
import AdminMRD from "@/pages/admin/AdminMRD";
import AdminMIS from "@/pages/admin/AdminMIS";
import AdminAudit from "@/pages/admin/AdminAudit";
import AdminSettings from "@/pages/admin/AdminSettings";
import AdminGeoIntelligence from "@/pages/admin/AdminGeoIntelligence";
import AdminDoctorSharing from "@/pages/admin/AdminDoctorSharing";
import AdminPhonebook from "@/pages/admin/AdminPhonebook";
import AdminMortalityAnalytics from "@/pages/admin/AdminMortalityAnalytics";
import AdminAIWorkflow from "@/pages/admin/AdminAIWorkflow";
import AdminDiseaseMapping from "@/pages/admin/AdminDiseaseMapping";
import AdminDataMining from "@/pages/admin/AdminDataMining";
import AdminCommandCenter from "@/pages/admin/AdminCommandCenter";
import AdminKaizen from "@/pages/admin/AdminKaizen";
import AdminRevenueCycle from "@/pages/admin/AdminRevenueCycle";
import AdminTreatmentSuccess from "@/pages/admin/AdminTreatmentSuccess";

// Billing pages
import BillingDashboard from "@/pages/billing/BillingDashboard";
import BillingInvoices from "@/pages/billing/BillingInvoices";
import BillingPayments from "@/pages/billing/BillingPayments";
import BillingIPD from "@/pages/billing/BillingIPD";
import BillingPackages from "@/pages/billing/BillingPackages";
import BillingRevenue from "@/pages/billing/BillingRevenue";
import BillingInsurance from "@/pages/billing/BillingInsurance";
import BillingFinance from "@/pages/billing/BillingFinance";
import BillingReports from "@/pages/billing/BillingReports";
import BillingHealthPlans from "@/pages/billing/BillingHealthPlans";
import BillingGST from "@/pages/billing/BillingGST";
import BillingTPACharges from "@/pages/billing/BillingTPACharges";

// OT pages
import OTDashboard from "@/pages/ot/OTDashboard";
import OTSchedule from "@/pages/ot/OTSchedule";
import OTRooms from "@/pages/ot/OTRooms";
import OTTeams from "@/pages/ot/OTTeams";
import OTPreOp from "@/pages/ot/OTPreOp";
import OTIntraOp from "@/pages/ot/OTIntraOp";
import OTPostOp from "@/pages/ot/OTPostOp";
import OTInventory from "@/pages/ot/OTInventory";
import OTReports from "@/pages/ot/OTReports";
import OTAnalytics from "@/pages/ot/OTAnalytics";

// Inventory pages
import InventoryDashboard from "@/pages/inventory/InventoryDashboard";
import InventoryCatalog from "@/pages/inventory/InventoryCatalog";
import InventoryStockEntry from "@/pages/inventory/InventoryStockEntry";
import InventoryDistribution from "@/pages/inventory/InventoryDistribution";
import InventoryRequisitions from "@/pages/inventory/InventoryRequisitions";
import InventoryPurchaseOrders from "@/pages/inventory/InventoryPurchaseOrders";
import InventoryAdjustments from "@/pages/inventory/InventoryAdjustments";
import InventoryEquipment from "@/pages/inventory/InventoryEquipment";
import InventoryReports from "@/pages/inventory/InventoryReports";

// Emergency pages
import EmergencyDashboard from "@/pages/emergency/EmergencyDashboard";
import EmergencyTriage from "@/pages/emergency/EmergencyTriage";
import EmergencyCases from "@/pages/emergency/EmergencyCases";
import EmergencyTreatment from "@/pages/emergency/EmergencyTreatment";
import EmergencyOrders from "@/pages/emergency/EmergencyOrders";
import EmergencyObservation from "@/pages/emergency/EmergencyObservation";
import EmergencyMLC from "@/pages/emergency/EmergencyMLC";
import EmergencyAmbulance from "@/pages/emergency/EmergencyAmbulance";
import EmergencyReports from "@/pages/emergency/EmergencyReports";

// HR pages
import HRDashboard from "@/pages/hr/HRDashboard";
import HRStaff from "@/pages/hr/HRStaff";
import HRScheduling from "@/pages/hr/HRScheduling";
import HRAttendance from "@/pages/hr/HRAttendance";
import HRLeave from "@/pages/hr/HRLeave";
import HRCredentials from "@/pages/hr/HRCredentials";
import HRTraining from "@/pages/hr/HRTraining";
import HRPerformance from "@/pages/hr/HRPerformance";
import HRReports from "@/pages/hr/HRReports";

// Scheduling pages
import SchedulingDashboard from "@/pages/scheduling/SchedulingDashboard";
import SchedulingBook from "@/pages/scheduling/SchedulingBook";
import SchedulingCalendar from "@/pages/scheduling/SchedulingCalendar";
import SchedulingDoctors from "@/pages/scheduling/SchedulingDoctors";
import SchedulingResources from "@/pages/scheduling/SchedulingResources";
import SchedulingWaitlist from "@/pages/scheduling/SchedulingWaitlist";
import SchedulingTeleconsult from "@/pages/scheduling/SchedulingTeleconsult";
import SchedulingReports from "@/pages/scheduling/SchedulingReports";

// Dialysis pages
import DialysisDashboard from "@/pages/dialysis/DialysisDashboard";
import DialysisPatients from "@/pages/dialysis/DialysisPatients";
import DialysisSchedule from "@/pages/dialysis/DialysisSchedule";
import DialysisSession from "@/pages/dialysis/DialysisSession";
import DialysisMachines from "@/pages/dialysis/DialysisMachines";
import DialysisConsumables from "@/pages/dialysis/DialysisConsumables";
import DialysisBilling from "@/pages/dialysis/DialysisBilling";
import DialysisReports from "@/pages/dialysis/DialysisReports";

const queryClient = new QueryClient();

const ADMIN_PAGES: Record<string, React.ComponentType> = {
  '/admin': AdminDashboard,
  '/admin/command-center': AdminCommandCenter,
  '/admin/mortality': AdminMortalityAnalytics,
  '/admin/ai-workflow': AdminAIWorkflow,
  '/admin/disease-mapping': AdminDiseaseMapping,
  '/admin/data-mining': AdminDataMining,
  '/admin/kaizen': AdminKaizen,
  '/admin/revenue-cycle': AdminRevenueCycle,
  '/admin/treatment-success': AdminTreatmentSuccess,
  '/admin/staff': AdminStaff,
  '/admin/departments': AdminDepartments,
  '/admin/finance': AdminFinance,
  '/admin/expenses': AdminExpenses,
  '/admin/approvals': AdminApprovals,
  '/admin/claims': AdminClaims,
  '/admin/mrd': AdminMRD,
  '/admin/mis': AdminMIS,
  '/admin/audit': AdminAudit,
  '/admin/settings': AdminSettings,
  '/admin/doctor-sharing': AdminDoctorSharing,
  '/admin/phonebook': AdminPhonebook,
};

const DOCTOR_PAGES: Record<string, React.ComponentType> = {
  '/doctor': DoctorDashboard,
  '/doctor/patients': DoctorPatients,
  '/doctor/queue': DoctorQueue,
  '/doctor/schedule': DoctorSchedule,
  '/doctor/labs': DoctorLabs,
  '/doctor/radiology': DoctorRadiology,
  '/doctor/ipd': DoctorIPD,
  '/doctor/analytics': DoctorAnalytics,
};

const NURSE_PAGES: Record<string, React.ComponentType> = {
  '/nurse': NurseDashboard,
  '/nurse/ward': NurseWard,
  '/nurse/admissions': NurseAdmissions,
  '/nurse/tasks': NurseTasks,
  '/nurse/medications': NurseMedications,
  '/nurse/vitals': NurseVitals,
  '/nurse/discharge': NurseDischarge,
  '/nurse/reports': NurseReports,
};

const RECEPTION_PAGES: Record<string, React.ComponentType> = {
  '/reception': ReceptionDashboard,
  '/reception/registration': ReceptionRegistration,
  '/reception/appointments': ReceptionAppointments,
  '/reception/checkin': ReceptionCheckIn,
  '/reception/queue': ReceptionQueue,
  '/reception/billing': ReceptionBilling,
  '/reception/beds': ReceptionBeds,
  '/reception/ipd': ReceptionIPD,
};

const LAB_PAGES: Record<string, React.ComponentType> = {
  '/lab': LabDashboard,
  '/lab/worklist': LabWorklist,
  '/lab/samples': LabSamples,
  '/lab/entry': LabEntry,
  '/lab/verification': LabVerification,
  '/lab/reports': LabReports,
};

const PHARMACY_PAGES: Record<string, React.ComponentType> = {
  '/pharmacy': PharmacyDashboard,
  '/pharmacy/prescriptions': PharmacyPrescriptions,
  '/pharmacy/inventory': PharmacyInventory,
  '/pharmacy/drugs': PharmacyDrugs,
  '/pharmacy/billing': PharmacyBilling,
  '/pharmacy/suppliers': PharmacySuppliers,
  '/pharmacy/purchase': PharmacyPurchase,
  '/pharmacy/queries': PharmacyQueries,
  '/pharmacy/schedule-h': PharmacyScheduleH,
};

const RADIOLOGY_PAGES: Record<string, React.ComponentType> = {
  '/radiology': RadiologyDashboard,
  '/radiology/orders': RadiologyOrders,
  '/radiology/worklist': RadiologyWorklist,
  '/radiology/reports': RadiologyReports,
  '/radiology/settings': RadiologySettings,
};

const BILLING_PAGES: Record<string, React.ComponentType> = {
  '/billing-dept': BillingDashboard,
  '/billing-dept/invoices': BillingInvoices,
  '/billing-dept/payments': BillingPayments,
  '/billing-dept/ipd-billing': BillingIPD,
  '/billing-dept/packages': BillingPackages,
  '/billing-dept/revenue': BillingRevenue,
  '/billing-dept/insurance': BillingInsurance,
  '/billing-dept/finance': BillingFinance,
  '/billing-dept/reports': BillingReports,
  '/billing-dept/health-plans': BillingHealthPlans,
  '/billing-dept/gst': BillingGST,
  '/billing-dept/tpa-charges': BillingTPACharges,
};

const OT_PAGES: Record<string, React.ComponentType> = {
  '/ot': OTDashboard,
  '/ot/schedule': OTSchedule,
  '/ot/rooms': OTRooms,
  '/ot/teams': OTTeams,
  '/ot/preop': OTPreOp,
  '/ot/intraop': OTIntraOp,
  '/ot/postop': OTPostOp,
  '/ot/inventory': OTInventory,
  '/ot/reports': OTReports,
  '/ot/analytics': OTAnalytics,
};

const INVENTORY_PAGES: Record<string, React.ComponentType> = {
  '/inventory': InventoryDashboard,
  '/inventory/catalog': InventoryCatalog,
  '/inventory/stock-entry': InventoryStockEntry,
  '/inventory/distribution': InventoryDistribution,
  '/inventory/requisitions': InventoryRequisitions,
  '/inventory/procurement': InventoryPurchaseOrders,
  '/inventory/adjustments': InventoryAdjustments,
  '/inventory/equipment': InventoryEquipment,
  '/inventory/reports': InventoryReports,
};

const EMERGENCY_PAGES: Record<string, React.ComponentType> = {
  '/emergency': EmergencyDashboard,
  '/emergency/triage': EmergencyTriage,
  '/emergency/cases': EmergencyCases,
  '/emergency/treatment': EmergencyTreatment,
  '/emergency/orders': EmergencyOrders,
  '/emergency/observation': EmergencyObservation,
  '/emergency/mlc': EmergencyMLC,
  '/emergency/ambulance': EmergencyAmbulance,
  '/emergency/reports': EmergencyReports,
};

const HR_PAGES: Record<string, React.ComponentType> = {
  '/hr': HRDashboard,
  '/hr/staff': HRStaff,
  '/hr/scheduling': HRScheduling,
  '/hr/attendance': HRAttendance,
  '/hr/leave': HRLeave,
  '/hr/credentials': HRCredentials,
  '/hr/training': HRTraining,
  '/hr/performance': HRPerformance,
  '/hr/reports': HRReports,
};

const SCHEDULING_PAGES: Record<string, React.ComponentType> = {
  '/scheduling': SchedulingDashboard,
  '/scheduling/book': SchedulingBook,
  '/scheduling/calendar': SchedulingCalendar,
  '/scheduling/doctors': SchedulingDoctors,
  '/scheduling/resources': SchedulingResources,
  '/scheduling/waitlist': SchedulingWaitlist,
  '/scheduling/teleconsult': SchedulingTeleconsult,
  '/scheduling/reports': SchedulingReports,
};

const DIALYSIS_PAGES: Record<string, React.ComponentType> = {
  '/dialysis': DialysisDashboard,
  '/dialysis/patients': DialysisPatients,
  '/dialysis/schedule': DialysisSchedule,
  '/dialysis/session': DialysisSession,
  '/dialysis/machines': DialysisMachines,
  '/dialysis/consumables': DialysisConsumables,
  '/dialysis/billing': DialysisBilling,
  '/dialysis/reports': DialysisReports,
};

function AppRoutes() {
  const { user, loading, activeRole } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold tracking-tight mb-2">ADRINE</h1>
          <p className="text-sm text-muted-foreground animate-pulse">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    );
  }

  const basePath = ROLE_BASE_PATH[user.role];
  const tabs = ROLE_TABS[user.role];

  // If no active role selected yet, force role selection for all routes
  if (!activeRole) {
    return (
      <Routes>
        <Route path="/select-role" element={<RoleSelectionPage />} />
        <Route path="*" element={<Navigate to="/select-role" replace />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<Navigate to={basePath} replace />} />
      <Route path="/select-role" element={<RoleSelectionPage />} />

      {/* Admin routes */}
      {Object.entries(ADMIN_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['admin']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}
      <Route path="/admin/geo-intelligence" element={<RoleGuard allowedRoles={['admin']}><AppLayout><AdminGeoIntelligence /></AppLayout></RoleGuard>} />

      {/* Doctor routes */}
      {Object.entries(DOCTOR_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['doctor']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}
      <Route path="/doctor/patients/:patientId" element={<RoleGuard allowedRoles={['doctor']}><AppLayout><DoctorPatientProfile /></AppLayout></RoleGuard>} />
      <Route path="/doctor/ipd/:patientId" element={<RoleGuard allowedRoles={['doctor']}><AppLayout><DoctorIPDPatientProfile /></AppLayout></RoleGuard>} />
      <Route path="/doctor/consultation/:patientId" element={<RoleGuard allowedRoles={['doctor']}><AppLayout><DoctorConsultation /></AppLayout></RoleGuard>} />

      {/* Nurse routes */}
      {Object.entries(NURSE_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['nurse']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Reception routes */}
      {Object.entries(RECEPTION_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['receptionist']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Lab routes */}
      {Object.entries(LAB_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['lab_technician']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Pharmacy routes */}
      {Object.entries(PHARMACY_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['pharmacist']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Radiology routes */}
      {Object.entries(RADIOLOGY_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['radiologist']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Billing routes */}
      {Object.entries(BILLING_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['billing']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* OT routes */}
      {Object.entries(OT_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['ot_coordinator']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Inventory routes */}
      {Object.entries(INVENTORY_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['inventory_manager']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Emergency routes */}
      {Object.entries(EMERGENCY_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['emergency']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* HR routes */}
      {Object.entries(HR_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['hr_manager']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Scheduling routes */}
      {Object.entries(SCHEDULING_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['scheduler']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Dialysis routes */}
      {Object.entries(DIALYSIS_PAGES).map(([path, Component]) => (
        <Route key={path} path={path} element={
          <RoleGuard allowedRoles={['dialysis_tech']}><AppLayout><Component /></AppLayout></RoleGuard>
        } />
      ))}

      {/* Dashboard route for other roles */}
      {user.role !== 'doctor' && user.role !== 'receptionist' && user.role !== 'nurse' && user.role !== 'lab_technician' && user.role !== 'pharmacist' && user.role !== 'radiologist' && user.role !== 'billing' && user.role !== 'admin' && user.role !== 'ot_coordinator' && user.role !== 'inventory_manager' && user.role !== 'emergency' && user.role !== 'hr_manager' && user.role !== 'scheduler' && user.role !== 'dialysis_tech' && (
        <Route path={basePath} element={
          <AppLayout><DashboardPage /></AppLayout>
        } />
      )}

      {/* All other role tabs as placeholders */}
      {tabs
        .filter(t => t.key !== 'dashboard')
        .filter(t => !ADMIN_PAGES[t.path] && !DOCTOR_PAGES[t.path] && !RECEPTION_PAGES[t.path] && !NURSE_PAGES[t.path] && !LAB_PAGES[t.path] && !PHARMACY_PAGES[t.path] && !RADIOLOGY_PAGES[t.path] && !BILLING_PAGES[t.path] && !OT_PAGES[t.path] && !INVENTORY_PAGES[t.path] && !EMERGENCY_PAGES[t.path] && !HR_PAGES[t.path] && !SCHEDULING_PAGES[t.path] && !DIALYSIS_PAGES[t.path])
        .map(tab => (
          <Route key={tab.key} path={tab.path} element={
            <AppLayout>
              <RolePlaceholder title={tab.label} />
            </AppLayout>
          } />
        ))}

      {/* Legacy routes */}
      <Route path="/dashboard" element={<Navigate to={basePath} replace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <HospitalProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <AppRoutes />
            </BrowserRouter>
          </HospitalProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
