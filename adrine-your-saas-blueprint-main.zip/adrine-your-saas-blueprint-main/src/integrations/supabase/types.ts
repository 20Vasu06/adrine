export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      admissions: {
        Row: {
          admission_date: string
          admission_no: string
          bed_id: string | null
          branch_id: string | null
          created_at: string
          department: string
          diagnosis: string | null
          discharge_date: string | null
          doctor: string
          id: string
          org_id: string
          patient_id: string
          patient_name: string
          status: string
          updated_at: string
        }
        Insert: {
          admission_date?: string
          admission_no: string
          bed_id?: string | null
          branch_id?: string | null
          created_at?: string
          department: string
          diagnosis?: string | null
          discharge_date?: string | null
          doctor: string
          id?: string
          org_id: string
          patient_id: string
          patient_name: string
          status?: string
          updated_at?: string
        }
        Update: {
          admission_date?: string
          admission_no?: string
          bed_id?: string | null
          branch_id?: string | null
          created_at?: string
          department?: string
          diagnosis?: string | null
          discharge_date?: string | null
          doctor?: string
          id?: string
          org_id?: string
          patient_id?: string
          patient_name?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "admissions_bed_id_fkey"
            columns: ["bed_id"]
            isOneToOne: false
            referencedRelation: "beds"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admissions_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admissions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admissions_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      appointments: {
        Row: {
          appointment_no: string
          branch_id: string | null
          created_at: string
          date: string
          department: string
          doctor: string
          duration: number | null
          id: string
          notes: string | null
          org_id: string
          patient_id: string
          patient_name: string
          phone: string | null
          status: Database["public"]["Enums"]["appointment_status"]
          time: string
          type: Database["public"]["Enums"]["appointment_type"]
          updated_at: string
        }
        Insert: {
          appointment_no: string
          branch_id?: string | null
          created_at?: string
          date: string
          department: string
          doctor: string
          duration?: number | null
          id?: string
          notes?: string | null
          org_id: string
          patient_id: string
          patient_name: string
          phone?: string | null
          status?: Database["public"]["Enums"]["appointment_status"]
          time: string
          type?: Database["public"]["Enums"]["appointment_type"]
          updated_at?: string
        }
        Update: {
          appointment_no?: string
          branch_id?: string | null
          created_at?: string
          date?: string
          department?: string
          doctor?: string
          duration?: number | null
          id?: string
          notes?: string | null
          org_id?: string
          patient_id?: string
          patient_name?: string
          phone?: string | null
          status?: Database["public"]["Enums"]["appointment_status"]
          time?: string
          type?: Database["public"]["Enums"]["appointment_type"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointments_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      beds: {
        Row: {
          bed_no: string
          bed_type: string
          branch_id: string | null
          created_at: string
          id: string
          is_occupied: boolean
          org_id: string
          patient_id: string | null
          updated_at: string
          ward: string
        }
        Insert: {
          bed_no: string
          bed_type?: string
          branch_id?: string | null
          created_at?: string
          id?: string
          is_occupied?: boolean
          org_id: string
          patient_id?: string | null
          updated_at?: string
          ward: string
        }
        Update: {
          bed_no?: string
          bed_type?: string
          branch_id?: string | null
          created_at?: string
          id?: string
          is_occupied?: boolean
          org_id?: string
          patient_id?: string | null
          updated_at?: string
          ward?: string
        }
        Relationships: [
          {
            foreignKeyName: "beds_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "beds_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "beds_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      branches: {
        Row: {
          address: string | null
          city: string | null
          code: string
          created_at: string
          id: string
          is_active: boolean
          name: string
          org_id: string
          phone: string | null
          pincode: string | null
          state: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          city?: string | null
          code: string
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          org_id: string
          phone?: string | null
          pincode?: string | null
          state?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          city?: string | null
          code?: string
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          org_id?: string
          phone?: string | null
          pincode?: string | null
          state?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "branches_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      consultations: {
        Row: {
          branch_id: string | null
          complaints: string | null
          consultation_fee: number | null
          created_at: string
          date: string
          department: string
          diagnosis: string | null
          doctor: string
          examination: string | null
          id: string
          notes: string | null
          org_id: string
          patient_id: string
          patient_name: string
          updated_at: string
          vitals: Json | null
        }
        Insert: {
          branch_id?: string | null
          complaints?: string | null
          consultation_fee?: number | null
          created_at?: string
          date?: string
          department: string
          diagnosis?: string | null
          doctor: string
          examination?: string | null
          id?: string
          notes?: string | null
          org_id: string
          patient_id: string
          patient_name: string
          updated_at?: string
          vitals?: Json | null
        }
        Update: {
          branch_id?: string | null
          complaints?: string | null
          consultation_fee?: number | null
          created_at?: string
          date?: string
          department?: string
          diagnosis?: string | null
          doctor?: string
          examination?: string | null
          id?: string
          notes?: string | null
          org_id?: string
          patient_id?: string
          patient_name?: string
          updated_at?: string
          vitals?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "consultations_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "consultations_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "consultations_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          branch_id: string | null
          code: string
          created_at: string
          hod: string | null
          id: string
          is_active: boolean
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          code: string
          created_at?: string
          hod?: string | null
          id?: string
          is_active?: boolean
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          code?: string
          created_at?: string
          hod?: string | null
          id?: string
          is_active?: boolean
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "departments_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      dialysis_machines: {
        Row: {
          branch_id: string | null
          created_at: string
          id: string
          last_maintenance: string | null
          machine_name: string
          machine_no: string
          manufacturer: string | null
          model: string | null
          next_maintenance: string | null
          org_id: string
          status: string
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          id?: string
          last_maintenance?: string | null
          machine_name: string
          machine_no: string
          manufacturer?: string | null
          model?: string | null
          next_maintenance?: string | null
          org_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          id?: string
          last_maintenance?: string | null
          machine_name?: string
          machine_no?: string
          manufacturer?: string | null
          model?: string | null
          next_maintenance?: string | null
          org_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "dialysis_machines_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dialysis_machines_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      dialysis_sessions: {
        Row: {
          blood_flow_rate: number | null
          branch_id: string | null
          complications: string | null
          created_at: string
          dialysate_flow_rate: number | null
          dialyzer_type: string | null
          duration_minutes: number | null
          end_time: string | null
          id: string
          machine_id: string | null
          notes: string | null
          org_id: string
          patient_id: string
          patient_name: string
          post_vitals: Json | null
          post_weight: number | null
          pre_vitals: Json | null
          pre_weight: number | null
          session_date: string
          start_time: string | null
          status: string
          technician: string | null
          uf_goal: number | null
          updated_at: string
        }
        Insert: {
          blood_flow_rate?: number | null
          branch_id?: string | null
          complications?: string | null
          created_at?: string
          dialysate_flow_rate?: number | null
          dialyzer_type?: string | null
          duration_minutes?: number | null
          end_time?: string | null
          id?: string
          machine_id?: string | null
          notes?: string | null
          org_id: string
          patient_id: string
          patient_name: string
          post_vitals?: Json | null
          post_weight?: number | null
          pre_vitals?: Json | null
          pre_weight?: number | null
          session_date?: string
          start_time?: string | null
          status?: string
          technician?: string | null
          uf_goal?: number | null
          updated_at?: string
        }
        Update: {
          blood_flow_rate?: number | null
          branch_id?: string | null
          complications?: string | null
          created_at?: string
          dialysate_flow_rate?: number | null
          dialyzer_type?: string | null
          duration_minutes?: number | null
          end_time?: string | null
          id?: string
          machine_id?: string | null
          notes?: string | null
          org_id?: string
          patient_id?: string
          patient_name?: string
          post_vitals?: Json | null
          post_weight?: number | null
          pre_vitals?: Json | null
          pre_weight?: number | null
          session_date?: string
          start_time?: string | null
          status?: string
          technician?: string | null
          uf_goal?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "dialysis_sessions_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dialysis_sessions_machine_id_fkey"
            columns: ["machine_id"]
            isOneToOne: false
            referencedRelation: "dialysis_machines"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dialysis_sessions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dialysis_sessions_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      doctor_schedules: {
        Row: {
          branch_id: string | null
          created_at: string
          day_of_week: number
          department: string
          doctor_name: string
          doctor_user_id: string | null
          end_time: string
          id: string
          is_active: boolean | null
          max_patients: number | null
          org_id: string
          room: string | null
          slot_duration: number
          start_time: string
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          day_of_week: number
          department: string
          doctor_name: string
          doctor_user_id?: string | null
          end_time: string
          id?: string
          is_active?: boolean | null
          max_patients?: number | null
          org_id: string
          room?: string | null
          slot_duration?: number
          start_time: string
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          day_of_week?: number
          department?: string
          doctor_name?: string
          doctor_user_id?: string | null
          end_time?: string
          id?: string
          is_active?: boolean | null
          max_patients?: number | null
          org_id?: string
          room?: string | null
          slot_duration?: number
          start_time?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "doctor_schedules_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "doctor_schedules_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      emergency_cases: {
        Row: {
          arrival_mode: string
          arrival_time: string
          attending_doctor: string | null
          branch_id: string | null
          case_no: string
          chief_complaint: string
          created_at: string
          discharge_time: string | null
          id: string
          is_mlc: boolean | null
          mlc_details: Json | null
          org_id: string
          patient_id: string | null
          patient_name: string
          status: string
          treatment_notes: string | null
          triage_level: string
          updated_at: string
          vitals: Json | null
        }
        Insert: {
          arrival_mode?: string
          arrival_time?: string
          attending_doctor?: string | null
          branch_id?: string | null
          case_no: string
          chief_complaint: string
          created_at?: string
          discharge_time?: string | null
          id?: string
          is_mlc?: boolean | null
          mlc_details?: Json | null
          org_id: string
          patient_id?: string | null
          patient_name: string
          status?: string
          treatment_notes?: string | null
          triage_level?: string
          updated_at?: string
          vitals?: Json | null
        }
        Update: {
          arrival_mode?: string
          arrival_time?: string
          attending_doctor?: string | null
          branch_id?: string | null
          case_no?: string
          chief_complaint?: string
          created_at?: string
          discharge_time?: string | null
          id?: string
          is_mlc?: boolean | null
          mlc_details?: Json | null
          org_id?: string
          patient_id?: string | null
          patient_name?: string
          status?: string
          treatment_notes?: string | null
          triage_level?: string
          updated_at?: string
          vitals?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "emergency_cases_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "emergency_cases_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "emergency_cases_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      equipment: {
        Row: {
          asset_code: string
          branch_id: string | null
          created_at: string
          department: string | null
          id: string
          last_maintenance: string | null
          location: string | null
          name: string
          next_maintenance: string | null
          notes: string | null
          org_id: string
          status: string
          updated_at: string
          vendor: string | null
          warranty_expiry: string | null
        }
        Insert: {
          asset_code: string
          branch_id?: string | null
          created_at?: string
          department?: string | null
          id?: string
          last_maintenance?: string | null
          location?: string | null
          name: string
          next_maintenance?: string | null
          notes?: string | null
          org_id: string
          status?: string
          updated_at?: string
          vendor?: string | null
          warranty_expiry?: string | null
        }
        Update: {
          asset_code?: string
          branch_id?: string | null
          created_at?: string
          department?: string | null
          id?: string
          last_maintenance?: string | null
          location?: string | null
          name?: string
          next_maintenance?: string | null
          notes?: string | null
          org_id?: string
          status?: string
          updated_at?: string
          vendor?: string | null
          warranty_expiry?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "equipment_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "equipment_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      inventory_items: {
        Row: {
          branch_id: string | null
          category: string
          code: string
          created_at: string
          current_stock: number
          hsn_code: string | null
          id: string
          is_active: boolean
          manufacturer: string | null
          name: string
          org_id: string
          reorder_level: number
          unit: string
          unit_price: number
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          category?: string
          code: string
          created_at?: string
          current_stock?: number
          hsn_code?: string | null
          id?: string
          is_active?: boolean
          manufacturer?: string | null
          name: string
          org_id: string
          reorder_level?: number
          unit?: string
          unit_price?: number
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          category?: string
          code?: string
          created_at?: string
          current_stock?: number
          hsn_code?: string | null
          id?: string
          is_active?: boolean
          manufacturer?: string | null
          name?: string
          org_id?: string
          reorder_level?: number
          unit?: string
          unit_price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "inventory_items_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inventory_items_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          branch_id: string | null
          category: Database["public"]["Enums"]["invoice_category"]
          created_at: string
          date: string
          id: string
          invoice_no: string
          items: Json
          org_id: string
          paid: number
          patient_id: string
          patient_name: string
          payment_mode: string | null
          status: Database["public"]["Enums"]["invoice_status"]
          total: number
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          category?: Database["public"]["Enums"]["invoice_category"]
          created_at?: string
          date?: string
          id?: string
          invoice_no: string
          items?: Json
          org_id: string
          paid?: number
          patient_id: string
          patient_name: string
          payment_mode?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          total?: number
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          category?: Database["public"]["Enums"]["invoice_category"]
          created_at?: string
          date?: string
          id?: string
          invoice_no?: string
          items?: Json
          org_id?: string
          paid?: number
          patient_id?: string
          patient_name?: string
          payment_mode?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      lab_orders: {
        Row: {
          branch_id: string | null
          category: string
          created_at: string
          doctor: string
          id: string
          order_no: string
          order_time: string
          org_id: string
          patient_id: string
          patient_name: string
          priority: Database["public"]["Enums"]["priority_level"]
          results: Json | null
          sample_status: Database["public"]["Enums"]["sample_status"]
          stage: Database["public"]["Enums"]["lab_stage"]
          tests: string
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          category: string
          created_at?: string
          doctor: string
          id?: string
          order_no: string
          order_time?: string
          org_id: string
          patient_id: string
          patient_name: string
          priority?: Database["public"]["Enums"]["priority_level"]
          results?: Json | null
          sample_status?: Database["public"]["Enums"]["sample_status"]
          stage?: Database["public"]["Enums"]["lab_stage"]
          tests: string
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          category?: string
          created_at?: string
          doctor?: string
          id?: string
          order_no?: string
          order_time?: string
          org_id?: string
          patient_id?: string
          patient_name?: string
          priority?: Database["public"]["Enums"]["priority_level"]
          results?: Json | null
          sample_status?: Database["public"]["Enums"]["sample_status"]
          stage?: Database["public"]["Enums"]["lab_stage"]
          tests?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lab_orders_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lab_orders_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lab_orders_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_requests: {
        Row: {
          approved_by: string | null
          created_at: string
          days: number
          employee_name: string
          from_date: string
          id: string
          leave_type: string
          org_id: string
          reason: string | null
          status: string
          to_date: string
          updated_at: string
          user_id: string
        }
        Insert: {
          approved_by?: string | null
          created_at?: string
          days?: number
          employee_name: string
          from_date: string
          id?: string
          leave_type?: string
          org_id: string
          reason?: string | null
          status?: string
          to_date: string
          updated_at?: string
          user_id: string
        }
        Update: {
          approved_by?: string | null
          created_at?: string
          days?: number
          employee_name?: string
          from_date?: string
          id?: string
          leave_type?: string
          org_id?: string
          reason?: string | null
          status?: string
          to_date?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "leave_requests_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      nursing_tasks: {
        Row: {
          assigned_to: string | null
          bed_no: string | null
          branch_id: string | null
          completed_at: string | null
          created_at: string
          description: string
          due_at: string
          id: string
          notes: string | null
          org_id: string
          patient_id: string
          patient_name: string
          priority: string
          status: string
          task_type: string
          updated_at: string
          ward: string | null
        }
        Insert: {
          assigned_to?: string | null
          bed_no?: string | null
          branch_id?: string | null
          completed_at?: string | null
          created_at?: string
          description: string
          due_at: string
          id?: string
          notes?: string | null
          org_id: string
          patient_id: string
          patient_name: string
          priority?: string
          status?: string
          task_type: string
          updated_at?: string
          ward?: string | null
        }
        Update: {
          assigned_to?: string | null
          bed_no?: string | null
          branch_id?: string | null
          completed_at?: string | null
          created_at?: string
          description?: string
          due_at?: string
          id?: string
          notes?: string | null
          org_id?: string
          patient_id?: string
          patient_name?: string
          priority?: string
          status?: string
          task_type?: string
          updated_at?: string
          ward?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "nursing_tasks_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "nursing_tasks_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "nursing_tasks_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      org_modules: {
        Row: {
          config: Json | null
          created_at: string
          id: string
          is_enabled: boolean
          module: Database["public"]["Enums"]["module_key"]
          org_id: string
          updated_at: string
        }
        Insert: {
          config?: Json | null
          created_at?: string
          id?: string
          is_enabled?: boolean
          module: Database["public"]["Enums"]["module_key"]
          org_id: string
          updated_at?: string
        }
        Update: {
          config?: Json | null
          created_at?: string
          id?: string
          is_enabled?: boolean
          module?: Database["public"]["Enums"]["module_key"]
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "org_modules_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          address: string | null
          city: string | null
          created_at: string
          email: string | null
          id: string
          is_active: boolean
          license_no: string | null
          logo_url: string | null
          max_branches: number | null
          max_users: number | null
          name: string
          org_type: Database["public"]["Enums"]["org_type"]
          phone: string | null
          pincode: string | null
          primary_color: string | null
          secondary_color: string | null
          slug: string
          state: string | null
          subscription_plan: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean
          license_no?: string | null
          logo_url?: string | null
          max_branches?: number | null
          max_users?: number | null
          name: string
          org_type: Database["public"]["Enums"]["org_type"]
          phone?: string | null
          pincode?: string | null
          primary_color?: string | null
          secondary_color?: string | null
          slug: string
          state?: string | null
          subscription_plan?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          address?: string | null
          city?: string | null
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean
          license_no?: string | null
          logo_url?: string | null
          max_branches?: number | null
          max_users?: number | null
          name?: string
          org_type?: Database["public"]["Enums"]["org_type"]
          phone?: string | null
          pincode?: string | null
          primary_color?: string | null
          secondary_color?: string | null
          slug?: string
          state?: string | null
          subscription_plan?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: []
      }
      ot_rooms: {
        Row: {
          branch_id: string | null
          created_at: string
          equipment: Json | null
          id: string
          org_id: string
          room_name: string
          room_type: string
          status: string
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          equipment?: Json | null
          id?: string
          org_id: string
          room_name: string
          room_type?: string
          status?: string
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          equipment?: Json | null
          id?: string
          org_id?: string
          room_name?: string
          room_type?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ot_rooms_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ot_rooms_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      ot_surgeries: {
        Row: {
          anesthesiologist: string | null
          branch_id: string | null
          created_at: string
          diagnosis: string | null
          duration_minutes: number | null
          id: string
          intraop_notes: Json | null
          org_id: string
          patient_id: string
          patient_name: string
          postop_notes: Json | null
          preop_checklist: Json | null
          priority: string
          room_id: string | null
          scheduled_date: string
          scheduled_time: string
          status: string
          surgeon: string
          surgery_type: string
          team: Json | null
          updated_at: string
        }
        Insert: {
          anesthesiologist?: string | null
          branch_id?: string | null
          created_at?: string
          diagnosis?: string | null
          duration_minutes?: number | null
          id?: string
          intraop_notes?: Json | null
          org_id: string
          patient_id: string
          patient_name: string
          postop_notes?: Json | null
          preop_checklist?: Json | null
          priority?: string
          room_id?: string | null
          scheduled_date: string
          scheduled_time: string
          status?: string
          surgeon: string
          surgery_type: string
          team?: Json | null
          updated_at?: string
        }
        Update: {
          anesthesiologist?: string | null
          branch_id?: string | null
          created_at?: string
          diagnosis?: string | null
          duration_minutes?: number | null
          id?: string
          intraop_notes?: Json | null
          org_id?: string
          patient_id?: string
          patient_name?: string
          postop_notes?: Json | null
          preop_checklist?: Json | null
          priority?: string
          room_id?: string | null
          scheduled_date?: string
          scheduled_time?: string
          status?: string
          surgeon?: string
          surgery_type?: string
          team?: Json | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ot_surgeries_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ot_surgeries_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ot_surgeries_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ot_surgeries_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "ot_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      patients: {
        Row: {
          aadhaar: string | null
          abha_id: string | null
          age: number
          allergies: string | null
          assigned_doctor: string | null
          blood_group: string | null
          branch_id: string | null
          category: Database["public"]["Enums"]["patient_category"]
          chronic_diseases: string | null
          created_at: string
          department: string | null
          gender: string
          id: string
          insurance_provider: string | null
          is_mlc: boolean | null
          last_visit: string | null
          name: string
          org_id: string
          patient_type: Database["public"]["Enums"]["patient_type"]
          phone: string
          policy_no: string | null
          registered_on: string
          uhid: string
          updated_at: string
        }
        Insert: {
          aadhaar?: string | null
          abha_id?: string | null
          age: number
          allergies?: string | null
          assigned_doctor?: string | null
          blood_group?: string | null
          branch_id?: string | null
          category?: Database["public"]["Enums"]["patient_category"]
          chronic_diseases?: string | null
          created_at?: string
          department?: string | null
          gender: string
          id?: string
          insurance_provider?: string | null
          is_mlc?: boolean | null
          last_visit?: string | null
          name: string
          org_id: string
          patient_type?: Database["public"]["Enums"]["patient_type"]
          phone: string
          policy_no?: string | null
          registered_on?: string
          uhid: string
          updated_at?: string
        }
        Update: {
          aadhaar?: string | null
          abha_id?: string | null
          age?: number
          allergies?: string | null
          assigned_doctor?: string | null
          blood_group?: string | null
          branch_id?: string | null
          category?: Database["public"]["Enums"]["patient_category"]
          chronic_diseases?: string | null
          created_at?: string
          department?: string | null
          gender?: string
          id?: string
          insurance_provider?: string | null
          is_mlc?: boolean | null
          last_visit?: string | null
          name?: string
          org_id?: string
          patient_type?: Database["public"]["Enums"]["patient_type"]
          phone?: string
          policy_no?: string | null
          registered_on?: string
          uhid?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "patients_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patients_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      pharmacy_stock: {
        Row: {
          batch_no: string | null
          branch_id: string | null
          category: string
          created_at: string
          current_stock: number
          drug_code: string | null
          drug_name: string
          expiry_date: string | null
          formulation: string | null
          generic_name: string | null
          id: string
          is_active: boolean | null
          manufacturer: string | null
          mrp: number
          org_id: string
          rack_location: string | null
          reorder_level: number
          schedule_type: string | null
          unit_price: number
          updated_at: string
        }
        Insert: {
          batch_no?: string | null
          branch_id?: string | null
          category?: string
          created_at?: string
          current_stock?: number
          drug_code?: string | null
          drug_name: string
          expiry_date?: string | null
          formulation?: string | null
          generic_name?: string | null
          id?: string
          is_active?: boolean | null
          manufacturer?: string | null
          mrp?: number
          org_id: string
          rack_location?: string | null
          reorder_level?: number
          schedule_type?: string | null
          unit_price?: number
          updated_at?: string
        }
        Update: {
          batch_no?: string | null
          branch_id?: string | null
          category?: string
          created_at?: string
          current_stock?: number
          drug_code?: string | null
          drug_name?: string
          expiry_date?: string | null
          formulation?: string | null
          generic_name?: string | null
          id?: string
          is_active?: boolean | null
          manufacturer?: string | null
          mrp?: number
          org_id?: string
          rack_location?: string | null
          reorder_level?: number
          schedule_type?: string | null
          unit_price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "pharmacy_stock_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pharmacy_stock_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      prescriptions: {
        Row: {
          branch_id: string | null
          created_at: string
          date: string
          department: string
          doctor: string
          id: string
          medications: Json
          org_id: string
          patient_id: string
          patient_name: string
          priority: Database["public"]["Enums"]["priority_level"]
          rx_no: string
          status: Database["public"]["Enums"]["rx_status"]
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          date?: string
          department: string
          doctor: string
          id?: string
          medications?: Json
          org_id: string
          patient_id: string
          patient_name: string
          priority?: Database["public"]["Enums"]["priority_level"]
          rx_no: string
          status?: Database["public"]["Enums"]["rx_status"]
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          date?: string
          department?: string
          doctor?: string
          id?: string
          medications?: Json
          org_id?: string
          patient_id?: string
          patient_name?: string
          priority?: Database["public"]["Enums"]["priority_level"]
          rx_no?: string
          status?: Database["public"]["Enums"]["rx_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "prescriptions_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prescriptions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prescriptions_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          branch_id: string | null
          created_at: string
          department: string | null
          designation: string | null
          email: string | null
          employee_id: string | null
          full_name: string
          id: string
          is_active: boolean
          org_id: string
          phone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          branch_id?: string | null
          created_at?: string
          department?: string | null
          designation?: string | null
          email?: string | null
          employee_id?: string | null
          full_name: string
          id?: string
          is_active?: boolean
          org_id: string
          phone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          branch_id?: string | null
          created_at?: string
          department?: string | null
          designation?: string | null
          email?: string | null
          employee_id?: string | null
          full_name?: string
          id?: string
          is_active?: boolean
          org_id?: string
          phone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      purchase_orders: {
        Row: {
          branch_id: string | null
          created_at: string
          expected_date: string | null
          id: string
          items: Json
          notes: string | null
          order_date: string
          org_id: string
          po_no: string
          received_date: string | null
          status: string
          supplier: string
          total: number
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          expected_date?: string | null
          id?: string
          items?: Json
          notes?: string | null
          order_date?: string
          org_id: string
          po_no: string
          received_date?: string | null
          status?: string
          supplier: string
          total?: number
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          expected_date?: string | null
          id?: string
          items?: Json
          notes?: string | null
          order_date?: string
          org_id?: string
          po_no?: string
          received_date?: string | null
          status?: string
          supplier?: string
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "purchase_orders_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_orders_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      queue_entries: {
        Row: {
          appointment_id: string | null
          branch_id: string | null
          checked_in_at: string
          complaint: string | null
          created_at: string
          department: string
          doctor: string
          id: string
          org_id: string
          patient_id: string
          patient_name: string
          status: Database["public"]["Enums"]["queue_status"]
          token_no: number
          updated_at: string
        }
        Insert: {
          appointment_id?: string | null
          branch_id?: string | null
          checked_in_at?: string
          complaint?: string | null
          created_at?: string
          department: string
          doctor: string
          id?: string
          org_id: string
          patient_id: string
          patient_name: string
          status?: Database["public"]["Enums"]["queue_status"]
          token_no: number
          updated_at?: string
        }
        Update: {
          appointment_id?: string | null
          branch_id?: string | null
          checked_in_at?: string
          complaint?: string | null
          created_at?: string
          department?: string
          doctor?: string
          id?: string
          org_id?: string
          patient_id?: string
          patient_name?: string
          status?: Database["public"]["Enums"]["queue_status"]
          token_no?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "queue_entries_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "queue_entries_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "queue_entries_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "queue_entries_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      radiology_orders: {
        Row: {
          branch_id: string | null
          created_at: string
          doctor: string
          id: string
          modality: string
          order_no: string
          order_time: string
          org_id: string
          patient_id: string
          patient_name: string
          priority: Database["public"]["Enums"]["priority_level"]
          report: Json | null
          status: Database["public"]["Enums"]["radiology_status"]
          study: string
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          doctor: string
          id?: string
          modality: string
          order_no: string
          order_time?: string
          org_id: string
          patient_id: string
          patient_name: string
          priority?: Database["public"]["Enums"]["priority_level"]
          report?: Json | null
          status?: Database["public"]["Enums"]["radiology_status"]
          study: string
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          doctor?: string
          id?: string
          modality?: string
          order_no?: string
          order_time?: string
          org_id?: string
          patient_id?: string
          patient_name?: string
          priority?: Database["public"]["Enums"]["priority_level"]
          report?: Json | null
          status?: Database["public"]["Enums"]["radiology_status"]
          study?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "radiology_orders_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "radiology_orders_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "radiology_orders_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      requisitions: {
        Row: {
          branch_id: string | null
          created_at: string
          from_department: string
          id: string
          items: Json
          notes: string | null
          org_id: string
          priority: string
          req_no: string
          requested_by: string | null
          status: string
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          from_department: string
          id?: string
          items?: Json
          notes?: string | null
          org_id: string
          priority?: string
          req_no: string
          requested_by?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          from_department?: string
          id?: string
          items?: Json
          notes?: string | null
          org_id?: string
          priority?: string
          req_no?: string
          requested_by?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "requisitions_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "requisitions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_attendance: {
        Row: {
          check_in: string | null
          check_out: string | null
          created_at: string
          date: string
          id: string
          notes: string | null
          org_id: string
          shift: string | null
          status: string
          user_id: string
        }
        Insert: {
          check_in?: string | null
          check_out?: string | null
          created_at?: string
          date?: string
          id?: string
          notes?: string | null
          org_id: string
          shift?: string | null
          status?: string
          user_id: string
        }
        Update: {
          check_in?: string | null
          check_out?: string | null
          created_at?: string
          date?: string
          id?: string
          notes?: string | null
          org_id?: string
          shift?: string | null
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_attendance_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      stock_entries: {
        Row: {
          batch_no: string | null
          branch_id: string | null
          created_at: string
          created_by: string | null
          entry_type: string
          expiry_date: string | null
          id: string
          invoice_no: string | null
          item_id: string
          notes: string | null
          org_id: string
          quantity: number
          supplier: string | null
          unit_cost: number | null
        }
        Insert: {
          batch_no?: string | null
          branch_id?: string | null
          created_at?: string
          created_by?: string | null
          entry_type?: string
          expiry_date?: string | null
          id?: string
          invoice_no?: string | null
          item_id: string
          notes?: string | null
          org_id: string
          quantity: number
          supplier?: string | null
          unit_cost?: number | null
        }
        Update: {
          batch_no?: string | null
          branch_id?: string | null
          created_at?: string
          created_by?: string | null
          entry_type?: string
          expiry_date?: string | null
          id?: string
          invoice_no?: string | null
          item_id?: string
          notes?: string | null
          org_id?: string
          quantity?: number
          supplier?: string | null
          unit_cost?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "stock_entries_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stock_entries_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "inventory_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stock_entries_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      suppliers: {
        Row: {
          address: string | null
          contact_person: string | null
          created_at: string
          drug_license_no: string | null
          email: string | null
          gst_no: string | null
          id: string
          is_active: boolean | null
          name: string
          org_id: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          contact_person?: string | null
          created_at?: string
          drug_license_no?: string | null
          email?: string | null
          gst_no?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          org_id: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          contact_person?: string | null
          created_at?: string
          drug_license_no?: string | null
          email?: string | null
          gst_no?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          org_id?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "suppliers_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          org_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          org_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          org_id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      vital_records: {
        Row: {
          blood_sugar: number | null
          bp_diastolic: number | null
          bp_systolic: number | null
          branch_id: string | null
          created_at: string
          height: number | null
          id: string
          notes: string | null
          org_id: string
          pain_score: number | null
          patient_id: string
          patient_name: string
          pulse: number | null
          recorded_at: string
          recorded_by: string | null
          respiratory_rate: number | null
          spo2: number | null
          temperature: number | null
          weight: number | null
        }
        Insert: {
          blood_sugar?: number | null
          bp_diastolic?: number | null
          bp_systolic?: number | null
          branch_id?: string | null
          created_at?: string
          height?: number | null
          id?: string
          notes?: string | null
          org_id: string
          pain_score?: number | null
          patient_id: string
          patient_name: string
          pulse?: number | null
          recorded_at?: string
          recorded_by?: string | null
          respiratory_rate?: number | null
          spo2?: number | null
          temperature?: number | null
          weight?: number | null
        }
        Update: {
          blood_sugar?: number | null
          bp_diastolic?: number | null
          bp_systolic?: number | null
          branch_id?: string | null
          created_at?: string
          height?: number | null
          id?: string
          notes?: string | null
          org_id?: string
          pain_score?: number | null
          patient_id?: string
          patient_name?: string
          pulse?: number | null
          recorded_at?: string
          recorded_by?: string | null
          respiratory_rate?: number | null
          spo2?: number | null
          temperature?: number | null
          weight?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "vital_records_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vital_records_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vital_records_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_user_org_id: { Args: { _user_id: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      user_belongs_to_org: {
        Args: { _org_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role:
        | "super_admin"
        | "org_admin"
        | "doctor"
        | "nurse"
        | "receptionist"
        | "lab_tech"
        | "pharmacist"
        | "billing_staff"
        | "radiologist"
        | "ot_coordinator"
        | "inventory_manager"
        | "emergency_staff"
        | "hr_manager"
        | "scheduler"
        | "dialysis_tech"
      appointment_status:
        | "scheduled"
        | "confirmed"
        | "checked-in"
        | "in-consultation"
        | "completed"
        | "cancelled"
        | "no-show"
      appointment_type: "new" | "follow-up" | "teleconsultation"
      invoice_category:
        | "OPD"
        | "IPD"
        | "Emergency"
        | "Lab"
        | "Pharmacy"
        | "Radiology"
      invoice_status: "paid" | "partial" | "pending" | "overdue"
      lab_stage:
        | "Pending Analysis"
        | "In Analysis"
        | "Awaiting Validation"
        | "Validated"
        | "Reported"
      module_key:
        | "dashboard"
        | "reception"
        | "doctor"
        | "nurse"
        | "lab"
        | "pharmacy"
        | "radiology"
        | "billing"
        | "inventory"
        | "ot"
        | "emergency"
        | "hr"
        | "scheduling"
        | "dialysis"
        | "admin"
        | "ipd"
        | "reports"
        | "ai_workflow"
        | "command_center"
        | "data_mining"
        | "geo_intelligence"
        | "kaizen"
        | "mis"
        | "mortality_analytics"
        | "revenue_cycle"
        | "treatment_success"
        | "disease_mapping"
        | "doctor_sharing"
        | "mrd"
      org_type:
        | "clinic"
        | "clinic_chain"
        | "hospital"
        | "hospital_chain"
        | "dialysis_center"
      patient_category:
        | "general"
        | "corporate"
        | "insurance"
        | "government"
        | "vip"
      patient_type: "OPD" | "IPD" | "Emergency"
      priority_level: "Routine" | "Urgent" | "Emergency"
      queue_status:
        | "waiting"
        | "called"
        | "in-consultation"
        | "completed"
        | "skipped"
      radiology_status:
        | "Ordered"
        | "Scheduled"
        | "In Progress"
        | "Completed"
        | "Reported"
      rx_status:
        | "Pending"
        | "Verified"
        | "Dispensed"
        | "Partially dispensed"
        | "Cancelled"
      sample_status:
        | "Ordered"
        | "Collected"
        | "Received"
        | "Processing"
        | "Analysis Complete"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "super_admin",
        "org_admin",
        "doctor",
        "nurse",
        "receptionist",
        "lab_tech",
        "pharmacist",
        "billing_staff",
        "radiologist",
        "ot_coordinator",
        "inventory_manager",
        "emergency_staff",
        "hr_manager",
        "scheduler",
        "dialysis_tech",
      ],
      appointment_status: [
        "scheduled",
        "confirmed",
        "checked-in",
        "in-consultation",
        "completed",
        "cancelled",
        "no-show",
      ],
      appointment_type: ["new", "follow-up", "teleconsultation"],
      invoice_category: [
        "OPD",
        "IPD",
        "Emergency",
        "Lab",
        "Pharmacy",
        "Radiology",
      ],
      invoice_status: ["paid", "partial", "pending", "overdue"],
      lab_stage: [
        "Pending Analysis",
        "In Analysis",
        "Awaiting Validation",
        "Validated",
        "Reported",
      ],
      module_key: [
        "dashboard",
        "reception",
        "doctor",
        "nurse",
        "lab",
        "pharmacy",
        "radiology",
        "billing",
        "inventory",
        "ot",
        "emergency",
        "hr",
        "scheduling",
        "dialysis",
        "admin",
        "ipd",
        "reports",
        "ai_workflow",
        "command_center",
        "data_mining",
        "geo_intelligence",
        "kaizen",
        "mis",
        "mortality_analytics",
        "revenue_cycle",
        "treatment_success",
        "disease_mapping",
        "doctor_sharing",
        "mrd",
      ],
      org_type: [
        "clinic",
        "clinic_chain",
        "hospital",
        "hospital_chain",
        "dialysis_center",
      ],
      patient_category: [
        "general",
        "corporate",
        "insurance",
        "government",
        "vip",
      ],
      patient_type: ["OPD", "IPD", "Emergency"],
      priority_level: ["Routine", "Urgent", "Emergency"],
      queue_status: [
        "waiting",
        "called",
        "in-consultation",
        "completed",
        "skipped",
      ],
      radiology_status: [
        "Ordered",
        "Scheduled",
        "In Progress",
        "Completed",
        "Reported",
      ],
      rx_status: [
        "Pending",
        "Verified",
        "Dispensed",
        "Partially dispensed",
        "Cancelled",
      ],
      sample_status: [
        "Ordered",
        "Collected",
        "Received",
        "Processing",
        "Analysis Complete",
      ],
    },
  },
} as const
