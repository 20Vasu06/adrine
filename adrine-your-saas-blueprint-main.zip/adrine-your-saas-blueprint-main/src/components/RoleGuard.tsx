import { Navigate } from 'react-router-dom';
import { useAuth, UserRole } from '@/contexts/AuthContext';

interface RoleGuardProps {
  allowedRoles: UserRole[];
  children: React.ReactNode;
}

export default function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const { activeRole } = useAuth();

  if (!activeRole || !allowedRoles.includes(activeRole)) {
    return <Navigate to="/select-role" replace />;
  }

  return <>{children}</>;
}
