import { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

// ── Shared Types (kept for backward compat) ──
export interface HospitalPatient {
  id?: string;
  uhid: string;
  name: string;
  age: number;
  gender: string;
  phone: string;
  bloodGroup?: string;
  abhaId?: string;
  aadhaar?: string;
  category: 'general' | 'corporate' | 'insurance' | 'government' | 'vip';
  patientType: 'OPD' | 'IPD' | 'Emergency';
  department?: string;
  assignedDoctor?: string;
  allergies?: string;
  chronicDiseases?: string;
  registeredOn: string;
  lastVisit?: string;
  branch: string;
  insuranceProvider?: string;
  policyNo?: string;
  isMLC?: boolean;
}

export interface HospitalAppointment {
  id: string;
  uhid: string;
  patientName: string;
  phone: string;
  doctor: string;
  department: string;
  date: string;
  time: string;
  duration: number;
  status: 'scheduled' | 'confirmed' | 'checked-in' | 'in-consultation' | 'completed' | 'cancelled' | 'no-show';
  type: 'new' | 'follow-up' | 'teleconsultation';
  notes: string;
}

export interface QueueEntry {
  tokenNo: number;
  uhid: string;
  patientName: string;
  doctor: string;
  department: string;
  status: 'waiting' | 'called' | 'in-consultation' | 'completed' | 'skipped';
  appointmentId?: string;
  checkedInAt: string;
  complaint?: string;
}

export interface LabOrder {
  orderId: string;
  uhid: string;
  patientName: string;
  tests: string;
  category: string;
  priority: 'Routine' | 'Urgent' | 'Emergency';
  doctor: string;
  orderTime: string;
  stage: 'Pending Analysis' | 'In Analysis' | 'Awaiting Validation' | 'Validated' | 'Reported';
  sampleStatus: 'Ordered' | 'Collected' | 'Received' | 'Processing' | 'Analysis Complete';
  results?: string;
}

export interface PrescriptionOrder {
  id: string;
  uhid: string;
  patientName: string;
  doctor: string;
  department: string;
  date: string;
  priority: 'Routine' | 'Urgent' | 'Emergency';
  status: 'Pending' | 'Verified' | 'Dispensed' | 'Partially dispensed' | 'Cancelled';
  meds: { drug: string; dosage: string; frequency: string; duration: string; route: string; qty: number; dispensed: number }[];
}

export interface RadiologyOrder {
  orderId: string;
  uhid: string;
  patientName: string;
  study: string;
  modality: string;
  priority: 'Routine' | 'Urgent' | 'Emergency';
  doctor: string;
  orderTime: string;
  status: 'Ordered' | 'Scheduled' | 'In Progress' | 'Completed' | 'Reported';
}

export interface BillingInvoice {
  id: string;
  uhid: string;
  patientName: string;
  date: string;
  category: 'OPD' | 'IPD' | 'Emergency' | 'Lab' | 'Pharmacy' | 'Radiology';
  items: { description: string; amount: number }[];
  total: number;
  paid: number;
  status: 'paid' | 'partial' | 'pending' | 'overdue';
  paymentMode?: string;
}

// ── Counter helpers for unique IDs ──
let patientCounter = Date.now();
let appointmentCounter = Date.now();
let tokenCounter = 100;
let labOrderCounter = Date.now();
let rxCounter = Date.now();
let radiologyCounter = Date.now();
let invoiceCounter = Date.now();

// ── Helper: Map DB row to frontend type ──
function mapPatient(row: any): HospitalPatient {
  return {
    id: row.id,
    uhid: row.uhid,
    name: row.name,
    age: row.age,
    gender: row.gender,
    phone: row.phone,
    bloodGroup: row.blood_group,
    abhaId: row.abha_id,
    aadhaar: row.aadhaar,
    category: row.category,
    patientType: row.patient_type,
    department: row.department,
    assignedDoctor: row.assigned_doctor,
    allergies: row.allergies,
    chronicDiseases: row.chronic_diseases,
    registeredOn: new Date(row.registered_on).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
    lastVisit: row.last_visit ? new Date(row.last_visit).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : undefined,
    branch: 'Main Hospital',
    insuranceProvider: row.insurance_provider,
    policyNo: row.policy_no,
    isMLC: row.is_mlc,
  };
}

function mapAppointment(row: any): HospitalAppointment {
  return {
    id: row.appointment_no,
    uhid: row.patient_id, // We store patient_id, map to uhid via context
    patientName: row.patient_name,
    phone: row.phone || '',
    doctor: row.doctor,
    department: row.department,
    date: row.date,
    time: row.time?.substring(0, 5) || '',
    duration: row.duration || 30,
    status: row.status,
    type: row.type,
    notes: row.notes || '',
  };
}

function mapQueue(row: any): QueueEntry {
  return {
    tokenNo: row.token_no,
    uhid: row.patient_id,
    patientName: row.patient_name,
    doctor: row.doctor,
    department: row.department,
    status: row.status,
    appointmentId: row.appointment_id,
    checkedInAt: new Date(row.checked_in_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }),
    complaint: row.complaint,
  };
}

function mapLabOrder(row: any): LabOrder {
  return {
    orderId: row.order_no,
    uhid: row.patient_id,
    patientName: row.patient_name,
    tests: row.tests,
    category: row.category,
    priority: row.priority,
    doctor: row.doctor,
    orderTime: new Date(row.order_time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }),
    stage: row.stage,
    sampleStatus: row.sample_status,
    results: row.results ? JSON.stringify(row.results) : undefined,
  };
}

function mapPrescription(row: any): PrescriptionOrder {
  return {
    id: row.rx_no,
    uhid: row.patient_id,
    patientName: row.patient_name,
    doctor: row.doctor,
    department: row.department,
    date: row.date,
    priority: row.priority,
    status: row.status,
    meds: Array.isArray(row.medications) ? row.medications : [],
  };
}

function mapRadiology(row: any): RadiologyOrder {
  return {
    orderId: row.order_no,
    uhid: row.patient_id,
    patientName: row.patient_name,
    study: row.study,
    modality: row.modality,
    priority: row.priority,
    doctor: row.doctor,
    orderTime: new Date(row.order_time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }),
    status: row.status,
  };
}

function mapInvoice(row: any): BillingInvoice {
  return {
    id: row.invoice_no,
    uhid: row.patient_id,
    patientName: row.patient_name,
    date: new Date(row.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
    category: row.category,
    items: Array.isArray(row.items) ? row.items : [],
    total: Number(row.total),
    paid: Number(row.paid),
    status: row.status,
    paymentMode: row.payment_mode,
  };
}

// ── Context ──
interface HospitalStore {
  patients: HospitalPatient[];
  appointments: HospitalAppointment[];
  queue: QueueEntry[];
  labOrders: LabOrder[];
  prescriptions: PrescriptionOrder[];
  radiologyOrders: RadiologyOrder[];
  invoices: BillingInvoice[];
  loading: boolean;
  refreshData: () => Promise<void>;

  registerPatient: (data: Omit<HospitalPatient, 'uhid' | 'registeredOn'>) => Promise<string>;
  bookAppointment: (data: Omit<HospitalAppointment, 'id'>) => Promise<string>;
  updateAppointmentStatus: (id: string, status: HospitalAppointment['status']) => void;
  checkInPatient: (appointmentId: string, complaint?: string) => Promise<number>;
  updateQueueStatus: (tokenNo: number, status: QueueEntry['status']) => void;
  nextQueuePatient: (doctor: string) => void;
  saveConsultation: (data: {
    uhid: string;
    patientName: string;
    doctor: string;
    department: string;
    labTests?: { tests: string; category: string; priority: 'Routine' | 'Urgent' | 'Emergency' }[];
    medications?: { drug: string; dosage: string; frequency: string; duration: string; route: string; qty: number }[];
    radiologyOrders?: { study: string; modality: string; priority: 'Routine' | 'Urgent' | 'Emergency' }[];
    consultationFee?: number;
  }) => void;
  updateLabStage: (orderId: string, stage: LabOrder['stage']) => void;
  dispensePrescription: (rxId: string, quantities: Record<number, number>) => void;
  collectPayment: (invoiceId: string, amount: number, mode: string) => void;
  createInvoice: (data: Omit<BillingInvoice, 'id'>) => string;
}

const HospitalContext = createContext<HospitalStore | null>(null);

export function HospitalProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const orgId = user?.orgId;

  const [patients, setPatients] = useState<HospitalPatient[]>([]);
  const [appointments, setAppointments] = useState<HospitalAppointment[]>([]);
  const [queue, setQueue] = useState<QueueEntry[]>([]);
  const [labOrders, setLabOrders] = useState<LabOrder[]>([]);
  const [prescriptions, setPrescriptions] = useState<PrescriptionOrder[]>([]);
  const [radiologyOrders, setRadiologyOrders] = useState<RadiologyOrder[]>([]);
  const [invoices, setInvoices] = useState<BillingInvoice[]>([]);
  const [loading, setLoading] = useState(false);

  const refreshData = useCallback(async () => {
    if (!orgId) return;
    setLoading(true);
    try {
      const [pRes, aRes, qRes, lRes, rxRes, rRes, iRes] = await Promise.all([
        supabase.from('patients').select('*').eq('org_id', orgId).order('created_at', { ascending: false }),
        supabase.from('appointments').select('*').eq('org_id', orgId).order('date', { ascending: false }),
        supabase.from('queue_entries').select('*').eq('org_id', orgId).order('token_no', { ascending: true }),
        supabase.from('lab_orders').select('*').eq('org_id', orgId).order('order_time', { ascending: false }),
        supabase.from('prescriptions').select('*').eq('org_id', orgId).order('created_at', { ascending: false }),
        supabase.from('radiology_orders').select('*').eq('org_id', orgId).order('order_time', { ascending: false }),
        supabase.from('invoices').select('*').eq('org_id', orgId).order('created_at', { ascending: false }),
      ]);

      if (pRes.data) setPatients(pRes.data.map(mapPatient));
      if (aRes.data) setAppointments(aRes.data.map(mapAppointment));
      if (qRes.data) setQueue(qRes.data.map(mapQueue));
      if (lRes.data) setLabOrders(lRes.data.map(mapLabOrder));
      if (rxRes.data) setPrescriptions(rxRes.data.map(mapPrescription));
      if (rRes.data) setRadiologyOrders(rRes.data.map(mapRadiology));
      if (iRes.data) setInvoices(iRes.data.map(mapInvoice));
    } catch (err) {
      console.error('Error loading hospital data:', err);
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  // Auto-load data when org changes
  useEffect(() => {
    if (orgId) refreshData();
  }, [orgId, refreshData]);

  // Realtime subscriptions
  useEffect(() => {
    if (!orgId) return;

    const channel = supabase
      .channel('hospital-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'queue_entries' }, () => refreshData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'appointments' }, () => refreshData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'lab_orders' }, () => refreshData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'prescriptions' }, () => refreshData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'radiology_orders' }, () => refreshData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'admissions' }, () => refreshData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'beds' }, () => refreshData())
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [orgId, refreshData]);

  const registerPatient = useCallback(async (data: Omit<HospitalPatient, 'uhid' | 'registeredOn'>) => {
    const uhid = `UHID-${++patientCounter}`;
    if (!orgId) return uhid;

    const { error } = await supabase.from('patients').insert({
      org_id: orgId,
      uhid,
      name: data.name,
      age: data.age,
      gender: data.gender,
      phone: data.phone,
      blood_group: data.bloodGroup,
      abha_id: data.abhaId,
      aadhaar: data.aadhaar,
      category: data.category,
      patient_type: data.patientType,
      department: data.department,
      assigned_doctor: data.assignedDoctor,
      allergies: data.allergies,
      chronic_diseases: data.chronicDiseases,
      insurance_provider: data.insuranceProvider,
      policy_no: data.policyNo,
      is_mlc: data.isMLC,
    });

    if (error) {
      toast.error('Registration failed', { description: error.message });
    } else {
      toast.success(`Patient registered: ${data.name}`, { description: `UHID: ${uhid}` });
      refreshData();
    }
    return uhid;
  }, [orgId, refreshData]);

  const bookAppointment = useCallback(async (data: Omit<HospitalAppointment, 'id'>) => {
    const appointmentNo = `APT-${++appointmentCounter}`;
    if (!orgId) return appointmentNo;

    // Find patient by uhid
    const patient = patients.find(p => p.uhid === data.uhid);
    
    const { error } = await supabase.from('appointments').insert({
      org_id: orgId,
      appointment_no: appointmentNo,
      patient_id: patient?.id || data.uhid,
      patient_name: data.patientName,
      phone: data.phone,
      doctor: data.doctor,
      department: data.department,
      date: data.date,
      time: data.time,
      duration: data.duration,
      status: data.status,
      type: data.type,
      notes: data.notes,
    });

    if (error) {
      toast.error('Booking failed', { description: error.message });
    } else {
      toast.success(`Appointment booked: ${data.patientName}`, { description: `${appointmentNo} · ${data.doctor} · ${data.time}` });
      refreshData();
    }
    return appointmentNo;
  }, [orgId, patients, refreshData]);

  const updateAppointmentStatus = useCallback((id: string, status: HospitalAppointment['status']) => {
    supabase.from('appointments').update({ status }).eq('appointment_no', id).eq('org_id', orgId!).then(() => refreshData());
  }, [orgId, refreshData]);

  const checkInPatient = useCallback(async (appointmentId: string, complaint?: string) => {
    const token = ++tokenCounter;
    const appt = appointments.find(a => a.id === appointmentId);
    if (!appt || !orgId) return token;

    await supabase.from('queue_entries').insert({
      org_id: orgId,
      token_no: token,
      patient_id: appt.uhid,
      patient_name: appt.patientName,
      doctor: appt.doctor,
      department: appt.department,
      status: 'waiting',
      appointment_id: appointmentId,
      complaint: complaint || appt.notes,
    });

    await supabase.from('appointments').update({ status: 'checked-in' }).eq('appointment_no', appointmentId).eq('org_id', orgId);
    
    toast.success(`Checked in: ${appt.patientName}`, { description: `Token #${token}` });
    refreshData();
    return token;
  }, [appointments, orgId, refreshData]);

  const updateQueueStatus = useCallback((tokenNo: number, status: QueueEntry['status']) => {
    if (!orgId) return;
    supabase.from('queue_entries').update({ status }).eq('token_no', tokenNo).eq('org_id', orgId).then(() => refreshData());
  }, [orgId, refreshData]);

  const nextQueuePatient = useCallback(async (doctor: string) => {
    if (!orgId) return;
    const currentEntry = queue.find(q => q.doctor === doctor && q.status === 'in-consultation');
    const nextEntry = queue.find(q => q.doctor === doctor && q.status === 'waiting');
    
    if (currentEntry) {
      await supabase.from('queue_entries').update({ status: 'completed' as any }).eq('token_no', currentEntry.tokenNo).eq('org_id', orgId);
    }
    if (nextEntry) {
      await supabase.from('queue_entries').update({ status: 'in-consultation' as any }).eq('token_no', nextEntry.tokenNo).eq('org_id', orgId);
    }
    refreshData();
  }, [orgId, queue, refreshData]);

  const saveConsultation = useCallback(async (data: {
    uhid: string; patientName: string; doctor: string; department: string;
    labTests?: { tests: string; category: string; priority: 'Routine' | 'Urgent' | 'Emergency' }[];
    medications?: { drug: string; dosage: string; frequency: string; duration: string; route: string; qty: number }[];
    radiologyOrders?: { study: string; modality: string; priority: 'Routine' | 'Urgent' | 'Emergency' }[];
    consultationFee?: number;
  }) => {
    if (!orgId) return;

    // Lab orders
    if (data.labTests?.length) {
      const labRows = data.labTests.map(t => ({
        org_id: orgId,
        order_no: `LO-${++labOrderCounter}`,
        patient_id: data.uhid,
        patient_name: data.patientName,
        tests: t.tests,
        category: t.category,
        priority: t.priority as any,
        doctor: data.doctor,
      }));
      await supabase.from('lab_orders').insert(labRows);
    }

    // Prescriptions
    if (data.medications?.length) {
      await supabase.from('prescriptions').insert({
        org_id: orgId,
        rx_no: `RX-${++rxCounter}`,
        patient_id: data.uhid,
        patient_name: data.patientName,
        doctor: data.doctor,
        department: data.department,
        medications: data.medications.map(m => ({ ...m, dispensed: 0 })) as any,
      });
    }

    // Radiology
    if (data.radiologyOrders?.length) {
      const radRows = data.radiologyOrders.map(r => ({
        org_id: orgId,
        order_no: `RD-${++radiologyCounter}`,
        patient_id: data.uhid,
        patient_name: data.patientName,
        study: r.study,
        modality: r.modality,
        priority: r.priority as any,
        doctor: data.doctor,
      }));
      await supabase.from('radiology_orders').insert(radRows);
    }

    // Invoice
    const billingItems: { description: string; amount: number }[] = [];
    if (data.consultationFee) billingItems.push({ description: `Consultation - ${data.department}`, amount: data.consultationFee });
    if (data.labTests) data.labTests.forEach(t => billingItems.push({ description: `Lab: ${t.tests}`, amount: 500 }));
    if (data.radiologyOrders) data.radiologyOrders.forEach(r => billingItems.push({ description: `Radiology: ${r.study}`, amount: 1000 }));

    if (billingItems.length > 0) {
      const total = billingItems.reduce((s, i) => s + i.amount, 0);
      await supabase.from('invoices').insert({
        org_id: orgId,
        invoice_no: `INV-${++invoiceCounter}`,
        patient_id: data.uhid,
        patient_name: data.patientName,
        category: 'OPD' as any,
        items: billingItems as any,
        total,
      });
    }

    // Update patient last visit
    await supabase.from('patients').update({ last_visit: new Date().toISOString() }).eq('id', data.uhid).eq('org_id', orgId);

    // Complete queue
    await supabase.from('queue_entries').update({ status: 'completed' as any }).eq('patient_id', data.uhid).eq('status', 'in-consultation' as any).eq('org_id', orgId);

    toast.success('Consultation saved', {
      description: `${data.labTests?.length || 0} lab, ${data.medications?.length || 0} meds, ${data.radiologyOrders?.length || 0} radiology`,
    });
    refreshData();
  }, [orgId, refreshData]);

  const updateLabStage = useCallback((orderId: string, stage: LabOrder['stage']) => {
    if (!orgId) return;
    supabase.from('lab_orders').update({ stage }).eq('order_no', orderId).eq('org_id', orgId).then(() => {
      toast.success(`Lab order ${orderId} updated to ${stage}`);
      refreshData();
    });
  }, [orgId, refreshData]);

  const dispensePrescription = useCallback((rxId: string, quantities: Record<number, number>) => {
    if (!orgId) return;
    const rx = prescriptions.find(r => r.id === rxId);
    if (!rx) return;

    const updatedMeds = rx.meds.map((m, i) => ({
      ...m,
      dispensed: m.dispensed + (quantities[i] || 0),
    }));
    const allDispensed = updatedMeds.every(m => m.dispensed >= m.qty);
    const someDispensed = updatedMeds.some(m => m.dispensed > 0);
    const newStatus = allDispensed ? 'Dispensed' : someDispensed ? 'Partially dispensed' : rx.status;

    supabase.from('prescriptions').update({ medications: updatedMeds, status: newStatus }).eq('rx_no', rxId).eq('org_id', orgId).then(() => {
      toast.success(`Prescription ${rxId} dispensed`);
      refreshData();
    });
  }, [orgId, prescriptions, refreshData]);

  const collectPayment = useCallback((invoiceId: string, amount: number, mode: string) => {
    if (!orgId) return;
    const inv = invoices.find(i => i.id === invoiceId);
    if (!inv) return;

    const newPaid = inv.paid + amount;
    const newStatus = newPaid >= inv.total ? 'paid' : 'partial';

    supabase.from('invoices').update({ paid: newPaid, status: newStatus, payment_mode: mode }).eq('invoice_no', invoiceId).eq('org_id', orgId).then(() => {
      toast.success(`Payment ₹${amount.toLocaleString('en-IN')} collected`, { description: `Invoice: ${invoiceId}` });
      refreshData();
    });
  }, [orgId, invoices, refreshData]);

  const createInvoice = useCallback((data: Omit<BillingInvoice, 'id'>) => {
    const invoiceNo = `INV-${++invoiceCounter}`;
    if (!orgId) return invoiceNo;

    supabase.from('invoices').insert({
      org_id: orgId,
      invoice_no: invoiceNo,
      patient_id: data.uhid,
      patient_name: data.patientName,
      category: data.category,
      items: data.items,
      total: data.total,
      paid: data.paid,
      status: data.status,
      payment_mode: data.paymentMode,
    }).then(() => refreshData());

    return invoiceNo;
  }, [orgId, refreshData]);

  return (
    <HospitalContext.Provider value={{
      patients, appointments, queue, labOrders, prescriptions, radiologyOrders, invoices, loading, refreshData,
      registerPatient, bookAppointment, updateAppointmentStatus, checkInPatient,
      updateQueueStatus, nextQueuePatient, saveConsultation, updateLabStage,
      dispensePrescription, collectPayment, createInvoice,
    }}>
      {children}
    </HospitalContext.Provider>
  );
}

export function useHospital() {
  const ctx = useContext(HospitalContext);
  if (!ctx) throw new Error('useHospital must be used within HospitalProvider');
  return ctx;
}
