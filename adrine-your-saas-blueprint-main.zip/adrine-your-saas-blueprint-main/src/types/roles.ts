// Re-export from AuthContext for backward compatibility
export type { UserRole, AppUser as User } from '@/contexts/AuthContext';

export const ROLE_LABELS: Record<string, string> = {
  admin: 'Administrator',
  doctor: 'Doctor',
  nurse: 'Nurse',
  receptionist: 'Receptionist',
  lab_technician: 'Lab Technician',
  pharmacist: 'Pharmacist',
  billing: 'Billing & Finance',
  radiologist: 'Radiologist',
  ot_coordinator: 'OT Coordinator',
  inventory_manager: 'Inventory Manager',
  emergency: 'Emergency / ER',
  hr_manager: 'HR & Staff',
  scheduler: 'Scheduling',
  dialysis_tech: 'Dialysis Unit',
};

export type ModuleKey =
  | 'dashboard'
  | 'patients'
  | 'appointments'
  | 'opd'
  | 'ipd'
  | 'bed_management'
  | 'nursing'
  | 'laboratory'
  | 'radiology'
  | 'pharmacy'
  | 'billing'
  | 'revenue'
  | 'insurance'
  | 'ot_management'
  | 'inventory'
  | 'reports'
  | 'settings';

// Which roles can access which modules
export const ROLE_PERMISSIONS: Record<string, ModuleKey[]> = {
  admin: [
    'dashboard', 'patients', 'appointments', 'opd', 'ipd', 'bed_management',
    'nursing', 'laboratory', 'radiology', 'pharmacy', 'billing', 'revenue',
    'insurance', 'ot_management', 'inventory', 'reports', 'settings',
  ],
  doctor: [
    'dashboard', 'patients', 'appointments', 'opd', 'ipd', 'bed_management',
    'laboratory', 'radiology', 'ot_management', 'reports',
  ],
  nurse: [
    'dashboard', 'patients', 'ipd', 'bed_management', 'nursing', 'ot_management',
  ],
  receptionist: [
    'dashboard', 'patients', 'appointments', 'opd', 'bed_management', 'billing',
  ],
  lab_technician: [
    'dashboard', 'laboratory', 'reports',
  ],
  pharmacist: [
    'dashboard', 'pharmacy', 'inventory', 'reports',
  ],
  billing: [
    'dashboard', 'patients', 'billing', 'revenue', 'insurance', 'reports',
  ],
  radiologist: [
    'dashboard', 'radiology', 'reports',
  ],
  ot_coordinator: [
    'dashboard', 'ot_management', 'reports',
  ],
  inventory_manager: [
    'dashboard', 'inventory', 'reports',
  ],
  emergency: [
    'dashboard', 'patients', 'opd', 'ipd', 'laboratory', 'radiology', 'pharmacy', 'billing', 'reports',
  ],
  hr_manager: [
    'dashboard', 'reports', 'settings',
  ],
  scheduler: [
    'dashboard', 'appointments', 'patients', 'reports',
  ],
  dialysis_tech: [
    'dashboard', 'patients', 'billing', 'inventory', 'reports',
  ],
};

export function hasAccess(role: string, module: ModuleKey): boolean {
  return ROLE_PERMISSIONS[role]?.includes(module) ?? false;
}
