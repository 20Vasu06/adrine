import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Activity, Users, BedDouble, Stethoscope, Clock, TrendingUp, AlertTriangle, Zap, Building2, Pill, FlaskConical, Scissors, Radio } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

export default function AdminCommandCenter() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [clock, setClock] = useState(new Date());
  const [kpis, setKpis] = useState({ opd: 0, ipd: 0, er: 0, surgeries: 0, labPending: 0, rxPending: 0 });
  const [beds, setBeds] = useState<any[]>([]);

  useEffect(() => {
    const timer = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('queue_entries').select('id', { count: 'exact' }).eq('org_id', orgId),
      supabase.from('admissions').select('id', { count: 'exact' }).eq('org_id', orgId).eq('status', 'admitted'),
      supabase.from('emergency_cases').select('id', { count: 'exact' }).eq('org_id', orgId).neq('status', 'discharged'),
      supabase.from('ot_surgeries').select('id', { count: 'exact' }).eq('org_id', orgId).eq('scheduled_date', today),
      supabase.from('lab_orders').select('id', { count: 'exact' }).eq('org_id', orgId).neq('stage', 'Reported'),
      supabase.from('prescriptions').select('id', { count: 'exact' }).eq('org_id', orgId).eq('status', 'Pending'),
      supabase.from('beds').select('*').eq('org_id', orgId),
    ]).then(([qRes, aRes, eRes, otRes, lRes, rxRes, bRes]) => {
      setKpis({
        opd: qRes.count || 0,
        ipd: aRes.count || 0,
        er: eRes.count || 0,
        surgeries: otRes.count || 0,
        labPending: lRes.count || 0,
        rxPending: rxRes.count || 0,
      });
      setBeds(bRes.data || []);
    });
  }, [orgId]);

  const totalBeds = beds.length;
  const occupiedBeds = beds.filter(b => b.is_occupied).length;

  // Group beds by ward
  const wardMap = new Map<string, { total: number; occupied: number }>();
  beds.forEach(b => {
    const w = wardMap.get(b.ward) || { total: 0, occupied: 0 };
    w.total += 1;
    if (b.is_occupied) w.occupied += 1;
    wardMap.set(b.ward, w);
  });
  const bedSummary = Array.from(wardMap.entries()).map(([ward, data]) => ({ ward, ...data, available: data.total - data.occupied }));

  const kpiCards = [
    { label: 'OPD Today', value: kpis.opd, icon: Users, color: 'text-primary' },
    { label: 'IPD Active', value: kpis.ipd, icon: BedDouble, color: 'text-success' },
    { label: 'ER Cases', value: kpis.er, icon: Zap, color: 'text-destructive' },
    { label: 'Surgeries', value: kpis.surgeries, icon: Scissors, color: 'text-warning' },
    { label: 'Lab Pending', value: kpis.labPending, icon: FlaskConical, color: 'text-info' },
    { label: 'Rx Pending', value: kpis.rxPending, icon: Pill, color: 'text-accent-foreground' },
  ];

  return (
    <div className="space-y-4">
      <motion.div {...fadeIn(0)} className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <Radio className="w-5 h-5 text-primary animate-pulse" /> Central Command Center
          </h1>
          <p className="text-sm text-muted-foreground">Unified real-time hospital operations view</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-mono font-bold">{clock.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</p>
          <p className="text-[10px] text-muted-foreground">{clock.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' })}</p>
        </div>
      </motion.div>

      <motion.div {...fadeIn(1)} className="grid grid-cols-2 lg:grid-cols-6 gap-3">
        {kpiCards.map((kpi, i) => (
          <Card key={i}>
            <CardContent className="p-3 flex items-center gap-3">
              <kpi.icon className={`w-5 h-5 ${kpi.color}`} />
              <div>
                <p className="text-lg font-bold">{kpi.value}</p>
                <p className="text-[10px] text-muted-foreground">{kpi.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </motion.div>

      {/* Bed Occupancy */}
      <motion.div {...fadeIn(2)}>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                <BedDouble className="w-3.5 h-3.5" /> Bed Occupancy
              </p>
              <Badge variant="secondary" className="text-[10px]">{occupiedBeds}/{totalBeds}</Badge>
            </div>
            {bedSummary.length > 0 ? (
              <div className="space-y-2">
                {bedSummary.map((b, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <span>{b.ward}</span>
                    <div className="flex items-center gap-2">
                      <Progress value={b.total ? (b.occupied / b.total) * 100 : 0} className="w-20 h-1.5" />
                      <span className={`font-medium w-8 text-right ${b.available <= 2 ? 'text-destructive' : 'text-success'}`}>{b.available}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground text-center py-4">No beds configured</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
