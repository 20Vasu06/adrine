import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Building2, Plus, Users, UserCheck } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export default function AdminDepartments() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [departments, setDepartments] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [newDept, setNewDept] = useState({ name: '', code: '', hod: '' });

  useEffect(() => {
    if (!orgId) return;
    const fetchData = async () => {
      const [deptRes, profRes] = await Promise.all([
        supabase.from('departments').select('*').eq('org_id', orgId).order('name'),
        supabase.from('profiles').select('department, designation').eq('org_id', orgId).eq('is_active', true),
      ]);
      setDepartments(deptRes.data || []);
      setProfiles(profRes.data || []);
      setLoading(false);
    };
    fetchData();
  }, [orgId]);

  const getDeptStaffCount = (deptName: string) => profiles.filter(p => p.department === deptName).length;
  const getDeptDoctorCount = (deptName: string) => profiles.filter(p => p.department === deptName && p.designation?.toLowerCase().includes('doctor')).length;
  const totalStaff = profiles.length;
  const totalDoctors = profiles.filter(p => p.designation?.toLowerCase().includes('doctor')).length;

  const handleCreate = async () => {
    if (!orgId || !newDept.name || !newDept.code) return;
    const { error } = await supabase.from('departments').insert({
      org_id: orgId, name: newDept.name, code: newDept.code.toUpperCase(), hod: newDept.hod || null,
    });
    if (error) { toast.error('Failed to create department'); return; }
    toast.success('Department created');
    setOpen(false);
    setNewDept({ name: '', code: '', hod: '' });
    const { data } = await supabase.from('departments').select('*').eq('org_id', orgId).order('name');
    setDepartments(data || []);
  };

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading departments...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Department Management</h1>
          <p className="text-sm text-muted-foreground">Manage hospital departments and staff allocation</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-1" /> Add Department</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Create Department</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Department Name</Label><Input placeholder="e.g. Neurology" value={newDept.name} onChange={e => setNewDept(p => ({ ...p, name: e.target.value }))} /></div>
              <div><Label>Code</Label><Input placeholder="e.g. NEURO" value={newDept.code} onChange={e => setNewDept(p => ({ ...p, code: e.target.value }))} /></div>
              <div><Label>Department Head</Label><Input placeholder="Head of Department" value={newDept.hod} onChange={e => setNewDept(p => ({ ...p, hod: e.target.value }))} /></div>
              <Button className="w-full" onClick={handleCreate}>Create Department</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card><CardContent className="p-4 flex items-center gap-3">
          <Building2 className="h-5 w-5 text-primary" />
          <div><p className="text-2xl font-bold">{departments.length}</p><p className="text-xs text-muted-foreground">Departments</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <Users className="h-5 w-5 text-info" />
          <div><p className="text-2xl font-bold">{totalStaff}</p><p className="text-xs text-muted-foreground">Total Staff</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <UserCheck className="h-5 w-5 text-success" />
          <div><p className="text-2xl font-bold">{totalDoctors}</p><p className="text-xs text-muted-foreground">Doctors</p></div>
        </CardContent></Card>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {departments.map(d => (
          <Card key={d.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{d.name}</CardTitle>
                <Badge variant={d.is_active ? 'default' : 'secondary'}>{d.is_active ? 'active' : 'inactive'}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">Code: {d.code} {d.hod ? `• Head: ${d.hod}` : ''}</p>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 text-sm">
                <div><span className="font-bold">{getDeptStaffCount(d.name)}</span> <span className="text-muted-foreground">Staff</span></div>
                <div><span className="font-bold">{getDeptDoctorCount(d.name)}</span> <span className="text-muted-foreground">Doctors</span></div>
              </div>
              <div className="flex gap-2 mt-3">
                <Button size="sm" variant="outline" className="flex-1">Edit</Button>
                <Button size="sm" variant="ghost">Manage Staff</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
