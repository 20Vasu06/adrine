import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Users, Plus, Search, UserCheck, UserX, Loader2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const DB_ROLE_LABELS: Record<string, string> = {
  org_admin: 'Admin',
  doctor: 'Doctor',
  nurse: 'Nurse',
  receptionist: 'Receptionist',
  lab_tech: 'Lab Tech',
  pharmacist: 'Pharmacist',
  billing_staff: 'Billing',
  radiologist: 'Radiologist',
  ot_coordinator: 'OT Coordinator',
  inventory_manager: 'Inventory Manager',
  emergency_staff: 'Emergency',
  hr_manager: 'HR Manager',
  scheduler: 'Scheduler',
  dialysis_tech: 'Dialysis Tech',
};

const INVITABLE_ROLES = Object.entries(DB_ROLE_LABELS).filter(([k]) => k !== 'org_admin' && k !== 'super_admin');

interface StaffMember {
  id: string;
  user_id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  department: string | null;
  is_active: boolean;
  roles: string[];
}

export default function AdminStaff() {
  const { user } = useAuth();
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Add staff dialog state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [newStaff, setNewStaff] = useState({
    fullName: '', email: '', password: '', role: '', department: '', phone: '',
  });

  const fetchStaff = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('id, user_id, full_name, email, phone, department, is_active')
        .eq('org_id', user.orgId);

      if (error) throw error;

      const { data: roles } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .eq('org_id', user.orgId);

      const roleMap = new Map<string, string[]>();
      (roles || []).forEach(r => {
        const existing = roleMap.get(r.user_id) || [];
        existing.push(r.role);
        roleMap.set(r.user_id, existing);
      });

      const staffList: StaffMember[] = (profiles || []).map(p => ({
        ...p,
        roles: roleMap.get(p.user_id) || [],
      }));

      setStaff(staffList);
    } catch (err) {
      console.error('Failed to fetch staff:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStaff(); }, [user]);

  const handleAddStaff = async () => {
    if (!newStaff.fullName || !newStaff.email || !newStaff.password || !newStaff.role) {
      toast.error('Please fill all required fields');
      return;
    }
    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke('invite-staff', {
        body: {
          fullName: newStaff.fullName,
          email: newStaff.email,
          password: newStaff.password,
          role: newStaff.role,
          department: newStaff.department,
          phone: newStaff.phone,
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success(`${newStaff.fullName} added successfully`);
      setNewStaff({ fullName: '', email: '', password: '', role: '', department: '', phone: '' });
      setDialogOpen(false);
      fetchStaff();
    } catch (err: any) {
      toast.error(err.message || 'Failed to add staff');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = staff.filter(s =>
    (search === '' || s.full_name.toLowerCase().includes(search.toLowerCase()) || (s.email || '').toLowerCase().includes(search.toLowerCase())) &&
    (roleFilter === 'all' || s.roles.includes(roleFilter)) &&
    (statusFilter === 'all' || (statusFilter === 'active' ? s.is_active : !s.is_active))
  );

  const activeCount = staff.filter(s => s.is_active).length;
  const inactiveCount = staff.filter(s => !s.is_active).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Staff Management</h1>
          <p className="text-sm text-muted-foreground">Manage all hospital users and staff accounts</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-1" /> Add Staff</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Register New Staff</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Full Name *</Label><Input placeholder="Enter name" value={newStaff.fullName} onChange={e => setNewStaff(p => ({ ...p, fullName: e.target.value }))} /></div>
                <div><Label>Email *</Label><Input type="email" placeholder="email@hospital.com" value={newStaff.email} onChange={e => setNewStaff(p => ({ ...p, email: e.target.value }))} /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Password *</Label><Input type="password" placeholder="Temporary password" value={newStaff.password} onChange={e => setNewStaff(p => ({ ...p, password: e.target.value }))} /></div>
                <div><Label>Phone</Label><Input placeholder="Phone number" value={newStaff.phone} onChange={e => setNewStaff(p => ({ ...p, phone: e.target.value }))} /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Role *</Label>
                  <Select value={newStaff.role} onValueChange={v => setNewStaff(p => ({ ...p, role: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger>
                    <SelectContent>
                      {INVITABLE_ROLES.map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Department</Label>
                  <Input placeholder="e.g. Cardiology" value={newStaff.department} onChange={e => setNewStaff(p => ({ ...p, department: e.target.value }))} />
                </div>
              </div>
              <Button className="w-full" onClick={handleAddStaff} disabled={submitting}>
                {submitting ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Creating...</> : 'Create Account'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card><CardContent className="p-4 flex items-center gap-3">
          <Users className="h-5 w-5 text-primary" />
          <div><p className="text-2xl font-bold">{staff.length}</p><p className="text-xs text-muted-foreground">Total Staff</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <UserCheck className="h-5 w-5 text-emerald-500" />
          <div><p className="text-2xl font-bold">{activeCount}</p><p className="text-xs text-muted-foreground">Active</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <UserX className="h-5 w-5 text-destructive" />
          <div><p className="text-2xl font-bold">{inactiveCount}</p><p className="text-xs text-muted-foreground">Inactive</p></div>
        </CardContent></Card>
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search by name or email..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Roles</SelectItem>
            {Object.entries(DB_ROLE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50 text-left text-muted-foreground">
                    <th className="p-3 font-medium">Name</th>
                    <th className="p-3 font-medium">Role(s)</th>
                    <th className="p-3 font-medium">Department</th>
                    <th className="p-3 font-medium">Email</th>
                    <th className="p-3 font-medium">Phone</th>
                    <th className="p-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">No staff found</td></tr>
                  ) : filtered.map(s => (
                    <tr key={s.id} className="border-b last:border-0 hover:bg-muted/30">
                      <td className="p-3 font-medium">{s.full_name}</td>
                      <td className="p-3">
                        <div className="flex gap-1 flex-wrap">
                          {s.roles.map(r => (
                            <Badge key={r} variant="outline" className="text-xs">{DB_ROLE_LABELS[r] || r}</Badge>
                          ))}
                        </div>
                      </td>
                      <td className="p-3 text-muted-foreground">{s.department || '—'}</td>
                      <td className="p-3 text-muted-foreground">{s.email || '—'}</td>
                      <td className="p-3 text-muted-foreground">{s.phone || '—'}</td>
                      <td className="p-3">
                        <Badge variant={s.is_active ? 'default' : 'secondary'}>{s.is_active ? 'Active' : 'Inactive'}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
