import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart3, Download, FileText, TrendingUp } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface ReportItem {
  name: string;
  description: string;
  lastGenerated: string;
  frequency: string;
  count?: number;
}

export default function AdminMIS() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [counts, setCounts] = useState({ patients: 0, appointments: 0, admissions: 0, invoices: 0, labOrders: 0, radOrders: 0, prescriptions: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('patients').select('id', { count: 'exact', head: true }).eq('org_id', orgId),
      supabase.from('appointments').select('id', { count: 'exact', head: true }).eq('org_id', orgId),
      supabase.from('admissions').select('id', { count: 'exact', head: true }).eq('org_id', orgId),
      supabase.from('invoices').select('id', { count: 'exact', head: true }).eq('org_id', orgId),
      supabase.from('lab_orders').select('id', { count: 'exact', head: true }).eq('org_id', orgId),
      supabase.from('radiology_orders').select('id', { count: 'exact', head: true }).eq('org_id', orgId),
      supabase.from('prescriptions').select('id', { count: 'exact', head: true }).eq('org_id', orgId),
    ]).then(([p, a, ad, inv, lab, rad, rx]) => {
      setCounts({
        patients: p.count || 0, appointments: a.count || 0, admissions: ad.count || 0,
        invoices: inv.count || 0, labOrders: lab.count || 0, radOrders: rad.count || 0, prescriptions: rx.count || 0,
      });
      setLoading(false);
    });
  }, [orgId]);

  const today = new Date().toISOString().split('T')[0];

  const REPORT_CATEGORIES = [
    {
      category: 'Operational Reports',
      reports: [
        { name: 'OPD Summary', description: `${counts.appointments} appointments total`, lastGenerated: today, frequency: 'Daily' },
        { name: 'IPD Census', description: `${counts.admissions} admissions total`, lastGenerated: today, frequency: 'Daily' },
        { name: 'Patient Registry', description: `${counts.patients} patients registered`, lastGenerated: today, frequency: 'Daily' },
      ],
    },
    {
      category: 'Financial Reports',
      reports: [
        { name: 'Revenue Collection', description: `${counts.invoices} invoices generated`, lastGenerated: today, frequency: 'Daily' },
        { name: 'Outstanding Receivables', description: 'Pending payments, aging analysis', lastGenerated: today, frequency: 'Weekly' },
      ],
    },
    {
      category: 'Clinical Reports',
      reports: [
        { name: 'Lab Orders Report', description: `${counts.labOrders} lab orders`, lastGenerated: today, frequency: 'Daily' },
        { name: 'Radiology Report', description: `${counts.radOrders} radiology orders`, lastGenerated: today, frequency: 'Daily' },
        { name: 'Pharmacy Dispensing', description: `${counts.prescriptions} prescriptions`, lastGenerated: today, frequency: 'Daily' },
      ],
    },
    {
      category: 'Compliance Reports',
      reports: [
        { name: 'Audit Trail Report', description: 'System-wide action log', lastGenerated: today, frequency: 'Daily' },
        { name: 'User Access Report', description: 'Login patterns, access violations', lastGenerated: today, frequency: 'Weekly' },
      ],
    },
  ];

  const filteredCategories = selectedCategory === 'all'
    ? REPORT_CATEGORIES
    : REPORT_CATEGORIES.filter(c => c.category === selectedCategory);

  const totalReports = REPORT_CATEGORIES.reduce((s, c) => s + c.reports.length, 0);

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">MIS Reports</h1>
          <p className="text-sm text-muted-foreground">Management Information System — hospital-wide analytics</p>
        </div>
        <Button variant="outline" onClick={() => toast.success('Export initiated')}><Download className="h-4 w-4 mr-1" /> Export All</Button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card><CardContent className="p-4 flex items-center gap-3">
          <FileText className="h-5 w-5 text-primary" />
          <div><p className="text-2xl font-bold">{totalReports}</p><p className="text-xs text-muted-foreground">Total Reports</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <BarChart3 className="h-5 w-5 text-blue-500" />
          <div><p className="text-2xl font-bold">{REPORT_CATEGORIES.length}</p><p className="text-xs text-muted-foreground">Categories</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <TrendingUp className="h-5 w-5 text-emerald-500" />
          <div><p className="text-2xl font-bold">{counts.patients}</p><p className="text-xs text-muted-foreground">Total Patients</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <FileText className="h-5 w-5 text-amber-500" />
          <div><p className="text-2xl font-bold">{counts.invoices}</p><p className="text-xs text-muted-foreground">Total Invoices</p></div>
        </CardContent></Card>
      </div>

      <Select value={selectedCategory} onValueChange={setSelectedCategory}>
        <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Categories</SelectItem>
          {REPORT_CATEGORIES.map(c => <SelectItem key={c.category} value={c.category}>{c.category}</SelectItem>)}
        </SelectContent>
      </Select>

      {filteredCategories.map(cat => (
        <Card key={cat.category}>
          <CardHeader><CardTitle className="text-base">{cat.category}</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-3">
              {cat.reports.map(r => (
                <div key={r.name} className="flex items-center justify-between border-b last:border-0 pb-3">
                  <div>
                    <p className="text-sm font-medium">{r.name}</p>
                    <p className="text-xs text-muted-foreground">{r.description}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="text-xs">{r.frequency}</Badge>
                    <span className="text-xs text-muted-foreground">{r.lastGenerated}</span>
                    <Button size="sm" variant="outline" onClick={() => toast.success(`${r.name} generated`)}><Download className="h-3 w-3 mr-1" /> Generate</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
