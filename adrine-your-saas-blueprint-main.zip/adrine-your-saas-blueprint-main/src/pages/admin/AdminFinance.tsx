import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function AdminFinance() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [tab, setTab] = useState<'overview' | 'cost' | 'doctor'>('overview');
  const [invoices, setInvoices] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('invoices').select('*').eq('org_id', orgId),
      supabase.from('profiles').select('full_name, designation, department').eq('org_id', orgId),
    ]).then(([invRes, profRes]) => {
      setInvoices(invRes.data || []);
      setProfiles(profRes.data || []);
      setLoading(false);
    });
  }, [orgId]);

  const totalRevenue = invoices.reduce((s, i) => s + i.total, 0);
  const totalPaid = invoices.reduce((s, i) => s + i.paid, 0);
  const totalOutstanding = totalRevenue - totalPaid;

  // Dept revenue from invoice categories
  const deptMap: Record<string, number> = {};
  invoices.forEach(inv => {
    const cat = inv.category || 'OPD';
    deptMap[cat] = (deptMap[cat] || 0) + inv.total;
  });
  const deptRevenue = Object.entries(deptMap).map(([dept, revenue]) => ({
    dept, revenue, percentage: totalRevenue > 0 ? Math.round((revenue / totalRevenue) * 100) : 0,
  })).sort((a, b) => b.revenue - a.revenue);

  // Doctor revenue from consultations invoices
  const doctorMap: Record<string, { consultations: number; revenue: number }> = {};
  // Group by unique doctors from profiles who have designation containing 'Dr'
  const doctors = profiles.filter(p => p.designation?.toLowerCase().includes('dr') || p.full_name?.startsWith('Dr'));
  
  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Finance Overview</h1>
        <p className="text-sm text-muted-foreground">Hospital financial performance & cost center analysis</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Revenue', value: `₹${totalRevenue.toLocaleString('en-IN')}` },
          { label: 'Collected', value: `₹${totalPaid.toLocaleString('en-IN')}` },
          { label: 'Outstanding', value: `₹${totalOutstanding.toLocaleString('en-IN')}` },
          { label: 'Invoices', value: String(invoices.length) },
        ].map(r => (
          <Card key={r.label}>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">{r.label}</p>
              <p className="text-xl font-bold mt-1">{r.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex gap-1 border-b pb-1">
        {(['overview', 'cost', 'doctor'] as const).map(t => (
          <Button key={t} size="sm" variant={tab === t ? 'default' : 'ghost'} onClick={() => setTab(t)}>
            {t === 'overview' ? 'Revenue by Category' : t === 'cost' ? 'Collection Summary' : 'Staff Overview'}
          </Button>
        ))}
      </div>

      {tab === 'overview' && (
        <Card>
          <CardHeader><CardTitle className="text-base">Category-wise Revenue</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {deptRevenue.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No revenue data yet</p>
            ) : deptRevenue.map(d => (
              <div key={d.dept} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{d.dept}</span>
                  <span>₹{d.revenue.toLocaleString('en-IN')} ({d.percentage}%)</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: `${d.percentage}%` }} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {tab === 'cost' && (
        <Card>
          <CardHeader><CardTitle className="text-base">Collection Summary</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {[
              { label: 'Paid Invoices', count: invoices.filter(i => i.status === 'paid').length, amount: invoices.filter(i => i.status === 'paid').reduce((s, i) => s + i.total, 0) },
              { label: 'Partial Payments', count: invoices.filter(i => i.status === 'partial').length, amount: invoices.filter(i => i.status === 'partial').reduce((s, i) => s + i.paid, 0) },
              { label: 'Pending Invoices', count: invoices.filter(i => i.status === 'pending').length, amount: invoices.filter(i => i.status === 'pending').reduce((s, i) => s + i.total, 0) },
            ].map(c => (
              <div key={c.label} className="flex items-center justify-between border-b last:border-0 pb-3">
                <div>
                  <p className="text-sm font-medium">{c.label}</p>
                  <p className="text-xs text-muted-foreground">{c.count} invoices</p>
                </div>
                <span className="font-semibold">₹{c.amount.toLocaleString('en-IN')}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {tab === 'doctor' && (
        <Card>
          <CardHeader><CardTitle className="text-base">Staff Directory</CardTitle></CardHeader>
          <CardContent>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-muted-foreground">
                  <th className="pb-2 font-medium">Name</th>
                  <th className="pb-2 font-medium">Designation</th>
                  <th className="pb-2 font-medium">Department</th>
                </tr>
              </thead>
              <tbody>
                {profiles.length === 0 ? (
                  <tr><td colSpan={3} className="py-8 text-center text-muted-foreground">No staff data</td></tr>
                ) : profiles.slice(0, 20).map((d, i) => (
                  <tr key={i} className="border-b last:border-0">
                    <td className="py-2 font-medium">{d.full_name}</td>
                    <td className="py-2 text-muted-foreground">{d.designation || '—'}</td>
                    <td className="py-2">{d.department || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
