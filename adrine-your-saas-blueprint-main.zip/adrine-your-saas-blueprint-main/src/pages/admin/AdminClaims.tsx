import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Search, FileText, Clock, CheckCircle, XCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function AdminClaims() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    // Use invoices with insurance-related data as claims proxy
    supabase.from('invoices').select('*').eq('org_id', orgId).order('created_at', { ascending: false })
      .then(({ data }) => { setInvoices(data || []); setLoading(false); });
  }, [orgId]);

  // Derive claims from invoices (insurance category)
  const claims = invoices.map(inv => ({
    id: inv.invoice_no,
    patient: inv.patient_name,
    claimAmount: inv.total,
    approvedAmount: inv.status === 'paid' ? inv.paid : 0,
    type: inv.category,
    status: inv.status === 'paid' ? 'settled' : inv.status === 'partial' ? 'approved' : 'pending',
    date: inv.date,
  }));

  const filtered = claims.filter(c =>
    (search === '' || c.patient.toLowerCase().includes(search.toLowerCase()) || c.id.toLowerCase().includes(search.toLowerCase())) &&
    (statusFilter === 'all' || c.status === statusFilter)
  );

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Insurance Claims</h1>
        <p className="text-sm text-muted-foreground">Track and manage insurance claims across all providers</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Claims', value: claims.length, icon: FileText, color: 'text-primary' },
          { label: 'Pending', value: claims.filter(c => c.status === 'pending').length, icon: Clock, color: 'text-amber-500' },
          { label: 'Approved/Settled', value: claims.filter(c => c.status === 'approved' || c.status === 'settled').length, icon: CheckCircle, color: 'text-emerald-500' },
          { label: 'Total Value', value: `₹${(claims.reduce((s, c) => s + c.claimAmount, 0)).toLocaleString('en-IN')}`, icon: FileText, color: 'text-primary' },
        ].map(s => (
          <Card key={s.label}><CardContent className="p-4 flex items-center gap-3">
            <s.icon className={`h-5 w-5 ${s.color}`} />
            <div><p className="text-2xl font-bold">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
          </CardContent></Card>
        ))}
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search claims..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            {['pending', 'approved', 'settled'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50 text-left text-muted-foreground">
                <th className="p-3 font-medium">Claim ID</th>
                <th className="p-3 font-medium">Patient</th>
                <th className="p-3 font-medium">Type</th>
                <th className="p-3 font-medium">Claim Amount</th>
                <th className="p-3 font-medium">Approved</th>
                <th className="p-3 font-medium">Status</th>
                <th className="p-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No claims found</td></tr>
              ) : filtered.map(c => (
                <tr key={c.id} className="border-b last:border-0 hover:bg-muted/30">
                  <td className="p-3 font-mono text-xs">{c.id}</td>
                  <td className="p-3 font-medium">{c.patient}</td>
                  <td className="p-3"><Badge variant="outline">{c.type}</Badge></td>
                  <td className="p-3 font-medium">₹{c.claimAmount.toLocaleString('en-IN')}</td>
                  <td className="p-3">{c.approvedAmount ? `₹${c.approvedAmount.toLocaleString('en-IN')}` : '—'}</td>
                  <td className="p-3">
                    <Badge variant={c.status === 'approved' || c.status === 'settled' ? 'default' : 'secondary'}>
                      {c.status}
                    </Badge>
                  </td>
                  <td className="p-3">
                    <Button size="sm" variant="ghost">View</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
