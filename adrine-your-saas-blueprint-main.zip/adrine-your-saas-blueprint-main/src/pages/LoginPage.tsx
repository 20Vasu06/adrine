import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Eye, EyeOff, ArrowRight, Building2, Loader2 } from 'lucide-react';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'login' | 'signup'>('login');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    setIsLoading(true);
    const { error } = await login(email, password);
    setIsLoading(false);
    if (error) {
      toast.error('Login failed', { description: error });
    }
    // Navigation happens automatically via auth state change
  };

  if (mode === 'signup') {
    return <SignupPage onBack={() => setMode('login')} />;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold tracking-tight text-foreground mb-2">ADRINE</h1>
          <p className="text-sm uppercase tracking-[0.3em] text-muted-foreground font-medium">
            Hospital Operating System
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="admin@hospital.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <motion.button
            type="submit"
            disabled={isLoading || !email || !password}
            whileTap={{ scale: 0.98 }}
            className="w-full py-3 rounded-lg font-semibold text-sm tracking-wide uppercase transition-all duration-200 bg-foreground text-background hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>Sign In <ArrowRight className="w-4 h-4" /></>
            )}
          </motion.button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => setMode('signup')}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-2"
          >
            <Building2 className="w-4 h-4" />
            Register your organization
          </button>
        </div>

        <p className="text-center text-[11px] text-muted-foreground mt-8">
          Powered by Adrine · adrine.in
        </p>
      </motion.div>
    </div>
  );
}

// ── Signup Component ──
const ORG_TYPES = [
  { value: 'clinic', label: 'Single Clinic' },
  { value: 'clinic_chain', label: 'Clinic Chain' },
  { value: 'hospital', label: 'Hospital' },
  { value: 'hospital_chain', label: 'Hospital Chain' },
  { value: 'dialysis_center', label: 'Dialysis Center' },
];

const MODULE_OPTIONS: { value: string; label: string; category: string }[] = [
  { value: 'reception', label: 'Reception & Registration', category: 'Core' },
  { value: 'doctor', label: 'Doctor / OPD', category: 'Core' },
  { value: 'nurse', label: 'Nursing', category: 'Core' },
  { value: 'lab', label: 'Laboratory', category: 'Diagnostics' },
  { value: 'pharmacy', label: 'Pharmacy', category: 'Diagnostics' },
  { value: 'radiology', label: 'Radiology', category: 'Diagnostics' },
  { value: 'billing', label: 'Billing & Finance', category: 'Finance' },
  { value: 'inventory', label: 'Inventory & Supply', category: 'Operations' },
  { value: 'ot', label: 'Operation Theatre', category: 'Clinical' },
  { value: 'emergency', label: 'Emergency / ER', category: 'Clinical' },
  { value: 'ipd', label: 'IPD / Admissions', category: 'Clinical' },
  { value: 'hr', label: 'HR & Staff Management', category: 'Admin' },
  { value: 'scheduling', label: 'Scheduling', category: 'Admin' },
  { value: 'dialysis', label: 'Dialysis Unit', category: 'Specialized' },
  { value: 'admin', label: 'Administration', category: 'Admin' },
  { value: 'reports', label: 'Reports & Analytics', category: 'Analytics' },
];

const DEFAULT_MODULES: Record<string, string[]> = {
  clinic: ['reception', 'doctor', 'billing', 'pharmacy', 'lab', 'scheduling', 'reports'],
  clinic_chain: ['reception', 'doctor', 'billing', 'pharmacy', 'lab', 'scheduling', 'reports', 'admin', 'hr'],
  hospital: ['reception', 'doctor', 'nurse', 'lab', 'pharmacy', 'radiology', 'billing', 'inventory', 'ot', 'emergency', 'ipd', 'hr', 'scheduling', 'admin', 'reports'],
  hospital_chain: ['reception', 'doctor', 'nurse', 'lab', 'pharmacy', 'radiology', 'billing', 'inventory', 'ot', 'emergency', 'ipd', 'hr', 'scheduling', 'admin', 'reports'],
  dialysis_center: ['reception', 'doctor', 'dialysis', 'billing', 'inventory', 'scheduling', 'reports'],
};

function SignupPage({ onBack }: { onBack: () => void }) {
  const { signup } = useAuth();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  const [orgName, setOrgName] = useState('');
  const [orgSlug, setOrgSlug] = useState('');
  const [orgType, setOrgType] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [modules, setModules] = useState<string[]>([]);

  const handleOrgTypeSelect = (type: string) => {
    setOrgType(type);
    setModules(DEFAULT_MODULES[type] || []);
  };

  const toggleModule = (mod: string) => {
    setModules((prev) =>
      prev.includes(mod) ? prev.filter((m) => m !== mod) : [...prev, mod]
    );
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    const slug = orgSlug || orgName.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
    const { error } = await signup({
      orgName, orgSlug: slug, orgType, fullName, email, password,
      modules: ['dashboard', ...modules],
    });
    setIsLoading(false);
    if (error) {
      toast.error('Registration failed', { description: error });
    } else {
      toast.success('Organization registered!', { description: 'Welcome to Adrine' });
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight text-foreground mb-2">Register Organization</h1>
          <p className="text-sm text-muted-foreground">Step {step} of 3</p>
          <div className="flex gap-1 justify-center mt-3">
            {[1, 2, 3].map((s) => (
              <div key={s} className={`h-1 w-16 rounded-full transition-colors ${s <= step ? 'bg-foreground' : 'bg-muted'}`} />
            ))}
          </div>
        </div>

        {step === 1 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
            <div className="space-y-2">
              <Label>Organization Name</Label>
              <Input placeholder="City Hospital" value={orgName} onChange={(e) => { setOrgName(e.target.value); setOrgSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, '-')); }} required />
            </div>
            <div className="space-y-2">
              <Label>URL Slug</Label>
              <Input placeholder="city-hospital" value={orgSlug} onChange={(e) => setOrgSlug(e.target.value)} />
              <p className="text-xs text-muted-foreground">app.adrine.in/{orgSlug || 'your-org'}</p>
            </div>
            <div className="space-y-2">
              <Label>Organization Type</Label>
              <div className="grid grid-cols-2 gap-2">
                {ORG_TYPES.map((t) => (
                  <button
                    key={t.value}
                    onClick={() => handleOrgTypeSelect(t.value)}
                    className={`p-3 rounded-lg border text-sm font-medium transition-all ${
                      orgType === t.value
                        ? 'border-foreground bg-foreground text-background'
                        : 'border-border hover:border-foreground/30'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={() => setStep(2)}
              disabled={!orgName || !orgType}
              className="w-full py-3 rounded-lg font-semibold text-sm bg-foreground text-background hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next: Select Modules
            </button>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
            <p className="text-sm text-muted-foreground">Select the modules you need. You can change this later.</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {MODULE_OPTIONS.map((m) => (
                <button
                  key={m.value}
                  onClick={() => toggleModule(m.value)}
                  className={`p-3 rounded-lg border text-left text-sm transition-all ${
                    modules.includes(m.value)
                      ? 'border-foreground bg-foreground text-background'
                      : 'border-border hover:border-foreground/30'
                  }`}
                >
                  <span className="font-medium">{m.label}</span>
                  <span className={`block text-[10px] mt-0.5 ${modules.includes(m.value) ? 'text-background/60' : 'text-muted-foreground'}`}>
                    {m.category}
                  </span>
                </button>
              ))}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setStep(1)} className="flex-1 py-3 rounded-lg font-semibold text-sm border border-border hover:bg-accent">Back</button>
              <button
                onClick={() => setStep(3)}
                disabled={modules.length === 0}
                className="flex-1 py-3 rounded-lg font-semibold text-sm bg-foreground text-background hover:opacity-90 disabled:opacity-50"
              >
                Next: Admin Account
              </button>
            </div>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
            <div className="space-y-2">
              <Label>Your Full Name</Label>
              <Input placeholder="Dr. Rajesh Sharma" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" placeholder="admin@hospital.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" placeholder="Min 6 characters" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <div className="rounded-lg border p-4 bg-muted/30 space-y-1">
              <p className="text-sm font-medium">{orgName}</p>
              <p className="text-xs text-muted-foreground">{ORG_TYPES.find(t => t.value === orgType)?.label} · {modules.length} modules</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setStep(2)} className="flex-1 py-3 rounded-lg font-semibold text-sm border border-border hover:bg-accent">Back</button>
              <button
                onClick={handleSubmit}
                disabled={isLoading || !fullName || !email || !password}
                className="flex-1 py-3 rounded-lg font-semibold text-sm bg-foreground text-background hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Organization'}
              </button>
            </div>
          </motion.div>
        )}

        <div className="mt-6 text-center">
          <button onClick={onBack} className="text-sm text-muted-foreground hover:text-foreground">
            Already have an account? Sign in
          </button>
        </div>
      </motion.div>
    </div>
  );
}
