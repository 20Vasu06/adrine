import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BedDouble, Search, X, UserPlus, Activity, Clock, MapPin } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface BedData {
  id: string;
  bed_no: string;
  ward: string;
  bed_type: string;
  is_occupied: boolean;
  patient_id: string | null;
}

const statusColors: Record<string, { bg: string; label: string; dot: string }> = {
  available: { bg: 'border-success/40 bg-success/5', label: 'Available', dot: 'bg-success' },
  occupied: { bg: 'border-destructive/30 bg-destructive/5', label: 'Occupied', dot: 'bg-destructive' },
};

export default function ReceptionBeds() {
  const { user } = useAuth();
  const [beds, setBeds] = useState<BedData[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selectedBed, setSelectedBed] = useState<BedData | null>(null);

  useEffect(() => {
    if (!user?.orgId) return;
    const fetchBeds = async () => {
      setLoading(true);
      const { data } = await supabase.from('beds').select('*').eq('org_id', user.orgId);
      setBeds(data || []);
      setLoading(false);
    };
    fetchBeds();

    const channel = supabase.channel('beds-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'beds' }, () => fetchBeds())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.orgId]);

  const wards = [...new Set(beds.map(b => b.ward))];
  const counts = {
    total: beds.length,
    available: beds.filter(b => !b.is_occupied).length,
    occupied: beds.filter(b => b.is_occupied).length,
  };

  const filteredBeds = beds.filter(b => {
    const status = b.is_occupied ? 'occupied' : 'available';
    const matchFilter = filter === 'all' || filter === status;
    const matchSearch = !search || b.bed_no.toLowerCase().includes(search.toLowerCase()) || b.ward.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Bed Management</h1>
          <p className="text-sm text-muted-foreground mt-1">{counts.available} of {counts.total} beds available{counts.total > 0 ? ` · ${Math.round((counts.occupied / counts.total) * 100)}% occupancy` : ''}</p>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <div className="rounded-xl border p-4 border-border">
          <div className="flex items-center gap-2 mb-1">
            <BedDouble className="w-4 h-4 text-muted-foreground" />
            <p className="text-xs text-muted-foreground">Total</p>
          </div>
          <p className="text-2xl font-bold">{counts.total}</p>
        </div>
        {Object.entries(statusColors).map(([status, config]) => (
          <div key={status} className={`rounded-xl border p-4 ${config.bg}`}>
            <div className="flex items-center gap-2 mb-1">
              <div className={`w-2.5 h-2.5 rounded-full ${config.dot}`} />
              <p className="text-xs text-muted-foreground">{config.label}</p>
            </div>
            <p className="text-2xl font-bold">{status === 'available' ? counts.available : counts.occupied}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border bg-card text-sm" placeholder="Search beds or wards..." />
        </div>
        <div className="flex gap-1.5">
          {['all', 'available', 'occupied'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filter === f ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <p className="text-center py-8 text-sm text-muted-foreground animate-pulse">Loading beds...</p>
      ) : beds.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <BedDouble className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No beds configured. Add beds from admin settings.</p>
        </div>
      ) : (
        wards.map(ward => {
          const wardBeds = filteredBeds.filter(b => b.ward === ward);
          if (wardBeds.length === 0) return null;
          return (
            <div key={ward}>
              <div className="flex items-center gap-2 mb-3">
                <h2 className="font-semibold">{ward}</h2>
                <span className="text-xs text-muted-foreground ml-auto">
                  {wardBeds.filter(b => !b.is_occupied).length}/{wardBeds.length} available
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {wardBeds.map((bed, i) => {
                  const status = bed.is_occupied ? 'occupied' : 'available';
                  return (
                    <motion.div key={bed.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.02 }}
                      onClick={() => setSelectedBed(bed)}
                      className={`rounded-xl border p-3 cursor-pointer hover:shadow-md transition-all ${statusColors[status].bg}`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-bold">{bed.bed_no}</span>
                        <BedDouble className="w-4 h-4 text-muted-foreground" />
                      </div>
                      <p className="text-xs text-muted-foreground">{bed.bed_type} · {statusColors[status].label}</p>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          );
        })
      )}

      {/* Bed Detail Modal */}
      <AnimatePresence>
        {selectedBed && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setSelectedBed(null)}>
            <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
              className="bg-card border rounded-xl w-full max-w-md p-6 space-y-4" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold">{selectedBed.bed_no}</h2>
                  <p className="text-xs text-muted-foreground">{selectedBed.ward} · {selectedBed.bed_type}</p>
                </div>
                <button onClick={() => setSelectedBed(null)} className="p-1 rounded hover:bg-accent"><X className="w-5 h-5" /></button>
              </div>
              <div className={`text-sm px-3 py-2 rounded-lg ${statusColors[selectedBed.is_occupied ? 'occupied' : 'available'].bg}`}>
                Status: <span className="font-semibold">{selectedBed.is_occupied ? 'Occupied' : 'Available'}</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
