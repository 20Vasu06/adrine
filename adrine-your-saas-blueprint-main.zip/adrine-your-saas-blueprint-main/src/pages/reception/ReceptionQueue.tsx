import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Monitor, Users, Clock, AlertTriangle, SkipForward, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const statusStyles: Record<string, string> = {
  'in_consultation': 'bg-success/10 text-success border-success/30',
  called: 'bg-primary/10 text-primary border-primary/30',
  waiting: 'bg-muted text-muted-foreground border-border',
  completed: 'bg-muted/50 text-muted-foreground border-border opacity-50',
  skipped: 'bg-warning/10 text-warning border-warning/30',
};

const statusLabels: Record<string, string> = {
  'in_consultation': '🟢 In Consultation',
  called: '🔵 Called',
  waiting: 'Waiting',
  completed: 'Completed',
  skipped: '⚠️ Skipped',
};

export default function ReceptionQueue() {
  const { user } = useAuth();
  const [queue, setQueue] = useState<any[]>([]);
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [tvMode, setTvMode] = useState(false);

  const fetchQueue = async () => {
    if (!user?.orgId) return;
    const { data } = await supabase.from('queue_entries').select('*').eq('org_id', user.orgId).order('token_no', { ascending: true });
    setQueue(data || []);
  };

  useEffect(() => {
    fetchQueue();
    if (!user?.orgId) return;
    const channel = supabase.channel('queue-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'queue_entries' }, () => fetchQueue())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.orgId]);

  const updateStatus = async (id: string, status: string) => {
    await supabase.from('queue_entries').update({ status: status as any }).eq('id', id);
    toast.success(`Queue updated`);
    fetchQueue();
  };

  const departments = [...new Set(queue.map(q => q.department))];
  const getQueueByDept = (dept: string) => queue.filter(q => q.department === dept);

  const totalWaiting = queue.filter(q => q.status === 'waiting' || q.status === 'called').length;
  const totalInConsultation = queue.filter(q => q.status === 'in_consultation').length;
  const totalSkipped = queue.filter(q => q.status === 'skipped').length;

  if (tvMode) {
    return (
      <div className="fixed inset-0 bg-background z-50 p-8 overflow-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">OPD Queue Display</h1>
          <button onClick={() => setTvMode(false)} className="px-4 py-2 rounded-lg border text-sm font-medium hover:bg-accent">
            <X className="w-4 h-4 inline mr-2" /> Exit TV Mode
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {departments.map(dept => {
            const deptQueue = getQueueByDept(dept).filter(q => q.status !== 'completed');
            const current = deptQueue.find(q => q.status === 'in_consultation');
            const called = deptQueue.find(q => q.status === 'called');
            return (
              <div key={dept} className="rounded-xl border bg-card p-6">
                <h2 className="text-xl font-bold mb-4">{dept}</h2>
                {current && (
                  <div className="rounded-lg bg-success/10 border border-success/30 p-4 mb-3">
                    <p className="text-xs text-success font-semibold uppercase">Now Serving</p>
                    <p className="text-3xl font-bold mt-1">{current.token_no}</p>
                    <p className="text-sm">{current.patient_name}</p>
                  </div>
                )}
                {called && (
                  <div className="rounded-lg bg-primary/10 border border-primary/30 p-4 mb-3">
                    <p className="text-xs text-primary font-semibold uppercase">Please Proceed</p>
                    <p className="text-3xl font-bold mt-1">{called.token_no}</p>
                    <p className="text-sm">{called.patient_name}</p>
                  </div>
                )}
                <div className="space-y-1 mt-3">
                  <p className="text-xs text-muted-foreground font-semibold uppercase">Waiting</p>
                  {deptQueue.filter(q => q.status === 'waiting').map(q => (
                    <div key={q.id} className="flex items-center justify-between text-sm py-1">
                      <span className="font-mono font-bold">{q.token_no}</span>
                      <span>{q.patient_name}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">OPD Queue</h1>
          <p className="text-sm text-muted-foreground mt-1">Live queue status across all departments</p>
        </div>
        <button onClick={() => setTvMode(true)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border text-sm font-medium hover:bg-accent transition-colors">
          <Monitor className="w-4 h-4" /> TV Display
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="rounded-xl border bg-card p-4 text-center">
          <Users className="w-5 h-5 mx-auto text-muted-foreground mb-1" />
          <p className="text-2xl font-bold">{totalWaiting}</p>
          <p className="text-xs text-muted-foreground">In Queue</p>
        </div>
        <div className="rounded-xl border bg-card p-4 text-center">
          <Clock className="w-5 h-5 mx-auto text-muted-foreground mb-1" />
          <p className="text-2xl font-bold">{queue.length}</p>
          <p className="text-xs text-muted-foreground">Total Tokens</p>
        </div>
        <div className="rounded-xl border bg-card p-4 text-center">
          <Users className="w-5 h-5 mx-auto text-success mb-1" />
          <p className="text-2xl font-bold">{totalInConsultation}</p>
          <p className="text-xs text-muted-foreground">Being Seen</p>
        </div>
        <div className="rounded-xl border bg-card p-4 text-center">
          <AlertTriangle className="w-5 h-5 mx-auto text-warning mb-1" />
          <p className="text-2xl font-bold">{totalSkipped}</p>
          <p className="text-xs text-muted-foreground">Skipped</p>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto">
        <button onClick={() => setSelectedDept('all')}
          className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${selectedDept === 'all' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
          All Departments
        </button>
        {departments.map(d => (
          <button key={d} onClick={() => setSelectedDept(d)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${selectedDept === d ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
            {d}
          </button>
        ))}
      </div>

      {queue.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Users className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No patients in queue. Check in patients from the Check-In page.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {departments.filter(d => selectedDept === 'all' || selectedDept === d).map(dept => {
            const deptQueue = getQueueByDept(dept);
            return (
              <div key={dept}>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-semibold">{dept}</h2>
                  <span className="text-xs text-muted-foreground">{deptQueue.filter(q => q.status !== 'completed').length} active</span>
                </div>
                <div className="space-y-2">
                  {deptQueue.map((entry, i) => (
                    <motion.div key={entry.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
                      className={`rounded-xl border p-4 flex items-center justify-between ${statusStyles[entry.status] || 'bg-muted'}`}>
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold ${
                          entry.status === 'in_consultation' ? 'bg-success/20' : entry.status === 'called' ? 'bg-primary/20' : entry.status === 'skipped' ? 'bg-warning/20' : 'bg-muted'
                        }`}>
                          {entry.token_no}
                        </div>
                        <div>
                          <p className="text-sm font-semibold">{entry.patient_name}</p>
                          <p className="text-xs opacity-70">{entry.doctor} · {new Date(entry.checked_in_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <p className="text-sm font-medium">{statusLabels[entry.status] || entry.status}</p>
                        {(entry.status === 'waiting' || entry.status === 'skipped') && (
                          <button onClick={() => updateStatus(entry.id, 'skipped')} className="p-1.5 rounded-lg hover:bg-accent border" title="Skip token">
                            <SkipForward className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
