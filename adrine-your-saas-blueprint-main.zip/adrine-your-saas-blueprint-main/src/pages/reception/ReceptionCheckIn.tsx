import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, CheckCircle2, Clock, UserCheck, Hash } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { toast } from 'sonner';

const statusConfig: Record<string, { label: string; color: string }> = {
  waiting: { label: 'Waiting', color: 'bg-warning/10 text-warning' },
  called: { label: 'Called', color: 'bg-info/10 text-info' },
  in_consultation: { label: 'With Doctor', color: 'bg-success/10 text-success' },
  completed: { label: 'Completed', color: 'bg-muted text-muted-foreground' },
  skipped: { label: 'Skipped', color: 'bg-warning/10 text-warning' },
};

export default function ReceptionCheckIn() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<any[]>([]);
  const [queue, setQueue] = useState<any[]>([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!user?.orgId) return;
    const today = format(new Date(), 'yyyy-MM-dd');
    Promise.all([
      supabase.from('appointments').select('*').eq('org_id', user.orgId).eq('date', today),
      supabase.from('queue_entries').select('*').eq('org_id', user.orgId),
    ]).then(([a, q]) => {
      setAppointments(a.data || []);
      setQueue(q.data || []);
    });
  }, [user?.orgId]);

  const checkInList = appointments.map(appt => {
    const queueEntry = queue.find(q => q.appointment_id === appt.id);
    return {
      ...appt,
      queueStatus: queueEntry?.status || null,
      tokenNo: queueEntry?.token_no,
    };
  });

  const filtered = checkInList.filter(p =>
    p.patient_name.toLowerCase().includes(search.toLowerCase()) || p.appointment_no.includes(search)
  );

  const counts = {
    pending: checkInList.filter(p => !p.queueStatus && p.status !== 'completed' && p.status !== 'cancelled').length,
    inQueue: checkInList.filter(p => p.queueStatus === 'waiting' || p.queueStatus === 'called').length,
    withDoctor: checkInList.filter(p => p.queueStatus === 'in_consultation').length,
    completed: checkInList.filter(p => p.queueStatus === 'completed' || p.status === 'completed').length,
  };

  const handleCheckIn = async (appt: any) => {
    if (!user?.orgId) return;
    const maxToken = queue.reduce((max, q) => Math.max(max, q.token_no || 0), 0);
    const { error } = await supabase.from('queue_entries').insert({
      org_id: user.orgId,
      patient_id: appt.patient_id,
      patient_name: appt.patient_name,
      doctor: appt.doctor,
      department: appt.department,
      token_no: maxToken + 1,
      appointment_id: appt.id,
      complaint: appt.notes || '',
    });
    if (error) { toast.error('Check-in failed'); return; }
    await supabase.from('appointments').update({ status: 'checked-in' as any }).eq('id', appt.id);
    toast.success(`${appt.patient_name} checked in — Token #${maxToken + 1}`);
    // Refresh
    const today = format(new Date(), 'yyyy-MM-dd');
    const [a, q] = await Promise.all([
      supabase.from('appointments').select('*').eq('org_id', user.orgId).eq('date', today),
      supabase.from('queue_entries').select('*').eq('org_id', user.orgId),
    ]);
    setAppointments(a.data || []);
    setQueue(q.data || []);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Patient Check-In</h1>
        <p className="text-sm text-muted-foreground mt-1">Confirm arrival and assign queue tokens</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl border p-4 flex items-center gap-3">
          <Clock className="w-5 h-5 text-warning" />
          <div><p className="text-xl font-bold">{counts.pending}</p><p className="text-xs text-muted-foreground">Pending Check-in</p></div>
        </div>
        <div className="rounded-xl border p-4 flex items-center gap-3">
          <UserCheck className="w-5 h-5 text-info" />
          <div><p className="text-xl font-bold">{counts.inQueue}</p><p className="text-xs text-muted-foreground">In Queue</p></div>
        </div>
        <div className="rounded-xl border p-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-success" />
          <div><p className="text-xl font-bold">{counts.withDoctor}</p><p className="text-xs text-muted-foreground">With Doctor</p></div>
        </div>
        <div className="rounded-xl border p-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-muted-foreground" />
          <div><p className="text-xl font-bold">{counts.completed}</p><p className="text-xs text-muted-foreground">Completed</p></div>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border bg-card text-sm" placeholder="Search by patient name or appointment ID..." />
      </div>

      {checkInList.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Clock className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No appointments today.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((p, i) => {
            const qStatus = p.queueStatus;
            const config = qStatus ? statusConfig[qStatus] : null;
            const canCheckIn = !qStatus && p.status !== 'completed' && p.status !== 'cancelled';

            return (
              <motion.div key={p.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
                className="rounded-xl border bg-card p-4 hover:bg-accent/30 transition-colors">
                <div className="flex items-start justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-sm font-semibold">
                      {p.patient_name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold">{p.patient_name}</p>
                        {p.tokenNo && <span className="text-xs px-1.5 py-0.5 rounded bg-muted font-mono">#{p.tokenNo}</span>}
                        <span className="text-xs px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground">{p.type}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{p.appointment_no} · {p.doctor} · {p.department}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="text-right hidden sm:block">
                      <p className="text-sm font-medium flex items-center gap-1"><Clock className="w-3 h-3" /> {p.time}</p>
                    </div>
                    {config && (
                      <span className={`text-xs px-2.5 py-1 rounded-full flex items-center gap-1 ${config.color}`}>{config.label}</span>
                    )}
                    {canCheckIn && (
                      <button onClick={() => handleCheckIn(p)}
                        className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 transition-colors flex items-center gap-1">
                        <Hash className="w-3 h-3" /> Check In
                      </button>
                    )}
                    {p.status === 'cancelled' && (
                      <span className="text-xs px-2.5 py-1 rounded-full bg-destructive/10 text-destructive">Cancelled</span>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
