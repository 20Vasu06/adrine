import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, UserPlus, BedDouble, Clock, Activity, X, FileText, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface Admission {
  id: string;
  admission_no: string;
  patient_name: string;
  patient_id: string;
  department: string;
  doctor: string;
  diagnosis: string | null;
  status: string;
  admission_date: string;
  discharge_date: string | null;
  bed_id: string | null;
}

const statusStyles: Record<string, string> = {
  admitted: 'bg-success/10 text-success',
  'discharge-pending': 'bg-warning/10 text-warning',
  discharged: 'bg-muted text-muted-foreground',
};

export default function ReceptionIPD() {
  const { user } = useAuth();
  const [admissions, setAdmissions] = useState<Admission[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [selectedAdmission, setSelectedAdmission] = useState<Admission | null>(null);

  useEffect(() => {
    if (!user?.orgId) return;
    const fetch = async () => {
      setLoading(true);
      const { data } = await supabase.from('admissions').select('*').eq('org_id', user.orgId).order('admission_date', { ascending: false });
      setAdmissions(data || []);
      setLoading(false);
    };
    fetch();

    const channel = supabase.channel('admissions-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'admissions' }, () => fetch())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.orgId]);

  const filtered = admissions.filter(a => {
    const matchSearch = a.patient_name.toLowerCase().includes(search.toLowerCase()) || a.admission_no.includes(search);
    const matchFilter = filter === 'all' || a.status === filter;
    return matchSearch && matchFilter;
  });

  const activeCount = admissions.filter(a => a.status === 'admitted').length;
  const dischargePending = admissions.filter(a => a.status === 'discharge-pending').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">IPD Admissions</h1>
          <p className="text-sm text-muted-foreground mt-1">{activeCount} active · {dischargePending} discharge pending</p>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border bg-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center"><Activity className="w-5 h-5 text-success" /></div>
          <div><p className="text-xl font-bold">{activeCount}</p><p className="text-xs text-muted-foreground">Active</p></div>
        </div>
        <div className="rounded-xl border bg-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center"><Clock className="w-5 h-5 text-warning" /></div>
          <div><p className="text-xl font-bold">{dischargePending}</p><p className="text-xs text-muted-foreground">Discharge Pending</p></div>
        </div>
        <div className="rounded-xl border bg-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center"><FileText className="w-5 h-5 text-muted-foreground" /></div>
          <div><p className="text-xl font-bold">{admissions.length}</p><p className="text-xs text-muted-foreground">Total</p></div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border bg-card text-sm" placeholder="Search by name or admission ID..." />
        </div>
        <div className="flex gap-1.5">
          {['all', 'admitted', 'discharge-pending', 'discharged'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${filter === f ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {f === 'all' ? 'All' : f === 'discharge-pending' ? 'Discharge Pending' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Admissions Table */}
      {loading ? (
        <p className="text-center py-8 text-sm text-muted-foreground animate-pulse">Loading admissions...</p>
      ) : admissions.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <BedDouble className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No admissions yet</p>
        </div>
      ) : (
        <div className="rounded-xl border bg-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-muted/30">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Patient</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden sm:table-cell">Department</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden md:table-cell">Doctor</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden md:table-cell">Admitted</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map((a, i) => (
                <motion.tr key={a.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                  className="hover:bg-accent/50 transition-colors cursor-pointer" onClick={() => setSelectedAdmission(a)}>
                  <td className="px-4 py-3">
                    <p className="text-sm font-medium">{a.patient_name}</p>
                    <p className="text-xs text-muted-foreground">{a.admission_no}</p>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground hidden sm:table-cell">{a.department}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground hidden md:table-cell">{a.doctor}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground hidden md:table-cell">{new Date(a.admission_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${statusStyles[a.status] || 'bg-muted text-muted-foreground'}`}>{a.status}</span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Admission Detail Modal */}
      <AnimatePresence>
        {selectedAdmission && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setSelectedAdmission(null)}>
            <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
              className="bg-card border rounded-xl w-full max-w-lg p-6 space-y-4" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold">{selectedAdmission.patient_name}</h2>
                  <p className="text-xs text-muted-foreground">{selectedAdmission.admission_no}</p>
                </div>
                <button onClick={() => setSelectedAdmission(null)} className="p-1 rounded hover:bg-accent"><X className="w-5 h-5" /></button>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted-foreground">Department:</span> {selectedAdmission.department}</div>
                <div><span className="text-muted-foreground">Doctor:</span> {selectedAdmission.doctor}</div>
                <div><span className="text-muted-foreground">Diagnosis:</span> {selectedAdmission.diagnosis || '—'}</div>
                <div><span className="text-muted-foreground">Admitted:</span> {new Date(selectedAdmission.admission_date).toLocaleDateString('en-IN')}</div>
                <div><span className="text-muted-foreground">Status:</span> <span className={`px-1.5 py-0.5 rounded-full text-xs ${statusStyles[selectedAdmission.status] || 'bg-muted text-muted-foreground'}`}>{selectedAdmission.status}</span></div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
