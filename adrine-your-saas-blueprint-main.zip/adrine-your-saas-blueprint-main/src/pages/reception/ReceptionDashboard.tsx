import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, CalendarCheck, Clock, BedDouble, UserPlus, ArrowRight, Activity, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';

export default function ReceptionDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [patients, setPatients] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [queue, setQueue] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.orgId) return;
    const orgId = user.orgId;
    setLoading(true);
    Promise.all([
      supabase.from('patients').select('*').eq('org_id', orgId).order('created_at', { ascending: false }).limit(20),
      supabase.from('appointments').select('*').eq('org_id', orgId).eq('date', format(new Date(), 'yyyy-MM-dd')),
      supabase.from('queue_entries').select('*').eq('org_id', orgId).order('checked_in_at', { ascending: true }),
      supabase.from('invoices').select('*').eq('org_id', orgId).order('date', { ascending: false }).limit(20),
    ]).then(([p, a, q, i]) => {
      setPatients(p.data || []);
      setAppointments(a.data || []);
      setQueue(q.data || []);
      setInvoices(i.data || []);
      setLoading(false);
    });
  }, [user?.orgId]);

  const activeQueue = queue.filter(q => q.status === 'waiting' || q.status === 'called');

  const stats = [
    { label: "Today's Registrations", value: patients.length.toString(), change: 'All patients', icon: UserPlus, trend: 'up' as const },
    { label: 'Appointments', value: appointments.length.toString(), change: `${appointments.filter(a => a.status === 'scheduled').length} remaining`, icon: CalendarCheck, trend: 'neutral' as const },
    { label: 'In Queue', value: activeQueue.length.toString(), change: `${queue.filter(q => q.status === 'waiting').length} waiting`, icon: Clock, trend: activeQueue.length > 5 ? 'warning' as const : 'neutral' as const },
    { label: 'Invoices', value: invoices.length.toString(), change: `${invoices.filter(i => i.status === 'paid').length} paid`, icon: BedDouble, trend: 'neutral' as const },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reception Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">{format(new Date(), 'EEEE, d MMMM yyyy')}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => navigate('/reception/registration?mode=emergency')}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border-2 border-destructive/30 text-destructive text-sm font-medium hover:bg-destructive/10 transition-colors">
            <Zap className="w-4 h-4" /> Emergency
          </button>
          <button onClick={() => navigate('/reception/registration')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
            <UserPlus className="w-4 h-4" /> New Registration
          </button>
        </div>
      </div>

      {loading && <p className="text-sm text-muted-foreground animate-pulse">Loading data...</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            className="rounded-xl border bg-card p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-muted-foreground">{s.label}</span>
              <s.icon className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold">{s.value}</div>
            <p className={`text-xs mt-1 ${s.trend === 'warning' ? 'text-warning' : s.trend === 'up' ? 'text-success' : 'text-muted-foreground'}`}>{s.change}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button onClick={() => navigate('/reception/registration')} className="rounded-xl border p-4 hover:bg-accent/50 transition-colors text-left">
          <UserPlus className="w-5 h-5 text-primary mb-2" />
          <p className="text-sm font-semibold">Register Patient</p>
          <p className="text-xs text-muted-foreground">New OPD / IPD</p>
        </button>
        <button onClick={() => navigate('/reception/appointments')} className="rounded-xl border p-4 hover:bg-accent/50 transition-colors text-left">
          <CalendarCheck className="w-5 h-5 text-primary mb-2" />
          <p className="text-sm font-semibold">Book Appointment</p>
          <p className="text-xs text-muted-foreground">Schedule visits</p>
        </button>
        <button onClick={() => navigate('/reception/checkin')} className="rounded-xl border p-4 hover:bg-accent/50 transition-colors text-left">
          <Clock className="w-5 h-5 text-muted-foreground mb-2" />
          <p className="text-sm font-semibold">Check-In</p>
          <p className="text-xs text-muted-foreground">{activeQueue.length} in queue</p>
        </button>
        <button onClick={() => navigate('/reception/beds')} className="rounded-xl border p-4 hover:bg-accent/50 transition-colors text-left">
          <BedDouble className="w-5 h-5 text-muted-foreground mb-2" />
          <p className="text-sm font-semibold">Bed Management</p>
          <p className="text-xs text-muted-foreground">View availability</p>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="rounded-xl border bg-card lg:col-span-2">
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="font-semibold">Recent Patients</h2>
            <button onClick={() => navigate('/reception/registration')} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="divide-y">
            {patients.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">No patients registered yet</div>
            ) : patients.slice(0, 5).map(p => (
              <div key={p.id} className="flex items-center justify-between px-4 py-3 hover:bg-accent/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold bg-muted">
                    {p.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{p.name}</p>
                    <p className="text-xs text-muted-foreground">{p.uhid} · {p.age}{p.gender} · {p.department || 'General'}</p>
                  </div>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{p.patient_type}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border bg-card">
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="font-semibold">Upcoming Appointments</h2>
            <button onClick={() => navigate('/reception/appointments')} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="divide-y">
            {appointments.filter(a => a.status === 'scheduled' || a.status === 'confirmed').length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">No upcoming appointments</div>
            ) : appointments.filter(a => a.status === 'scheduled' || a.status === 'confirmed').slice(0, 4).map(a => (
              <div key={a.id} className="flex items-center justify-between px-4 py-3 hover:bg-accent/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="text-sm font-mono font-medium w-16">{a.time}</div>
                  <div>
                    <p className="text-sm font-medium">{a.patient_name}</p>
                    <p className="text-xs text-muted-foreground">{a.doctor} · {a.type}</p>
                  </div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full ${a.status === 'confirmed' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'}`}>{a.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {activeQueue.length > 0 && (
        <div className="rounded-xl border bg-card">
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="font-semibold flex items-center gap-2"><Activity className="w-4 h-4" /> Active Queue</h2>
            <button onClick={() => navigate('/reception/queue')} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1">
              View full queue <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="divide-y">
            {activeQueue.slice(0, 5).map(q => (
              <div key={q.id} className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-sm font-bold">#{q.token_no}</div>
                  <div>
                    <p className="text-sm font-medium">{q.patient_name}</p>
                    <p className="text-xs text-muted-foreground">{q.doctor} · {q.department}</p>
                  </div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full ${q.status === 'called' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>{q.status}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
