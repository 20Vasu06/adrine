import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Plus, CreditCard, IndianRupee, Download, Printer, Eye, X, Banknote, Smartphone, Shield, FileText } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const statusStyles: Record<string, string> = {
  paid: 'bg-success/10 text-success',
  partial: 'bg-warning/10 text-warning',
  pending: 'bg-info/10 text-info',
  overdue: 'bg-destructive/10 text-destructive',
};

interface Invoice {
  id: string;
  invoice_no: string;
  patient_name: string;
  date: string;
  category: string;
  items: any[];
  total: number;
  paid: number;
  status: string;
  payment_mode: string | null;
}

export default function ReceptionBilling() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState<Invoice | null>(null);
  const [paymentModal, setPaymentModal] = useState<Invoice | null>(null);
  const [paymentMode, setPaymentMode] = useState<string>('cash');
  const [paymentAmount, setPaymentAmount] = useState('');

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const { data } = await supabase.from('invoices').select('*').eq('org_id', orgId).order('created_at', { ascending: false });
      setInvoices((data || []).map(d => ({ ...d, items: Array.isArray(d.items) ? d.items : [] })) as Invoice[]);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  const totalRevenue = invoices.reduce((s, i) => s + i.paid, 0);
  const totalPending = invoices.reduce((s, i) => s + (i.total - i.paid), 0);

  const filtered = invoices.filter(inv => {
    const matchSearch = inv.patient_name.toLowerCase().includes(search.toLowerCase()) || inv.invoice_no.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || inv.status === filter;
    return matchSearch && matchFilter;
  });

  const handlePayment = async () => {
    if (!paymentModal || !paymentAmount) return;
    const amount = Number(paymentAmount);
    const newPaid = paymentModal.paid + amount;
    const newStatus = newPaid >= paymentModal.total ? 'paid' : 'partial';
    const { error } = await supabase.from('invoices').update({ paid: newPaid, status: newStatus as any, payment_mode: paymentMode }).eq('id', paymentModal.id);
    if (error) { toast.error('Payment failed'); return; }
    setInvoices(prev => prev.map(i => i.id === paymentModal.id ? { ...i, paid: newPaid, status: newStatus, payment_mode: paymentMode } : i));
    toast.success(`₹${amount.toLocaleString('en-IN')} collected`);
    setPaymentModal(null);
    setPaymentAmount('');
  };

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading invoices...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Billing</h1>
          <p className="text-sm text-muted-foreground mt-1">Invoices and payment collection</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border bg-card p-4">
          <p className="text-xs text-muted-foreground mb-1">Total Collection</p>
          <p className="text-xl font-bold flex items-center"><IndianRupee className="w-4 h-4" />{totalRevenue.toLocaleString('en-IN')}</p>
        </div>
        <div className="rounded-xl border bg-card p-4">
          <p className="text-xs text-muted-foreground mb-1">Pending Amount</p>
          <p className="text-xl font-bold flex items-center text-warning"><IndianRupee className="w-4 h-4" />{totalPending.toLocaleString('en-IN')}</p>
        </div>
        <div className="rounded-xl border bg-card p-4">
          <p className="text-xs text-muted-foreground mb-1">Invoices</p>
          <p className="text-xl font-bold">{invoices.length}</p>
          <p className="text-xs text-success">{invoices.filter(i => i.status === 'paid').length} paid</p>
        </div>
      </div>

      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border bg-card text-sm" placeholder="Search invoices..." />
        </div>
        <div className="flex gap-1.5">
          {['all', 'paid', 'partial', 'pending', 'overdue'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filter === f ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {invoices.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <FileText className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No invoices yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 rounded-xl border bg-card overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-muted/30">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Invoice</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden sm:table-cell">Patient</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden md:table-cell">Category</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Amount</th>
                  <th className="text-center px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filtered.map(inv => (
                  <tr key={inv.id} onClick={() => setSelected(inv)} className={`hover:bg-accent/50 transition-colors cursor-pointer ${selected?.id === inv.id ? 'bg-accent/50' : ''}`}>
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium">{inv.invoice_no}</p>
                      <p className="text-xs text-muted-foreground">{inv.date}</p>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell text-sm">{inv.patient_name}</td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{inv.category}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <p className="text-sm font-semibold">₹{inv.total.toLocaleString('en-IN')}</p>
                      {inv.status === 'partial' && <p className="text-xs text-muted-foreground">Paid ₹{inv.paid.toLocaleString('en-IN')}</p>}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${statusStyles[inv.status] || ''}`}>{inv.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="rounded-xl border bg-card p-5">
            {selected ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{selected.invoice_no}</h3>
                </div>
                <div className="text-sm space-y-1">
                  <p><span className="text-muted-foreground">Patient:</span> {selected.patient_name}</p>
                  <p><span className="text-muted-foreground">Date:</span> {selected.date}</p>
                  <p><span className="text-muted-foreground">Category:</span> {selected.category}</p>
                </div>
                <div className="border-t pt-3 space-y-2">
                  {selected.items.map((item: any, i: number) => (
                    <div key={i} className="flex justify-between text-sm">
                      <span>{item.description}</span>
                      <span className="font-medium">₹{item.amount?.toLocaleString('en-IN')}</span>
                    </div>
                  ))}
                  <div className="border-t pt-2 flex justify-between font-semibold">
                    <span>Total</span>
                    <span>₹{selected.total.toLocaleString('en-IN')}</span>
                  </div>
                  {selected.total - selected.paid > 0 && (
                    <div className="flex justify-between text-sm text-warning font-medium">
                      <span>Balance Due</span>
                      <span>₹{(selected.total - selected.paid).toLocaleString('en-IN')}</span>
                    </div>
                  )}
                </div>
                {selected.status !== 'paid' && (
                  <button onClick={() => { setPaymentModal(selected); setPaymentAmount((selected.total - selected.paid).toString()); }}
                    className="w-full py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                    <CreditCard className="w-4 h-4" /> Collect Payment
                  </button>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                <FileText className="w-8 h-8 mb-2 opacity-30" />
                <p className="text-sm">Select an invoice to preview</p>
              </div>
            )}
          </div>
        </div>
      )}

      <AnimatePresence>
        {paymentModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setPaymentModal(null)}>
            <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
              className="bg-card border rounded-xl w-full max-w-md p-6 space-y-5" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold">Collect Payment</h2>
                <button onClick={() => setPaymentModal(null)} className="p-1 rounded hover:bg-accent"><X className="w-5 h-5" /></button>
              </div>
              <div className="text-sm space-y-1">
                <p><span className="text-muted-foreground">Invoice:</span> {paymentModal.invoice_no}</p>
                <p><span className="text-muted-foreground">Patient:</span> {paymentModal.patient_name}</p>
                <p className="text-lg font-bold">Due: ₹{(paymentModal.total - paymentModal.paid).toLocaleString('en-IN')}</p>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Payment Mode</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: 'cash', label: 'Cash', icon: Banknote },
                    { key: 'card', label: 'Card', icon: CreditCard },
                    { key: 'upi', label: 'UPI', icon: Smartphone },
                    { key: 'insurance', label: 'Insurance', icon: Shield },
                  ].map(m => (
                    <button key={m.key} onClick={() => setPaymentMode(m.key)}
                      className={`flex items-center gap-2 px-4 py-3 rounded-lg border text-sm font-medium transition-colors ${paymentMode === m.key ? 'bg-primary text-primary-foreground' : 'bg-background hover:bg-accent'}`}>
                      <m.icon className="w-4 h-4" /> {m.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Amount (₹)</label>
                <input type="number" value={paymentAmount} onChange={e => setPaymentAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border bg-background text-sm" />
              </div>
              <button onClick={handlePayment}
                className="w-full py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors">
                Confirm Payment
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
