import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Pill, ClipboardList, Package } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const statusColor: Record<string, string> = {
  Pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  Verified: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  Dispensed: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  "Partially dispensed": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  Cancelled: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

export default function PharmacyDashboard() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    supabase.from('prescriptions').select('*').eq('org_id', orgId).order('created_at', { ascending: false }).limit(50)
      .then(({ data }) => { setPrescriptions(data || []); setLoading(false); });
  }, [orgId]);

  const pending = prescriptions.filter(r => r.status === 'Pending').length;
  const dispensed = prescriptions.filter(r => r.status === 'Dispensed').length;

  const stats = [
    { label: "Pending Prescriptions", value: String(pending), icon: ClipboardList, trend: "Awaiting dispensing" },
    { label: "Dispensed Today", value: String(dispensed), icon: Pill, trend: "Completed" },
    { label: "Total Prescriptions", value: String(prescriptions.length), icon: Package, trend: "All time" },
  ];

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Pharmacy Dashboard</h1>
        <p className="text-muted-foreground text-sm">Real-time overview of pharmacy operations</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {stats.map(s => (
          <Card key={s.label}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                  <p className="text-3xl font-bold text-foreground mt-1">{s.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{s.trend}</p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <s.icon className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Recent Prescriptions</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Rx ID</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Doctor</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {prescriptions.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No prescriptions yet.</TableCell></TableRow>
              ) : prescriptions.slice(0, 10).map(rx => {
                const meds = Array.isArray(rx.medications) ? rx.medications : [];
                return (
                  <TableRow key={rx.id}>
                    <TableCell className="font-mono text-sm">{rx.rx_no}</TableCell>
                    <TableCell className="font-medium">{rx.patient_name}</TableCell>
                    <TableCell className="text-muted-foreground">{rx.doctor}</TableCell>
                    <TableCell>{meds.length}</TableCell>
                    <TableCell>
                      <Badge variant={rx.priority === "Emergency" ? "destructive" : rx.priority === "Urgent" ? "default" : "secondary"} className="text-xs">{rx.priority}</Badge>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor[rx.status] || ''}`}>{rx.status}</span>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
