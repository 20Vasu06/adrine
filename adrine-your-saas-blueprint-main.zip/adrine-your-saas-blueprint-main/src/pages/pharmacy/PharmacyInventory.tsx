import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Package, AlertTriangle, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

function getStockStatus(qty: number, reorder: number) {
  if (qty === 0) return { label: "Out of Stock", color: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400" };
  if (qty < reorder) return { label: "Low Stock", color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400" };
  return { label: "In Stock", color: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" };
}

function getExpiryStatus(expiry: string | null) {
  if (!expiry) return { label: "N/A", color: "text-muted-foreground" };
  const days = Math.ceil((new Date(expiry).getTime() - Date.now()) / 86400000);
  if (days <= 0) return { label: "Expired", color: "text-destructive" };
  if (days <= 30) return { label: `${days}d left`, color: "text-yellow-600 dark:text-yellow-400" };
  return { label: new Date(expiry).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }), color: "text-muted-foreground" };
}

export default function PharmacyInventory() {
  const { user } = useAuth();
  const [stock, setStock] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.orgId) return;
    const load = async () => {
      setLoading(true);
      const { data } = await supabase.from('pharmacy_stock').select('*').eq('org_id', user.orgId).order('drug_name');
      setStock(data || []);
      setLoading(false);
    };
    load();
  }, [user?.orgId]);

  const categories = ['all', ...new Set(stock.map(s => s.category))];
  const filtered = stock.filter(s => {
    const matchSearch = s.drug_name.toLowerCase().includes(search.toLowerCase()) || (s.generic_name || '').toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === 'all' || s.category === categoryFilter;
    return matchSearch && matchCat;
  });

  const lowStock = stock.filter(s => s.current_stock < s.reorder_level);
  const expiringSoon = stock.filter(s => {
    if (!s.expiry_date) return false;
    const days = Math.ceil((new Date(s.expiry_date).getTime() - Date.now()) / 86400000);
    return days <= 30 && days > 0;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Pharmacy Inventory</h1>
          <p className="text-sm text-muted-foreground mt-1">Stock levels, expiry tracking & reorder alerts</p>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Total Items</p>
          <p className="text-2xl font-bold text-foreground">{stock.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Low Stock</p>
          <p className="text-2xl font-bold text-amber-600">{lowStock.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Expiring Soon</p>
          <p className="text-2xl font-bold text-destructive">{expiringSoon.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Categories</p>
          <p className="text-2xl font-bold text-foreground">{new Set(stock.map(s => s.category)).size}</p>
        </CardContent></Card>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all"><Package className="h-3.5 w-3.5 mr-1" /> All Stock</TabsTrigger>
          <TabsTrigger value="low"><AlertTriangle className="h-3.5 w-3.5 mr-1" /> Low Stock ({lowStock.length})</TabsTrigger>
          <TabsTrigger value="expiring"><Clock className="h-3.5 w-3.5 mr-1" /> Expiring ({expiringSoon.length})</TabsTrigger>
        </TabsList>

        {['all', 'low', 'expiring'].map(tabKey => (
          <TabsContent key={tabKey} value={tabKey} className="mt-4 space-y-4">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search drug name or generic..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
              </div>
            </div>

            <Card className="border-border">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Drug Name</TableHead>
                      <TableHead>Generic</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Batch</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>MRP</TableHead>
                      <TableHead>Expiry</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(tabKey === 'low' ? lowStock : tabKey === 'expiring' ? expiringSoon : filtered).filter(s =>
                      s.drug_name.toLowerCase().includes(search.toLowerCase()) || (s.generic_name || '').toLowerCase().includes(search.toLowerCase())
                    ).map(item => {
                      const stockStatus = getStockStatus(item.current_stock, item.reorder_level);
                      const expiryStatus = getExpiryStatus(item.expiry_date);
                      return (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium text-foreground">{item.drug_name}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">{item.generic_name || '—'}</TableCell>
                          <TableCell><Badge variant="outline" className="text-xs">{item.category}</Badge></TableCell>
                          <TableCell className="text-xs font-mono text-muted-foreground">{item.batch_no || '—'}</TableCell>
                          <TableCell className="font-mono">{item.current_stock}</TableCell>
                          <TableCell className="font-mono">₹{Number(item.mrp).toFixed(2)}</TableCell>
                          <TableCell className={`text-xs ${expiryStatus.color}`}>{expiryStatus.label}</TableCell>
                          <TableCell><span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${stockStatus.color}`}>{stockStatus.label}</span></TableCell>
                        </TableRow>
                      );
                    })}
                    {stock.length === 0 && (
                      <TableRow><TableCell colSpan={8} className="text-center py-12 text-sm text-muted-foreground">No pharmacy stock data. Add drugs from the Pharmacy module.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
