import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Scissors, Clock, Activity, Users, AlertTriangle, CheckCircle2, 
  Timer, Bed, ArrowRight, Zap, Heart
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_CONFIG: Record<string, { label: string; class: string }> = {
  in_progress: { label: 'In Progress', class: 'bg-success/10 text-success border-success/20' },
  preparing: { label: 'Preparing', class: 'bg-warning/10 text-warning border-warning/20' },
  available: { label: 'Available', class: 'bg-info/10 text-info border-info/20' },
  cleaning: { label: 'Turnover', class: 'bg-muted text-muted-foreground border-border' },
  occupied: { label: 'In Use', class: 'bg-warning/10 text-warning border-warning/20' },
};

const PRIORITY_BADGE: Record<string, string> = {
  elective: 'bg-muted text-muted-foreground',
  urgent: 'bg-warning/10 text-warning border-warning/20',
  emergency: 'bg-destructive/10 text-destructive border-destructive/20',
};

const container = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.35 } } };

export default function OTDashboard() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [rooms, setRooms] = useState<any[]>([]);
  const [surgeries, setSurgeries] = useState<any[]>([]);
  const [stats, setStats] = useState({ scheduled: 0, completed: 0, inProgress: 0, emergency: 0 });

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];

    const fetchData = async () => {
      const [roomsRes, surgeriesRes] = await Promise.all([
        supabase.from('ot_rooms').select('*').eq('org_id', orgId),
        supabase.from('ot_surgeries').select('*').eq('org_id', orgId).eq('scheduled_date', today).order('scheduled_time'),
      ]);
      setRooms(roomsRes.data || []);
      const s = surgeriesRes.data || [];
      setSurgeries(s);
      setStats({
        scheduled: s.length,
        completed: s.filter(x => x.status === 'completed').length,
        inProgress: s.filter(x => x.status === 'in_progress').length,
        emergency: s.filter(x => x.priority === 'emergency').length,
      });
    };
    fetchData();
  }, [orgId]);

  const todayStats = [
    { label: 'Scheduled', value: String(stats.scheduled), icon: Clock, color: 'text-info' },
    { label: 'Completed', value: String(stats.completed), icon: CheckCircle2, color: 'text-success' },
    { label: 'In Progress', value: String(stats.inProgress), icon: Activity, color: 'text-warning' },
    { label: 'Emergency', value: String(stats.emergency), icon: AlertTriangle, color: 'text-destructive' },
  ];

  const upcoming = surgeries.filter(s => s.status === 'scheduled' || s.status === 'confirmed');
  const recovery = surgeries.filter(s => s.status === 'completed' && s.postop_notes);

  // Map rooms with current surgeries
  const roomsWithStatus = rooms.map(room => {
    const currentSurgery = surgeries.find(s => s.room_id === room.id && s.status === 'in_progress');
    const nextSurgery = surgeries.find(s => s.room_id === room.id && (s.status === 'scheduled' || s.status === 'confirmed'));
    return { ...room, currentSurgery, nextSurgery };
  });

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Operation Theatre</h1>
          <p className="text-sm text-muted-foreground">Live surgical operations & OT management</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-success/10 border border-success/20">
            <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
            <span className="text-xs font-medium text-success">Live</span>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {todayStats.map(s => (
          <motion.div key={s.label} variants={item}>
            <Card className="border-border/60 hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <s.icon className={`h-5 w-5 mb-3 ${s.color}`} strokeWidth={1.5} />
                <p className="text-3xl font-bold tracking-tight">{s.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.label} Today</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Live OT Room Status */}
      <motion.div variants={item}>
        <div className="flex items-center gap-2 mb-3">
          <Zap className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Live OT Status</span>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {roomsWithStatus.length > 0 ? roomsWithStatus.map(room => {
            const status = room.currentSurgery ? 'in_progress' : room.status === 'available' ? 'available' : room.status;
            const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.available;
            return (
              <Card key={room.id} className={`border-border/60 hover:shadow-md transition-all cursor-pointer ${room.currentSurgery ? 'ring-1 ring-success/30' : ''}`}>
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-foreground text-background flex items-center justify-center text-xs font-bold">
                        {room.room_name}
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{room.room_type}</p>
                        <p className="text-[11px] text-muted-foreground">{room.currentSurgery?.surgery_type || '—'}</p>
                      </div>
                    </div>
                    <Badge className={`${cfg.class} text-[10px]`}>{cfg.label}</Badge>
                  </div>
                  {room.currentSurgery && (
                    <div className="grid grid-cols-3 gap-3 text-[11px]">
                      <div><p className="text-muted-foreground">Surgeon</p><p className="font-medium">{room.currentSurgery.surgeon}</p></div>
                      <div><p className="text-muted-foreground">Patient</p><p className="font-medium">{room.currentSurgery.patient_name}</p></div>
                      <div><p className="text-muted-foreground">Team</p><p className="font-medium flex items-center gap-1"><Users className="h-3 w-3" /> {(room.currentSurgery.team as any[])?.length || 0}</p></div>
                    </div>
                  )}
                  {!room.currentSurgery && room.nextSurgery && (
                    <p className="text-xs text-muted-foreground">Next: {room.nextSurgery.surgery_type} at {room.nextSurgery.scheduled_time}</p>
                  )}
                  {!room.currentSurgery && !room.nextSurgery && (
                    <p className="text-xs text-muted-foreground">Ready for next surgery</p>
                  )}
                </CardContent>
              </Card>
            );
          }) : (
            <p className="text-sm text-muted-foreground col-span-2 text-center py-8">No OT rooms configured. Add rooms to get started.</p>
          )}
        </div>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        <motion.div variants={item} className="md:col-span-2">
          <Card className="border-border/60">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
                  <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Upcoming Surgeries</span>
                </div>
              </div>
              {upcoming.length > 0 ? (
                <div className="space-y-3">
                  {upcoming.map((s, i) => (
                    <div key={i} className="flex items-center justify-between py-2 border-b border-border/40 last:border-0">
                      <div className="flex items-center gap-4">
                        <div className="w-16 text-right"><p className="text-sm font-mono font-semibold">{s.scheduled_time?.substring(0, 5)}</p></div>
                        <div className="w-px h-8 bg-border" />
                        <div>
                          <p className="text-sm font-semibold">{s.surgery_type}</p>
                          <p className="text-[11px] text-muted-foreground">{s.surgeon} • {s.patient_name}</p>
                        </div>
                      </div>
                      <Badge className={`${PRIORITY_BADGE[s.priority] || PRIORITY_BADGE.elective} text-[10px] capitalize`}>{s.priority}</Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">No upcoming surgeries today</p>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/60">
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-4">
                <Heart className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
                <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Recovery Room</span>
              </div>
              {recovery.length > 0 ? (
                <div className="space-y-4">
                  {recovery.map((p, i) => (
                    <div key={i} className="p-3 rounded-lg bg-muted/50 border border-border/40">
                      <p className="text-sm font-semibold">{p.patient_name}</p>
                      <p className="text-[11px] text-muted-foreground">{p.surgery_type}</p>
                      <span className="text-[11px] font-medium">{p.surgeon}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center py-4">No patients in recovery</p>
              )}
              <div className="mt-4 p-3 rounded-lg border border-dashed border-border flex items-center justify-center">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Bed className="h-3.5 w-3.5" />
                  <span>{recovery.length} patients in recovery</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}
