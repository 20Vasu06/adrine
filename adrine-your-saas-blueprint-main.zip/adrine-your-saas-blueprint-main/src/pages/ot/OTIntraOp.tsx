import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Activity, Clock, Droplets, Heart, Thermometer, User,
  AlertTriangle, FileText, Plus, Package
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const container = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTIntraOp() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [surgeries, setSurgeries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from('ot_surgeries')
        .select('*, ot_rooms(room_name)')
        .eq('org_id', orgId)
        .eq('status', 'in_progress')
        .order('scheduled_time');
      setSurgeries(data || []);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading...</div>;

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Intraoperative Documentation</h1>
          <p className="text-sm text-muted-foreground">Live surgical procedures — real-time monitoring</p>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-success/10 border border-success/20">
          <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
          <span className="text-xs font-medium text-success">{surgeries.length} Active Surgeries</span>
        </div>
      </motion.div>

      {surgeries.length === 0 && (
        <div className="p-8 text-center text-muted-foreground">No surgeries currently in progress.</div>
      )}

      {surgeries.map(surgery => {
        const intraop = (surgery.intraop_notes || {}) as Record<string, any>;
        const vitals = intraop.vitals || { hr: '—', bp: '—', spo2: '—', temp: '—' };
        const steps = (intraop.steps || []) as { step: string; time: string; done: boolean }[];
        const implants = (intraop.implants || []) as { name: string; manufacturer: string; batch: string }[];
        const complications = (intraop.complications || []) as string[];
        const roomName = (surgery.ot_rooms as any)?.room_name || '—';

        return (
          <motion.div key={surgery.id} variants={item}>
            <Card className="border-border/60 ring-1 ring-success/20">
              <CardContent className="p-0">
                <div className="p-5 border-b border-border/40 bg-muted/30">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-foreground text-background flex items-center justify-center text-sm font-bold">
                        {roomName}
                      </div>
                      <div>
                        <h2 className="text-lg font-bold">{surgery.surgery_type}</h2>
                        <p className="text-sm text-muted-foreground">{surgery.patient_name} • {surgery.surgeon}</p>
                      </div>
                    </div>
                    <div className="text-right space-y-1">
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="font-mono font-bold">{surgery.scheduled_time}</span>
                      </div>
                      <p className="text-[10px] text-muted-foreground">Est. {surgery.duration_minutes || 60} min</p>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 divide-x divide-border/40">
                  {/* Vitals */}
                  <div className="p-5">
                    <div className="flex items-center gap-2 mb-4">
                      <Activity className="h-4 w-4 text-success" />
                      <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Vitals</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { icon: Heart, label: 'Heart Rate', value: vitals.hr, color: 'text-destructive' },
                        { icon: Activity, label: 'BP', value: vitals.bp, color: 'text-info' },
                        { icon: Droplets, label: 'SpO₂', value: vitals.spo2 ? `${vitals.spo2}%` : '—', color: 'text-info' },
                        { icon: Thermometer, label: 'Temp', value: vitals.temp, color: 'text-warning' },
                      ].map(v => (
                        <div key={v.label} className="p-3 rounded-lg bg-muted/50 border border-border/40">
                          <v.icon className={`h-3.5 w-3.5 ${v.color} mb-1`} />
                          <p className="text-xl font-bold font-mono">{v.value}</p>
                          <p className="text-[10px] text-muted-foreground">{v.label}</p>
                        </div>
                      ))}
                    </div>
                    {intraop.bloodLoss && (
                      <div className="mt-3 p-3 rounded-lg bg-muted/50 border border-border/40 flex items-center justify-between">
                        <div><Droplets className="h-3.5 w-3.5 text-destructive mb-1" /><p className="text-[10px] text-muted-foreground">Blood Loss</p></div>
                        <p className="text-lg font-bold font-mono text-destructive">{intraop.bloodLoss}</p>
                      </div>
                    )}
                    <div className="mt-3 p-2 rounded-lg bg-accent/50 text-[11px]">
                      <p className="text-muted-foreground"><User className="h-3 w-3 inline mr-1" />{surgery.anesthesiologist || 'Not assigned'}</p>
                    </div>
                  </div>

                  {/* Surgical Steps */}
                  <div className="p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Surgical Steps</span>
                      </div>
                      <span className="text-[10px] font-mono text-muted-foreground">
                        {steps.filter(s => s.done).length}/{steps.length}
                      </span>
                    </div>
                    {steps.length > 0 ? (
                      <div className="space-y-1">
                        {steps.map((step, i) => (
                          <div key={i} className={`flex items-start gap-3 p-2.5 rounded-lg transition-colors ${step.done ? 'bg-success/5' : i === steps.findIndex(s => !s.done) ? 'bg-info/5 border border-info/20' : ''}`}>
                            <div className="mt-0.5">
                              {step.done ? (
                                <div className="w-5 h-5 rounded-full bg-success flex items-center justify-center"><span className="text-[10px] text-success-foreground font-bold">✓</span></div>
                              ) : i === steps.findIndex(s => !s.done) ? (
                                <div className="w-5 h-5 rounded-full border-2 border-info animate-pulse" />
                              ) : (
                                <div className="w-5 h-5 rounded-full border border-border" />
                              )}
                            </div>
                            <div className="flex-1">
                              <p className={`text-xs font-medium ${step.done ? 'text-muted-foreground' : ''}`}>{step.step}</p>
                              {step.time !== '—' && <p className="text-[10px] text-muted-foreground font-mono">{step.time}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground p-4 text-center">No surgical steps recorded yet.</p>
                    )}
                    <Button variant="outline" size="sm" className="w-full mt-3 text-xs gap-1"><Plus className="h-3 w-3" /> Add Step Note</Button>
                  </div>

                  {/* Implants & Complications */}
                  <div className="p-5">
                    <div className="mb-6">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <Package className="h-4 w-4 text-muted-foreground" />
                          <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Implants & Devices</span>
                        </div>
                        <Button variant="ghost" size="sm" className="h-6 text-[10px] gap-1"><Plus className="h-3 w-3" /> Add</Button>
                      </div>
                      {implants.length > 0 ? (
                        <div className="space-y-2">
                          {implants.map((imp, i) => (
                            <div key={i} className="p-2.5 rounded-lg border border-border/60 bg-muted/30">
                              <p className="text-xs font-semibold">{imp.name}</p>
                              <p className="text-[10px] text-muted-foreground">{imp.manufacturer}</p>
                              <p className="text-[10px] font-mono text-muted-foreground mt-0.5">Batch: {imp.batch}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="p-4 rounded-lg border border-dashed border-border text-center">
                          <p className="text-xs text-muted-foreground">No implants recorded</p>
                        </div>
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                        <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Complications</span>
                      </div>
                      {complications.length > 0 ? (
                        <div className="space-y-2">
                          {complications.map((c, i) => (
                            <div key={i} className="p-2.5 rounded-lg bg-warning/5 border border-warning/20">
                              <p className="text-xs text-warning">{c}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="p-3 rounded-lg bg-success/5 border border-success/20 text-center">
                          <p className="text-xs text-success">No complications reported</p>
                        </div>
                      )}
                      <Button variant="outline" size="sm" className="w-full mt-3 text-xs gap-1"><Plus className="h-3 w-3" /> Report Complication</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </motion.div>
  );
}
