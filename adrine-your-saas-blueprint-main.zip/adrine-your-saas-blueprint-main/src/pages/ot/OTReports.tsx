import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  FileText, Download, Clock, Scissors,
  Package, AlertTriangle, Eye, Printer
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const OUTCOME_CONFIG: Record<string, { label: string; class: string }> = {
  completed: { label: 'Successful', class: 'bg-success/10 text-success border-success/20' },
  cancelled: { label: 'Cancelled', class: 'bg-destructive/10 text-destructive border-destructive/20' },
  in_progress: { label: 'In Progress', class: 'bg-warning/10 text-warning border-warning/20' },
  scheduled: { label: 'Scheduled', class: 'bg-info/10 text-info border-info/20' },
};

const container = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTReports() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [surgeries, setSurgeries] = useState<any[]>([]);
  const [rooms, setRooms] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('ot_surgeries').select('*').eq('org_id', orgId).order('scheduled_date', { ascending: false }).limit(50),
      supabase.from('ot_rooms').select('id, room_name').eq('org_id', orgId),
    ]).then(([surgRes, roomRes]) => {
      setSurgeries(surgRes.data || []);
      setRooms(roomRes.data || []);
    });
  }, [orgId]);

  const completed = surgeries.filter(s => s.status === 'completed').length;
  const withComplications = surgeries.filter(s => {
    const notes = s.postop_notes as Record<string, any> || {};
    return notes.complications && notes.complications !== 'None';
  }).length;

  const REPORT_TYPES = [
    { label: 'Surgery Reports', value: completed, description: 'Complete surgical documentation', icon: Scissors },
    { label: 'Total Surgeries', value: surgeries.length, description: 'All surgery records', icon: FileText },
    { label: 'Complication Reports', value: withComplications, description: 'Adverse event documentation', icon: AlertTriangle },
  ];

  const getRoomName = (roomId: string) => rooms.find(r => r.id === roomId)?.room_name || '—';

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Surgical Reports</h1>
          <p className="text-sm text-muted-foreground">Complete surgical documentation & compliance records</p>
        </div>
        <Button variant="outline" size="sm" className="gap-1.5"><Download className="h-3.5 w-3.5" /> Export All</Button>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {REPORT_TYPES.map(r => (
          <motion.div key={r.label} variants={item}>
            <Card className="border-border/60 hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-5">
                <r.icon className="h-5 w-5 mb-3 text-muted-foreground" strokeWidth={1.5} />
                <p className="text-2xl font-bold">{r.value}</p>
                <p className="text-xs font-medium mt-0.5">{r.label}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{r.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <motion.div variants={item}>
        <div className="flex items-center gap-2 mb-3">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Recent Surgery Reports</span>
        </div>
        <div className="space-y-2">
          {surgeries.map(r => {
            const outcomeConfig = OUTCOME_CONFIG[r.status] || OUTCOME_CONFIG.scheduled;
            return (
              <Card key={r.id} className="border-border/60 hover:shadow-md transition-shadow">
                <CardContent className="p-4 flex items-center gap-5">
                  <div className="w-10 h-10 rounded-lg bg-foreground text-background flex items-center justify-center shrink-0">
                    <Scissors className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold">{r.surgery_type}</p>
                      <Badge className={`${outcomeConfig.class} text-[10px]`}>{outcomeConfig.label}</Badge>
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-0.5">
                      {r.patient_name} • {r.surgeon} • {getRoomName(r.room_id)} • {r.duration_minutes || 60}min
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs text-muted-foreground">{r.scheduled_date}</p>
                    <p className="text-[10px] font-mono text-muted-foreground">{r.id.slice(0, 8)}</p>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button variant="ghost" size="icon" className="h-8 w-8"><Eye className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8"><Download className="h-3.5 w-3.5" /></Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
          {surgeries.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-8">No surgery reports</p>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
