import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Users, Search, Plus, Stethoscope, Heart, Shield, 
  Wrench, Clock, CheckCircle2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const ROLE_CONFIG: Record<string, { label: string; icon: any; color: string }> = {
  surgeon: { label: 'Surgeon', icon: Stethoscope, color: 'text-foreground' },
  anesthesiologist: { label: 'Anesthesiologist', icon: Shield, color: 'text-success' },
  nurse: { label: 'OT Nurse', icon: Heart, color: 'text-warning' },
  technician: { label: 'Technician', icon: Wrench, color: 'text-muted-foreground' },
};

const container = { hidden: {}, show: { transition: { staggerChildren: 0.03 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTTeams() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [profiles, setProfiles] = useState<any[]>([]);
  const [todaySurgeries, setTodaySurgeries] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('profiles').select('*').eq('org_id', orgId).eq('is_active', true),
      supabase.from('ot_surgeries').select('*').eq('org_id', orgId).eq('scheduled_date', today),
    ]).then(([profRes, surgRes]) => {
      setProfiles(profRes.data || []);
      setTodaySurgeries(surgRes.data || []);
    });
  }, [orgId]);

  // Map profiles to OT team members based on department/designation
  const teamMembers = profiles
    .filter(p => {
      const dept = (p.department || '').toLowerCase();
      const desig = (p.designation || '').toLowerCase();
      return dept.includes('surgery') || dept.includes('ot') || dept.includes('anesthes') || 
             desig.includes('surgeon') || desig.includes('anesthes') || desig.includes('ot nurse') || desig.includes('ot tech');
    })
    .map(p => {
      const desig = (p.designation || '').toLowerCase();
      let role = 'technician';
      if (desig.includes('surgeon') || desig.includes('doctor')) role = 'surgeon';
      else if (desig.includes('anesthes')) role = 'anesthesiologist';
      else if (desig.includes('nurse')) role = 'nurse';

      const inSurgery = todaySurgeries.some(s => s.surgeon === p.full_name && s.status === 'in_progress');
      const todayCount = todaySurgeries.filter(s => s.surgeon === p.full_name).length;

      return {
        id: p.id,
        name: p.full_name,
        role,
        department: p.department || 'Surgery',
        status: inSurgery ? 'in_surgery' : 'available',
        todaySurgeries: todayCount,
      };
    });

  const filtered = teamMembers.filter(m => {
    const matchSearch = m.name.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === 'All' || m.role === roleFilter;
    return matchSearch && matchRole;
  });

  const available = teamMembers.filter(m => m.status === 'available').length;
  const inSurgery = teamMembers.filter(m => m.status === 'in_surgery').length;

  const STATUS_CONFIG: Record<string, { label: string; class: string }> = {
    available: { label: 'Available', class: 'bg-success/10 text-success border-success/20' },
    in_surgery: { label: 'In Surgery', class: 'bg-warning/10 text-warning border-warning/20' },
  };

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Surgical Teams</h1>
          <p className="text-sm text-muted-foreground">{available} available • {inSurgery} in surgery • {teamMembers.length} total staff</p>
        </div>
        <Button size="sm" className="gap-1.5"><Plus className="h-3.5 w-3.5" /> Add Team Member</Button>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {Object.entries(ROLE_CONFIG).map(([key, config]) => {
          const count = teamMembers.filter(m => m.role === key).length;
          const avail = teamMembers.filter(m => m.role === key && m.status === 'available').length;
          return (
            <motion.div key={key} variants={item}>
              <Card className="border-border/60 cursor-pointer hover:shadow-md transition-shadow" onClick={() => setRoleFilter(key)}>
                <CardContent className="p-4">
                  <config.icon className={`h-4 w-4 mb-2 ${config.color}`} strokeWidth={1.5} />
                  <p className="text-lg font-bold">{count}</p>
                  <p className="text-[10px] text-muted-foreground">{config.label}s</p>
                  <p className="text-[10px] text-success mt-1">{avail} available</p>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <motion.div variants={item} className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search staff..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9" />
        </div>
        <div className="flex gap-1 bg-muted p-0.5 rounded-lg">
          {['All', ...Object.keys(ROLE_CONFIG)].map(r => (
            <button key={r} onClick={() => setRoleFilter(r)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors capitalize ${roleFilter === r ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              {r === 'All' ? 'All' : ROLE_CONFIG[r]?.label || r}
            </button>
          ))}
        </div>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map(member => {
          const roleConfig = ROLE_CONFIG[member.role] || ROLE_CONFIG.technician;
          const Icon = roleConfig.icon;
          const statusConfig = STATUS_CONFIG[member.status] || STATUS_CONFIG.available;
          return (
            <motion.div key={member.id} variants={item}>
              <Card className="border-border/60 hover:shadow-md transition-all cursor-pointer group">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-foreground text-background flex items-center justify-center text-xs font-bold">
                        {member.name.split(' ').map((n: string) => n[0]).join('').slice(0, 2)}
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{member.name}</p>
                        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                          <Icon className="h-3 w-3" /> {roleConfig.label} • {member.department}
                        </div>
                      </div>
                    </div>
                    <Badge className={`${statusConfig.class} text-[10px]`}>{statusConfig.label}</Badge>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                    <span className="flex items-center gap-1"><CheckCircle2 className="h-3 w-3" /> {member.todaySurgeries} today</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
        {filtered.length === 0 && <p className="col-span-3 text-sm text-muted-foreground text-center py-8">No OT team members found</p>}
      </div>
    </motion.div>
  );
}
