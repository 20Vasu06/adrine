import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Plus, Settings, Wrench, CheckCircle2, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_CONFIG: Record<string, { label: string; class: string; dot: string }> = {
  available: { label: 'Available', class: 'bg-success/10 text-success border-success/20', dot: 'bg-success' },
  occupied: { label: 'In Use', class: 'bg-warning/10 text-warning border-warning/20', dot: 'bg-warning' },
  maintenance: { label: 'Maintenance', class: 'bg-destructive/10 text-destructive border-destructive/20', dot: 'bg-destructive' },
  cleaning: { label: 'Turnover', class: 'bg-info/10 text-info border-info/20', dot: 'bg-info' },
};

const container = { hidden: {}, show: { transition: { staggerChildren: 0.05 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTRooms() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [rooms, setRooms] = useState<any[]>([]);
  const [surgeries, setSurgeries] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('ot_rooms').select('*').eq('org_id', orgId),
      supabase.from('ot_surgeries').select('*').eq('org_id', orgId).eq('scheduled_date', today),
    ]).then(([rRes, sRes]) => {
      setRooms(rRes.data || []);
      setSurgeries(sRes.data || []);
    });
  }, [orgId]);

  const statusSummary = {
    total: rooms.length,
    occupied: rooms.filter(r => r.status === 'occupied').length,
    available: rooms.filter(r => r.status === 'available').length,
    maintenance: rooms.filter(r => r.status === 'maintenance').length,
  };

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">OT Rooms</h1>
          <p className="text-sm text-muted-foreground">{statusSummary.total} theatres • {statusSummary.occupied} occupied • {statusSummary.available} available</p>
        </div>
        <Button size="sm" className="gap-1.5"><Plus className="h-3.5 w-3.5" /> Add Room</Button>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-4">
        {rooms.length > 0 ? rooms.map(room => {
          const cfg = STATUS_CONFIG[room.status] || STATUS_CONFIG.available;
          const currentSurgery = surgeries.find(s => s.room_id === room.id && s.status === 'in_progress');
          const nextSurgery = surgeries.find(s => s.room_id === room.id && (s.status === 'scheduled' || s.status === 'confirmed'));
          const todayCount = surgeries.filter(s => s.room_id === room.id).length;
          const equipment = Array.isArray(room.equipment) ? room.equipment as string[] : [];

          return (
            <motion.div key={room.id} variants={item}>
              <Card className={`border-border/60 hover:shadow-md transition-all ${room.status === 'occupied' ? 'ring-1 ring-warning/20' : ''}`}>
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-foreground text-background flex items-center justify-center text-xs font-bold">{room.room_name}</div>
                      <div>
                        <p className="text-sm font-semibold">{room.room_type}</p>
                      </div>
                    </div>
                    <Badge className={`${cfg.class} text-[10px]`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot} mr-1.5`} />
                      {cfg.label}
                    </Badge>
                  </div>

                  {currentSurgery && (
                    <div className="p-3 rounded-lg bg-warning/5 border border-warning/20 mb-3">
                      <p className="text-xs text-muted-foreground mb-0.5">Current Surgery</p>
                      <p className="text-sm font-semibold">{currentSurgery.surgery_type}</p>
                      <p className="text-[11px] text-muted-foreground">{currentSurgery.surgeon}</p>
                    </div>
                  )}

                  {nextSurgery && (
                    <div className="flex items-center gap-2 mb-3 text-[11px]">
                      <Clock className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">Next:</span>
                      <span className="font-medium">{nextSurgery.surgery_type}</span>
                      <span className="text-muted-foreground">at {nextSurgery.scheduled_time?.substring(0, 5)}</span>
                    </div>
                  )}

                  {equipment.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {equipment.slice(0, 3).map((e, i) => (
                        <span key={i} className="px-2 py-0.5 rounded-full bg-muted text-[10px] font-medium text-muted-foreground">{String(e)}</span>
                      ))}
                      {equipment.length > 3 && (
                        <span className="px-2 py-0.5 rounded-full bg-muted text-[10px] font-medium text-muted-foreground">+{equipment.length - 3}</span>
                      )}
                    </div>
                  )}

                  <div className="flex items-center justify-between mt-4 pt-3 border-t border-border/40">
                    <span className="text-[11px] text-muted-foreground">{todayCount} surgeries today</span>
                    <Button variant="ghost" size="sm" className="h-7 text-[11px] gap-1"><Wrench className="h-3 w-3" /> Maintenance</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        }) : (
          <p className="text-sm text-muted-foreground col-span-2 text-center py-8">No OT rooms configured yet</p>
        )}
      </div>
    </motion.div>
  );
}
