import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Heart, Clock, Activity, Bed, User, FileText, 
  CheckCircle2, AlertTriangle, Thermometer
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const OUTCOME_CONFIG: Record<string, { label: string; class: string }> = {
  successful: { label: 'Successful', class: 'bg-success/10 text-success border-success/20' },
  with_complications: { label: 'With Complications', class: 'bg-warning/10 text-warning border-warning/20' },
  monitoring: { label: 'Close Monitoring', class: 'bg-info/10 text-info border-info/20' },
};

const RECOVERY_CONFIG: Record<string, { label: string; class: string }> = {
  recovery_room: { label: 'Recovery Room', class: 'bg-info/10 text-info border-info/20' },
  ward_transfer: { label: 'Ward Transfer', class: 'bg-success/10 text-success border-success/20' },
  icu_transfer: { label: 'ICU Transfer', class: 'bg-destructive/10 text-destructive border-destructive/20' },
  discharged: { label: 'Discharged', class: 'bg-muted text-muted-foreground' },
};

const container = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTPostOp() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [surgeries, setSurgeries] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from('ot_surgeries')
        .select('*')
        .eq('org_id', orgId)
        .in('status', ['completed', 'postop'])
        .order('updated_at', { ascending: false })
        .limit(20);
      setSurgeries(data || []);
      if (data && data.length > 0) setSelectedId(data[0].id);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  const selected = surgeries.find(s => s.id === selectedId);
  const postop = (selected?.postop_notes || {}) as Record<string, any>;
  const vitals = postop.vitals || { hr: '—', bp: '—', spo2: '—', temp: '—', pain: '—' };
  const outcome = postop.outcome || 'successful';
  const recoveryStatus = postop.recovery_status || 'recovery_room';
  const instructions = (postop.instructions || []) as string[];
  const notes = postop.notes || 'No post-op notes recorded.';
  const nurse = postop.nurse || '—';

  const inRecovery = surgeries.filter(s => ((s.postop_notes as any)?.recovery_status || 'recovery_room') === 'recovery_room').length;
  const wardTransfers = surgeries.filter(s => ((s.postop_notes as any)?.recovery_status) === 'ward_transfer').length;

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading...</div>;
  if (surgeries.length === 0) return <div className="p-8 text-center text-muted-foreground">No post-operative cases found.</div>;

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item}>
        <h1 className="text-2xl font-bold tracking-tight">Post-Operative Care</h1>
        <p className="text-sm text-muted-foreground">Recovery monitoring & post-op documentation</p>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'In Recovery', value: inRecovery, icon: Bed, color: 'text-info' },
          { label: 'Ward Transfers', value: wardTransfers, icon: CheckCircle2, color: 'text-success' },
          { label: 'Total Cases', value: surgeries.length, icon: AlertTriangle, color: 'text-muted-foreground' },
          { label: 'Today', value: surgeries.filter(s => s.scheduled_date === new Date().toISOString().split('T')[0]).length, icon: Clock, color: 'text-foreground' },
        ].map(s => (
          <motion.div key={s.label} variants={item}>
            <Card className="border-border/60"><CardContent className="p-4">
              <s.icon className={`h-4 w-4 mb-2 ${s.color}`} strokeWidth={1.5} />
              <p className="text-xl font-bold">{s.value}</p>
              <p className="text-[10px] text-muted-foreground">{s.label}</p>
            </CardContent></Card>
          </motion.div>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <motion.div variants={item} className="space-y-2">
          <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Post-Op Patients</span>
          {surgeries.map(p => (
            <Card key={p.id} onClick={() => setSelectedId(p.id)}
              className={`border-border/60 cursor-pointer transition-all hover:shadow-md ${selectedId === p.id ? 'ring-1 ring-foreground/20 shadow-md' : ''}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-semibold">{p.patient_name}</p>
                  <Badge className={`${(RECOVERY_CONFIG[(p.postop_notes as any)?.recovery_status || 'recovery_room'] || RECOVERY_CONFIG.recovery_room).class} text-[10px]`}>
                    {(RECOVERY_CONFIG[(p.postop_notes as any)?.recovery_status || 'recovery_room'] || RECOVERY_CONFIG.recovery_room).label}
                  </Badge>
                </div>
                <p className="text-[11px] text-muted-foreground">{p.surgery_type}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{p.surgeon} • {p.scheduled_date}</p>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {selected && (
          <motion.div variants={item} className="md:col-span-2">
            <Card className="border-border/60">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-5 pb-4 border-b border-border/40">
                  <div>
                    <h2 className="text-lg font-bold">{selected.patient_name}</h2>
                    <p className="text-sm text-muted-foreground">{selected.surgery_type}</p>
                  </div>
                  <div className="flex gap-2">
                    <Badge className={`${(OUTCOME_CONFIG[outcome] || OUTCOME_CONFIG.successful).class} text-xs`}>{(OUTCOME_CONFIG[outcome] || OUTCOME_CONFIG.successful).label}</Badge>
                    <Badge className={`${(RECOVERY_CONFIG[recoveryStatus] || RECOVERY_CONFIG.recovery_room).class} text-xs`}>{(RECOVERY_CONFIG[recoveryStatus] || RECOVERY_CONFIG.recovery_room).label}</Badge>
                  </div>
                </div>

                <div className="grid grid-cols-5 gap-3 mb-5">
                  {[
                    { icon: Heart, value: vitals.hr, label: 'HR', color: 'text-destructive' },
                    { icon: Activity, value: vitals.bp, label: 'BP', color: 'text-info' },
                    { icon: Activity, value: vitals.spo2 ? `${vitals.spo2}%` : '—', label: 'SpO₂', color: 'text-info' },
                    { icon: Thermometer, value: vitals.temp, label: 'Temp', color: 'text-warning' },
                    { icon: Activity, value: vitals.pain !== undefined ? `${vitals.pain}/10` : '—', label: 'Pain', color: 'text-destructive' },
                  ].map(v => (
                    <div key={v.label} className="p-3 rounded-lg bg-muted/50 border border-border/40 text-center">
                      <v.icon className={`h-3.5 w-3.5 ${v.color} mx-auto mb-1`} />
                      <p className="text-lg font-bold font-mono">{v.value}</p>
                      <p className="text-[9px] text-muted-foreground">{v.label}</p>
                    </div>
                  ))}
                </div>

                <div className="grid md:grid-cols-2 gap-5">
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Surgeon Notes</span>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50 border border-border/40">
                      <p className="text-sm">{notes}</p>
                    </div>
                    <div className="flex items-center gap-2 mt-3 text-[11px] text-muted-foreground">
                      <User className="h-3 w-3" /> Attending Nurse: <span className="font-medium text-foreground">{nurse}</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                      <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Post-Op Instructions</span>
                    </div>
                    {instructions.length > 0 ? (
                      <div className="space-y-1.5">
                        {instructions.map((inst, i) => (
                          <div key={i} className="flex items-start gap-2 p-2 rounded-md bg-muted/50 border border-border/40">
                            <span className="w-5 h-5 rounded-full bg-foreground text-background flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">{i + 1}</span>
                            <p className="text-xs">{inst}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground p-3">No instructions recorded.</p>
                    )}
                  </div>
                </div>

                <div className="mt-5 flex justify-end gap-2">
                  <Button variant="outline" size="sm">Print Report</Button>
                  <Button size="sm" onClick={async () => {
                    const updated = { ...postop, recovery_status: 'ward_transfer' };
                    await supabase.from('ot_surgeries').update({ postop_notes: updated }).eq('id', selected.id);
                    setSurgeries(prev => prev.map(s => s.id === selected.id ? { ...s, postop_notes: updated } : s));
                  }}>Transfer to Ward</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
