import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ClipboardCheck, CheckCircle2, Circle, AlertTriangle, Clock,
  FileText, FlaskConical, ScanLine, User, Shield
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const WHO_PHASES: Record<string, { label: string; class: string }> = {
  pending: { label: 'Not Started', class: 'bg-muted text-muted-foreground' },
  sign_in: { label: 'Sign-In', class: 'bg-warning/10 text-warning border-warning/20' },
  time_out: { label: 'Time-Out', class: 'bg-info/10 text-info border-info/20' },
  completed: { label: 'Completed', class: 'bg-success/10 text-success border-success/20' },
};

const CHECKLIST_ITEMS = [
  { key: 'consent', label: 'Patient Consent', icon: FileText },
  { key: 'labResults', label: 'Lab Results Verified', icon: FlaskConical },
  { key: 'imaging', label: 'Imaging Reports', icon: ScanLine },
  { key: 'fasting', label: 'Fasting Confirmed', icon: Clock },
  { key: 'preOpEval', label: 'Pre-Op Evaluation', icon: User },
  { key: 'bloodReserve', label: 'Blood Reserve', icon: Shield },
  { key: 'markingSite', label: 'Surgical Site Marking', icon: ClipboardCheck },
  { key: 'ivAccess', label: 'IV Access Secured', icon: ClipboardCheck },
] as const;

const container = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTPreOp() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [surgeries, setSurgeries] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetchSurgeries = async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data } = await supabase
        .from('ot_surgeries')
        .select('*, patients(blood_group, allergies)')
        .eq('org_id', orgId)
        .in('status', ['scheduled', 'preop'])
        .gte('scheduled_date', today)
        .order('scheduled_date')
        .order('scheduled_time');
      setSurgeries(data || []);
      if (data && data.length > 0 && !selectedId) setSelectedId(data[0].id);
      setLoading(false);
    };
    fetchSurgeries();
  }, [orgId]);

  const activeCase = surgeries.find(s => s.id === selectedId);
  const checklist = (activeCase?.preop_checklist || {}) as Record<string, boolean>;
  const whoPhase = (checklist as any)?.who_phase || 'pending';
  const completedCount = CHECKLIST_ITEMS.filter(ci => checklist[ci.key]).length;
  const totalCount = CHECKLIST_ITEMS.length;
  const bloodGroup = (activeCase?.patients as any)?.blood_group || '—';
  const allergies = ((activeCase?.patients as any)?.allergies || '').split(',').filter(Boolean);

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading pre-op cases...</div>;
  if (surgeries.length === 0) return <div className="p-8 text-center text-muted-foreground">No scheduled surgeries for pre-op preparation.</div>;

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item}>
        <h1 className="text-2xl font-bold tracking-tight">Pre-Operative Preparation</h1>
        <p className="text-sm text-muted-foreground">WHO Surgical Safety Checklist & patient preparation</p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Case List */}
        <motion.div variants={item} className="space-y-2">
          <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Pending Cases</span>
          {surgeries.map(c => {
            const cl = (c.preop_checklist || {}) as Record<string, boolean>;
            const done = CHECKLIST_ITEMS.filter(ci => cl[ci.key]).length;
            const pct = Math.round((done / totalCount) * 100);
            const phase = (cl as any)?.who_phase || 'pending';
            return (
              <Card key={c.id} onClick={() => setSelectedId(c.id)}
                className={`border-border/60 cursor-pointer transition-all hover:shadow-md ${selectedId === c.id ? 'ring-1 ring-foreground/20 shadow-md' : ''}`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-semibold">{c.patient_name}</p>
                    <Badge className={`${(WHO_PHASES[phase] || WHO_PHASES.pending).class} text-[10px]`}>{(WHO_PHASES[phase] || WHO_PHASES.pending).label}</Badge>
                  </div>
                  <p className="text-[11px] text-muted-foreground mb-2">{c.surgery_type} • {c.scheduled_time}</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 rounded-full bg-muted">
                      <div className={`h-full rounded-full transition-all ${pct === 100 ? 'bg-success' : pct > 50 ? 'bg-info' : 'bg-warning'}`}
                        style={{ width: `${pct}%` }} />
                    </div>
                    <span className="text-[10px] font-mono font-semibold">{done}/{totalCount}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </motion.div>

        {/* Checklist Detail */}
        {activeCase && (
          <motion.div variants={item} className="md:col-span-2">
            <Card className="border-border/60">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-border/40">
                  <div>
                    <h2 className="text-lg font-bold">{activeCase.patient_name}</h2>
                    <p className="text-sm text-muted-foreground">{activeCase.surgery_type}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{activeCase.surgeon} • {activeCase.scheduled_time}</p>
                  </div>
                  <div className="text-right space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-muted-foreground">Blood Group:</span>
                      <Badge className="bg-destructive/10 text-destructive border-destructive/20 text-xs">{bloodGroup}</Badge>
                    </div>
                    {allergies.length > 0 && (
                      <div className="flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3 text-warning" />
                        <span className="text-[10px] text-warning font-medium">{allergies.join(', ')}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3 mb-6">
                  <div className="flex-1">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-medium">Checklist Progress</span>
                      <span className="font-mono font-bold">{completedCount}/{totalCount}</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-muted">
                      <div className={`h-full rounded-full transition-all ${completedCount === totalCount ? 'bg-success' : 'bg-info'}`}
                        style={{ width: `${(completedCount / totalCount) * 100}%` }} />
                    </div>
                  </div>
                  <Badge className={`${(WHO_PHASES[whoPhase] || WHO_PHASES.pending).class} text-xs`}>
                    WHO: {(WHO_PHASES[whoPhase] || WHO_PHASES.pending).label}
                  </Badge>
                </div>

                <div className="space-y-2">
                  {CHECKLIST_ITEMS.map(ci => {
                    const done = !!checklist[ci.key];
                    return (
                      <div key={ci.key} className={`flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer ${done ? 'bg-success/5 border-success/20' : 'border-border/60 hover:bg-accent'}`}
                        onClick={async () => {
                          const updated = { ...checklist, [ci.key]: !done };
                          await supabase.from('ot_surgeries').update({ preop_checklist: updated }).eq('id', activeCase.id);
                          setSurgeries(prev => prev.map(s => s.id === activeCase.id ? { ...s, preop_checklist: updated } : s));
                        }}>
                        {done ? <CheckCircle2 className="h-5 w-5 text-success shrink-0" /> : <Circle className="h-5 w-5 text-muted-foreground shrink-0" />}
                        <ci.icon className={`h-4 w-4 shrink-0 ${done ? 'text-success' : 'text-muted-foreground'}`} />
                        <span className={`text-sm font-medium ${done ? 'text-foreground' : 'text-muted-foreground'}`}>{ci.label}</span>
                      </div>
                    );
                  })}
                </div>

                <div className="mt-6 pt-4 border-t border-border/40">
                  <p className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground mb-3">WHO Surgical Safety Checklist</p>
                  <div className="grid grid-cols-3 gap-3">
                    {(['sign_in', 'time_out', 'sign_out'] as const).map((phase, i) => {
                      const labels = ['Sign-In (Before Anesthesia)', 'Time-Out (Before Incision)', 'Sign-Out (Before Leaving OT)'];
                      const phaseOrder: Record<string, number> = { pending: 0, sign_in: 1, time_out: 2, completed: 3 };
                      const currentOrder = phaseOrder[whoPhase] || 0;
                      const thisOrder = i + 1;
                      const isActive = thisOrder === currentOrder;
                      const isDone = thisOrder < currentOrder;
                      return (
                        <div key={phase} className={`p-3 rounded-lg border text-center ${isActive ? 'border-info/40 bg-info/5' : isDone ? 'border-success/40 bg-success/5' : 'border-border/60'}`}>
                          {isDone ? <CheckCircle2 className="h-5 w-5 text-success mx-auto mb-1" /> : isActive ? <Clock className="h-5 w-5 text-info mx-auto mb-1" /> : <Circle className="h-5 w-5 text-muted-foreground mx-auto mb-1" />}
                          <p className="text-[10px] font-medium">{labels[i]}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="mt-6 flex justify-end gap-2">
                  <Button variant="outline" size="sm">Save Progress</Button>
                  <Button size="sm" disabled={completedCount < totalCount}
                    onClick={async () => {
                      await supabase.from('ot_surgeries').update({ status: 'ready' }).eq('id', activeCase.id);
                      setSurgeries(prev => prev.filter(s => s.id !== activeCase.id));
                    }}>Mark Ready for Surgery</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
