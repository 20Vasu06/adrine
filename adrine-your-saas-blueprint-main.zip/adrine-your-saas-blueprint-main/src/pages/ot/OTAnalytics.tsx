import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  BarChart3, TrendingUp, Clock, Scissors, AlertTriangle,
  CheckCircle2, Users, Calendar, Download
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, LineChart, Line, Tooltip, PieChart, Pie, Cell } from 'recharts';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const container = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTAnalytics() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [surgeries, setSurgeries] = useState<any[]>([]);
  const [rooms, setRooms] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('ot_surgeries').select('*').eq('org_id', orgId).order('scheduled_date', { ascending: false }).limit(500),
      supabase.from('ot_rooms').select('*').eq('org_id', orgId),
    ]).then(([surgRes, roomRes]) => {
      setSurgeries(surgRes.data || []);
      setRooms(roomRes.data || []);
    });
  }, [orgId]);

  const now = new Date();
  const currentMonth = now.getMonth();
  const mtdSurgeries = surgeries.filter(s => new Date(s.scheduled_date).getMonth() === currentMonth);
  const completed = mtdSurgeries.filter(s => s.status === 'completed');
  const complications = completed.filter(s => {
    const notes = s.postop_notes as Record<string, any> || {};
    return notes.complications && notes.complications !== 'None';
  });
  const cancelled = mtdSurgeries.filter(s => s.status === 'cancelled');

  // Room utilization
  const roomUtil = rooms.map(r => {
    const roomSurgeries = surgeries.filter(s => s.room_id === r.id && s.status === 'completed');
    return { room: r.room_name, utilization: Math.min(Math.round((roomSurgeries.length / Math.max(surgeries.length, 1)) * 100 * rooms.length), 100), surgeries: roomSurgeries.length };
  });

  // Surgeon performance
  const surgeonMap = new Map<string, { surgeries: number; complications: number; cancelled: number }>();
  mtdSurgeries.forEach(s => {
    const existing = surgeonMap.get(s.surgeon) || { surgeries: 0, complications: 0, cancelled: 0 };
    existing.surgeries++;
    if (s.status === 'cancelled') existing.cancelled++;
    const notes = s.postop_notes as Record<string, any> || {};
    if (notes.complications && notes.complications !== 'None') existing.complications++;
    surgeonMap.set(s.surgeon, existing);
  });
  const surgeonPerf = Array.from(surgeonMap.entries()).map(([name, data]) => ({ name, ...data }));

  // Specialty distribution
  const specMap = new Map<string, number>();
  mtdSurgeries.forEach(s => specMap.set(s.surgery_type, (specMap.get(s.surgery_type) || 0) + 1));
  const COLORS_LIST = ['hsl(var(--foreground))', 'hsl(var(--muted-foreground))', 'hsl(var(--info))', 'hsl(var(--success))', 'hsl(var(--border))'];
  const specDist = Array.from(specMap.entries()).slice(0, 5).map(([name, value], i) => ({ name, value, color: COLORS_LIST[i % COLORS_LIST.length] }));

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">OT Analytics</h1>
          <p className="text-sm text-muted-foreground">Surgical performance metrics & operational insights</p>
        </div>
        <Button variant="outline" size="sm" className="gap-1.5"><Download className="h-3.5 w-3.5" /> Export</Button>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Surgeries (MTD)', value: mtdSurgeries.length.toString(), icon: Scissors, color: 'text-foreground' },
          { label: 'Completed', value: completed.length.toString(), icon: CheckCircle2, color: 'text-success' },
          { label: 'Complications', value: complications.length.toString(), icon: AlertTriangle, color: 'text-warning' },
          { label: 'Cancelled', value: cancelled.length.toString(), icon: Clock, color: 'text-destructive' },
        ].map(s => (
          <motion.div key={s.label} variants={item}>
            <Card className="border-border/60 hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <s.icon className={`h-5 w-5 mb-3 ${s.color}`} strokeWidth={1.5} />
                <p className="text-2xl font-bold tracking-tight">{s.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {specDist.length > 0 && (
          <motion.div variants={item}>
            <Card className="border-border/60">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Scissors className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">By Surgery Type</span>
                </div>
                <div className="flex items-center gap-6">
                  <ResponsiveContainer width={160} height={160}>
                    <PieChart>
                      <Pie data={specDist} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" strokeWidth={0}>
                        {specDist.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-2 flex-1">
                    {specDist.map(s => (
                      <div key={s.name} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                          <span className="text-xs">{s.name}</span>
                        </div>
                        <span className="text-xs font-mono font-semibold">{s.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {roomUtil.length > 0 && (
          <motion.div variants={item}>
            <Card className="border-border/60">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">OT Room Utilization</span>
                </div>
                <div className="space-y-4">
                  {roomUtil.map(r => (
                    <div key={r.room}>
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold">{r.room}</span>
                          <span className="text-[10px] text-muted-foreground">{r.surgeries} surgeries</span>
                        </div>
                        <span className="text-sm font-mono font-bold">{r.utilization}%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-muted">
                        <div className={`h-full rounded-full transition-all ${r.utilization > 75 ? 'bg-success' : r.utilization > 50 ? 'bg-info' : 'bg-warning'}`}
                          style={{ width: `${r.utilization}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>

      {surgeonPerf.length > 0 && (
        <motion.div variants={item}>
          <Card className="border-border/60">
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-4">
                <Users className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Surgeon Performance</span>
              </div>
              <div className="space-y-2">
                {surgeonPerf.map(s => (
                  <div key={s.name} className="flex items-center justify-between p-3 rounded-lg border border-border/40 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-foreground text-background flex items-center justify-center text-[10px] font-bold">
                        {s.name.split(' ').pop()?.[0] || s.name[0]}
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{s.name}</p>
                        <p className="text-[10px] text-muted-foreground">{s.surgeries} surgeries</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-[10px] text-muted-foreground">Complications</p>
                        <p className={`text-sm font-mono font-bold ${s.complications === 0 ? 'text-success' : 'text-warning'}`}>{s.complications}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-muted-foreground">Cancelled</p>
                        <p className={`text-sm font-mono font-bold ${s.cancelled === 0 ? 'text-success' : 'text-warning'}`}>{s.cancelled}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </motion.div>
  );
}
