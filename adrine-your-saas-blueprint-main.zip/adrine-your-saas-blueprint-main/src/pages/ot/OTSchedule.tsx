import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CalendarDays, Plus, Search, Clock, User, Scissors, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const PRIORITY_CONFIG: Record<string, { label: string; class: string }> = {
  elective: { label: 'Elective', class: 'bg-muted text-muted-foreground' },
  urgent: { label: 'Urgent', class: 'bg-warning/10 text-warning border-warning/20' },
  emergency: { label: 'Emergency', class: 'bg-destructive/10 text-destructive border-destructive/20' },
};

const STATUS_CONFIG: Record<string, { label: string; class: string }> = {
  scheduled: { label: 'Scheduled', class: 'bg-info/10 text-info border-info/20' },
  confirmed: { label: 'Confirmed', class: 'bg-success/10 text-success border-success/20' },
  in_progress: { label: 'In Progress', class: 'bg-warning/10 text-warning border-warning/20' },
  completed: { label: 'Completed', class: 'bg-muted text-muted-foreground' },
  cancelled: { label: 'Cancelled', class: 'bg-destructive/10 text-destructive border-destructive/20' },
};

const container = { hidden: {}, show: { transition: { staggerChildren: 0.03 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTSchedule() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState('');
  const [surgeries, setSurgeries] = useState<any[]>([]);
  const [rooms, setRooms] = useState<any[]>([]);
  const [dateOffset, setDateOffset] = useState(0);

  const currentDate = new Date();
  currentDate.setDate(currentDate.getDate() + dateOffset);
  const dateStr = currentDate.toISOString().split('T')[0];

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const [sRes, rRes] = await Promise.all([
        supabase.from('ot_surgeries').select('*').eq('org_id', orgId).eq('scheduled_date', dateStr).order('scheduled_time'),
        supabase.from('ot_rooms').select('*').eq('org_id', orgId),
      ]);
      setSurgeries(sRes.data || []);
      setRooms(rRes.data || []);
    };
    fetch();
  }, [orgId, dateStr]);

  const filtered = surgeries.filter(s => {
    const q = search.toLowerCase();
    return s.surgery_type.toLowerCase().includes(q) || s.patient_name.toLowerCase().includes(q);
  });

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Surgery Schedule</h1>
          <p className="text-sm text-muted-foreground">{currentDate.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' })} • {surgeries.length} surgeries</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setDateOffset(d => d - 1)}>
            <ChevronLeft className="h-3.5 w-3.5" /> Previous
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5 font-semibold" onClick={() => setDateOffset(0)}>
            <CalendarDays className="h-3.5 w-3.5" /> Today
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setDateOffset(d => d + 1)}>
            Next <ChevronRight className="h-3.5 w-3.5" />
          </Button>
        </div>
      </motion.div>

      <motion.div variants={item} className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search surgery or patient..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9" />
        </div>
      </motion.div>

      <motion.div variants={item} className="space-y-2">
        {filtered.length > 0 ? filtered.map(s => (
          <Card key={s.id} className="border-border/60 hover:shadow-md transition-shadow cursor-pointer group">
            <CardContent className="p-4 flex items-center gap-5">
              <div className="w-16 text-center shrink-0">
                <p className="text-lg font-mono font-bold">{s.scheduled_time?.substring(0, 5)}</p>
                <p className="text-[10px] text-muted-foreground">{s.duration_minutes || 60}m</p>
              </div>
              <div className="w-px h-10 bg-border" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <Scissors className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                  <p className="text-sm font-semibold truncate">{s.surgery_type}</p>
                </div>
                <p className="text-[11px] text-muted-foreground mt-0.5">{s.patient_name} • {s.anesthesiologist || 'No anesthesiologist assigned'}</p>
              </div>
              <div className="text-right shrink-0 space-y-1">
                <div className="flex items-center gap-1.5 text-xs">
                  <User className="h-3 w-3 text-muted-foreground" />
                  <span className="font-medium">{s.surgeon}</span>
                </div>
                <p className="text-[10px] text-muted-foreground">{rooms.find(r => r.id === s.room_id)?.room_name || 'No room'}</p>
              </div>
              <div className="flex flex-col items-end gap-1 shrink-0">
                <Badge className={`${(PRIORITY_CONFIG[s.priority] || PRIORITY_CONFIG.elective).class} text-[10px]`}>{(PRIORITY_CONFIG[s.priority] || PRIORITY_CONFIG.elective).label}</Badge>
                <Badge className={`${(STATUS_CONFIG[s.status] || STATUS_CONFIG.scheduled).class} text-[10px]`}>{(STATUS_CONFIG[s.status] || STATUS_CONFIG.scheduled).label}</Badge>
              </div>
            </CardContent>
          </Card>
        )) : (
          <p className="text-sm text-muted-foreground text-center py-8">No surgeries scheduled for this date</p>
        )}
      </motion.div>
    </motion.div>
  );
}
