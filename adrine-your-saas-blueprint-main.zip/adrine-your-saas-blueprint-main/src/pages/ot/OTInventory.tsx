import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Package, Search, Plus, AlertTriangle, CheckCircle2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const container = { hidden: {}, show: { transition: { staggerChildren: 0.03 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OTInventory() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    supabase.from('inventory_items').select('*').eq('org_id', orgId).eq('is_active', true)
      .order('name')
      .then(({ data }) => setItems(data || []));
  }, [orgId]);

  const categories = ['All', ...new Set(items.map(i => i.category))];
  const filtered = items.filter(i => {
    const matchSearch = i.name.toLowerCase().includes(search.toLowerCase());
    const matchCat = category === 'All' || i.category === category;
    return matchSearch && matchCat;
  });
  const lowStock = items.filter(i => i.current_stock <= i.reorder_level).length;

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">OT Inventory</h1>
          <p className="text-sm text-muted-foreground">{items.length} items tracked • {lowStock} low stock alerts</p>
        </div>
        <Button size="sm" className="gap-1.5"><Plus className="h-3.5 w-3.5" /> Add Item</Button>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {categories.filter(c => c !== 'All').slice(0, 5).map(cat => {
          const count = items.filter(i => i.category === cat).length;
          const low = items.filter(i => i.category === cat && i.current_stock <= i.reorder_level).length;
          return (
            <motion.div key={cat} variants={item}>
              <Card className={`border-border/60 cursor-pointer hover:shadow-md transition-shadow ${category === cat ? 'ring-1 ring-foreground/20' : ''}`}
                onClick={() => setCategory(category === cat ? 'All' : cat)}>
                <CardContent className="p-4">
                  <Package className="h-4 w-4 mb-2 text-muted-foreground" strokeWidth={1.5} />
                  <p className="text-lg font-bold">{count}</p>
                  <p className="text-[10px] text-muted-foreground capitalize">{cat}</p>
                  {low > 0 && <p className="text-[10px] text-destructive mt-1">⚠ {low} low stock</p>}
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <motion.div variants={item} className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search inventory..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9" />
        </div>
      </motion.div>

      <motion.div variants={item}>
        <Card className="border-border/60">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-[11px]">Item</TableHead>
                  <TableHead className="text-[11px]">Category</TableHead>
                  <TableHead className="text-[11px]">Stock</TableHead>
                  <TableHead className="text-[11px]">Status</TableHead>
                  <TableHead className="text-[11px]">Unit Price</TableHead>
                  <TableHead className="text-[11px]">Manufacturer</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map(i => {
                  const isLow = i.current_stock <= i.reorder_level;
                  return (
                    <TableRow key={i.id} className="cursor-pointer hover:bg-muted/50">
                      <TableCell>
                        <p className="text-sm font-semibold">{i.name}</p>
                        <p className="text-[10px] text-muted-foreground">{i.code}</p>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-muted text-muted-foreground text-[10px] capitalize">{i.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-baseline gap-1">
                          <span className={`text-sm font-bold ${isLow ? 'text-destructive' : ''}`}>{i.current_stock}</span>
                          <span className="text-[10px] text-muted-foreground">/ {i.reorder_level} min • {i.unit}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {isLow ? (
                          <Badge className="bg-destructive/10 text-destructive border-destructive/20 text-[10px] gap-1">
                            <AlertTriangle className="h-3 w-3" /> Low Stock
                          </Badge>
                        ) : (
                          <Badge className="bg-success/10 text-success border-success/20 text-[10px] gap-1">
                            <CheckCircle2 className="h-3 w-3" /> In Stock
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-xs font-mono">₹{i.unit_price}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{i.manufacturer || '—'}</TableCell>
                    </TableRow>
                  );
                })}
                {filtered.length === 0 && (
                  <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No items found</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
