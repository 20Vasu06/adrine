import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Barcode, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const statusColor = (s: string) => {
  if (s === 'Analysis Complete' || s === 'Reported' || s === 'Validated') return "default" as const;
  if (s === 'In Analysis' || s === 'Processing') return "secondary" as const;
  return "outline" as const;
};

export default function LabSamples() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!user?.orgId) return;
    supabase.from('lab_orders').select('*').eq('org_id', user.orgId).order('order_time', { ascending: false })
      .then(({ data }) => setOrders(data || []));
  }, [user?.orgId]);

  const filtered = orders.filter(o =>
    o.patient_name.toLowerCase().includes(search.toLowerCase()) || o.order_no.includes(search)
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Samples</h1>
        <p className="text-sm text-muted-foreground mt-1">Sample tracking linked to lab orders</p>
      </div>

      <Tabs defaultValue="tracking">
        <TabsList>
          <TabsTrigger value="tracking"><Barcode className="h-3.5 w-3.5 mr-1" /> Sample Tracking</TabsTrigger>
        </TabsList>

        <TabsContent value="tracking" className="mt-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search order ID, patient..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>

          <Card className="border-border">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Patient</TableHead>
                    <TableHead>Tests</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Sample Status</TableHead>
                    <TableHead>Stage</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-12 text-sm text-muted-foreground">
                        No lab orders found.
                      </TableCell>
                    </TableRow>
                  ) : filtered.map(o => (
                    <TableRow key={o.id}>
                      <TableCell className="font-mono text-sm text-foreground">{o.order_no}</TableCell>
                      <TableCell>
                        <p className="text-sm font-medium text-foreground">{o.patient_name}</p>
                      </TableCell>
                      <TableCell className="text-sm">{o.tests}</TableCell>
                      <TableCell><Badge variant="outline" className="text-xs">{o.category}</Badge></TableCell>
                      <TableCell>
                        <Badge variant={o.priority === 'Emergency' ? 'destructive' : o.priority === 'Urgent' ? 'default' : 'outline'} className="text-xs">{o.priority}</Badge>
                      </TableCell>
                      <TableCell><Badge variant={statusColor(o.sample_status)} className="text-xs">{o.sample_status}</Badge></TableCell>
                      <TableCell><Badge variant={statusColor(o.stage)} className="text-xs">{o.stage}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
