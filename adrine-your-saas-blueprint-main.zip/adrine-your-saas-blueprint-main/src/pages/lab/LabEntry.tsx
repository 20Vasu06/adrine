import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Beaker, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export default function LabEntry() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [search, setSearch] = useState("");

  const fetchOrders = async () => {
    if (!user?.orgId) return;
    const { data } = await supabase.from('lab_orders').select('*').eq('org_id', user.orgId)
      .in('stage', ['Pending Analysis', 'In Analysis']).order('order_time', { ascending: false });
    setOrders(data || []);
  };

  useEffect(() => { fetchOrders(); }, [user?.orgId]);

  const filtered = orders.filter(o =>
    o.patient_name.toLowerCase().includes(search.toLowerCase()) || o.order_no.includes(search)
  );

  const updateStage = async (id: string, stage: string) => {
    await supabase.from('lab_orders').update({ stage: stage as any }).eq('id', id);
    toast.success(`Order updated to ${stage}`);
    fetchOrders();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Test Entry</h1>
        <p className="text-sm text-muted-foreground mt-1">Enter and process lab test results</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search order, patient..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20">
          <Beaker className="w-8 h-8 text-muted-foreground mb-3" />
          <p className="text-sm font-medium">No pending test entries</p>
          <p className="text-xs text-muted-foreground mt-1">Orders will appear here when samples are ready for analysis</p>
        </div>
      ) : filtered.map(order => (
        <Card key={order.id} className="border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <Beaker className="h-4 w-4" />
                  <span className="font-mono">{order.order_no}</span>
                  <Badge variant={order.priority === 'Emergency' ? 'destructive' : order.priority === 'Urgent' ? 'default' : 'outline'} className="text-xs">{order.priority}</Badge>
                </CardTitle>
                <p className="text-sm text-foreground mt-1">{order.patient_name}</p>
                <p className="text-xs text-muted-foreground">Doctor: {order.doctor} · Category: {order.category}</p>
              </div>
              <div className="flex gap-2">
                {order.stage === 'Pending Analysis' && (
                  <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => updateStage(order.id, 'In Analysis')}>Start Analysis</Button>
                )}
                {order.stage === 'In Analysis' && (
                  <Button size="sm" className="text-xs h-7" onClick={() => updateStage(order.id, 'Awaiting Validation')}>Submit for Validation</Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="border rounded-lg p-3 bg-accent/20">
              <p className="text-xs font-medium text-muted-foreground mb-1">Tests Ordered</p>
              <p className="text-sm font-medium">{order.tests}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded-full ${
                  order.stage === 'In Analysis' ? 'bg-amber-500/10 text-amber-600' : 'bg-muted text-muted-foreground'
                }`}>{order.stage}</span>
                <span className={`text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded-full ${
                  order.sample_status === 'Processing' ? 'bg-blue-500/10 text-blue-600' : 'bg-muted text-muted-foreground'
                }`}>{order.sample_status}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
