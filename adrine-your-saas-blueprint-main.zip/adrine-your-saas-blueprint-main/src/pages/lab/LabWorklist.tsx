import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clock, FlaskConical, ListChecks, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const priorityColor = (p: string) => {
  if (p === "Emergency") return "destructive";
  if (p === "Urgent") return "default";
  return "outline";
};

const stageColor = (s: string) => {
  if (s === "Awaiting Validation") return "default";
  if (s === "In Analysis") return "secondary";
  return "outline";
};

export default function LabWorklist() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");

  const fetchOrders = async () => {
    if (!user?.orgId) return;
    const { data } = await supabase.from('lab_orders').select('*').eq('org_id', user.orgId).order('order_time', { ascending: false });
    setOrders(data || []);
  };

  useEffect(() => { fetchOrders(); }, [user?.orgId]);

  const activeOrders = orders.filter(o => o.stage !== 'Validated' && o.stage !== 'Reported');
  const delayedOrders = orders.filter(o => o.stage === 'Pending Analysis' && o.sample_status === 'Ordered');

  const filtered = activeOrders.filter(w => {
    const matchSearch = w.patient_name.toLowerCase().includes(search.toLowerCase()) || w.order_no.includes(search);
    const matchCat = categoryFilter === "all" || w.category === categoryFilter;
    const matchPri = priorityFilter === "all" || w.priority === priorityFilter;
    return matchSearch && matchCat && matchPri;
  });

  const handleAdvanceStage = async (id: string, currentStage: string) => {
    const stageFlow: Record<string, string> = {
      'Pending Analysis': 'In Analysis',
      'In Analysis': 'Awaiting Validation',
      'Awaiting Validation': 'Validated',
    };
    const nextStage = stageFlow[currentStage];
    if (!nextStage) return;
    await supabase.from('lab_orders').update({ stage: nextStage as any }).eq('id', id);
    toast.success(`Order advanced to ${nextStage}`);
    fetchOrders();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Worklist</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {activeOrders.length} active orders · {orders.filter(o => o.stage === 'Validated').length} validated today
        </p>
      </div>

      <Tabs defaultValue="active">
        <TabsList>
          <TabsTrigger value="active"><ListChecks className="h-3.5 w-3.5 mr-1" /> Active ({activeOrders.length})</TabsTrigger>
          <TabsTrigger value="pending-samples"><Clock className="h-3.5 w-3.5 mr-1" /> Pending Samples ({delayedOrders.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="mt-4 space-y-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search order, patient..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-40"><SelectValue placeholder="Category" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Hematology">Hematology</SelectItem>
                <SelectItem value="Biochemistry">Biochemistry</SelectItem>
                <SelectItem value="Microbiology">Microbiology</SelectItem>
                <SelectItem value="Serology">Serology</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-36"><SelectValue placeholder="Priority" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="Routine">Routine</SelectItem>
                <SelectItem value="Urgent">Urgent</SelectItem>
                <SelectItem value="Emergency">Emergency</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Card className="border-border">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order</TableHead>
                    <TableHead>Patient</TableHead>
                    <TableHead>Tests</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Sample</TableHead>
                    <TableHead>Stage</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.length === 0 ? (
                    <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No active lab orders.</TableCell></TableRow>
                  ) : filtered.map(w => (
                    <TableRow key={w.id}>
                      <TableCell>
                        <p className="text-sm font-mono text-foreground">{w.order_no}</p>
                        <p className="text-xs text-muted-foreground">{new Date(w.order_time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</p>
                      </TableCell>
                      <TableCell><p className="text-sm font-medium text-foreground">{w.patient_name}</p></TableCell>
                      <TableCell className="text-sm max-w-[180px] truncate">{w.tests}</TableCell>
                      <TableCell><Badge variant="outline" className="text-xs">{w.category}</Badge></TableCell>
                      <TableCell><Badge variant={priorityColor(w.priority)} className="text-xs">{w.priority}</Badge></TableCell>
                      <TableCell><Badge variant="outline" className="text-xs">{w.sample_status}</Badge></TableCell>
                      <TableCell><Badge variant={stageColor(w.stage)} className="text-xs">{w.stage}</Badge></TableCell>
                      <TableCell>
                        {w.stage === "Pending Analysis" && (
                          <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => handleAdvanceStage(w.id, w.stage)}>Start Analysis</Button>
                        )}
                        {w.stage === "In Analysis" && (
                          <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => handleAdvanceStage(w.id, w.stage)}>Enter Results</Button>
                        )}
                        {w.stage === "Awaiting Validation" && (
                          <Button size="sm" className="text-xs h-7" onClick={() => handleAdvanceStage(w.id, w.stage)}>Validate</Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pending-samples" className="mt-4 space-y-4">
          {delayedOrders.length === 0 ? (
            <div className="text-center py-8 text-sm text-muted-foreground">No pending sample collections</div>
          ) : delayedOrders.map(d => (
            <Card key={d.id} className="border-border border-l-4 border-l-warning">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono text-foreground">{d.order_no}</span>
                    <Badge variant="default" className="text-xs">Sample Pending</Badge>
                  </div>
                  <Button size="sm" variant="outline" className="text-xs h-7" onClick={async () => {
                    await supabase.from('lab_orders').update({ sample_status: 'Collected' }).eq('id', d.id);
                    toast.success('Sample marked as collected');
                    fetchOrders();
                  }}>Mark Collected</Button>
                </div>
                <p className="text-sm font-medium text-foreground">{d.patient_name}</p>
                <p className="text-xs text-muted-foreground">{d.tests} · {d.category} · {d.doctor}</p>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
