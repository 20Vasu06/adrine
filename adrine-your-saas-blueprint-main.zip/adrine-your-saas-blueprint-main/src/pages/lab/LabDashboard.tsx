import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Activity, Beaker, CheckCircle, FlaskConical, TestTube } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const priorityColor = (p: string) => {
  if (p === "Emergency") return "destructive" as const;
  if (p === "Urgent") return "default" as const;
  return "outline" as const;
};

export default function LabDashboard() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(() => {
    if (!user?.orgId) return;
    supabase.from('lab_orders').select('*').eq('org_id', user.orgId).order('order_time', { ascending: false })
      .then(({ data }) => setOrders(data || []));
  }, [user?.orgId]);

  const pending = orders.filter(o => o.stage === 'Pending Analysis');
  const inAnalysis = orders.filter(o => o.stage === 'In Analysis');
  const awaitingValidation = orders.filter(o => o.stage === 'Awaiting Validation');
  const validated = orders.filter(o => o.stage === 'Validated' || o.stage === 'Reported');

  const STATS = [
    { label: "Pending Samples", value: pending.length, icon: TestTube, change: `${pending.filter(o => o.priority === 'Urgent' || o.priority === 'Emergency').length} urgent` },
    { label: "In Analysis", value: inAnalysis.length, icon: FlaskConical, change: "Processing" },
    { label: "Awaiting Validation", value: awaitingValidation.length, icon: Beaker, change: "Ready for review" },
    { label: "Validated Today", value: validated.length, icon: CheckCircle, change: "Completed" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Laboratory Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">Today's overview · {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {STATS.map(s => (
          <Card key={s.label} className="border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">{s.label}</span>
                <s.icon className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.change}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><Activity className="h-4 w-4" /> Recent Orders</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Tests</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Stage</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No lab orders yet.</TableCell></TableRow>
              ) : orders.slice(0, 10).map(o => (
                <TableRow key={o.id}>
                  <TableCell>
                    <p className="text-sm font-mono text-foreground">{o.order_no}</p>
                    <p className="text-xs text-muted-foreground">{new Date(o.order_time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</p>
                  </TableCell>
                  <TableCell><p className="text-sm font-medium text-foreground">{o.patient_name}</p></TableCell>
                  <TableCell className="text-sm max-w-[180px] truncate">{o.tests}</TableCell>
                  <TableCell><Badge variant={priorityColor(o.priority)} className="text-xs">{o.priority}</Badge></TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{o.stage}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
