import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CheckCircle, ClipboardCheck, Search, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export default function LabVerification() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [search, setSearch] = useState("");

  const fetchOrders = async () => {
    if (!user?.orgId) return;
    const { data } = await supabase.from('lab_orders').select('*').eq('org_id', user.orgId)
      .in('stage', ['Awaiting Validation', 'Validated', 'Reported']).order('order_time', { ascending: false });
    setOrders(data || []);
  };

  useEffect(() => { fetchOrders(); }, [user?.orgId]);

  const awaitingValidation = orders.filter(o => o.stage === 'Awaiting Validation');
  const validated = orders.filter(o => o.stage === 'Validated' || o.stage === 'Reported');

  const filtered = awaitingValidation.filter(o =>
    o.patient_name.toLowerCase().includes(search.toLowerCase()) || o.order_no.includes(search)
  );

  const handleApprove = async (id: string, orderNo: string) => {
    await supabase.from('lab_orders').update({ stage: 'Validated' }).eq('id', id);
    toast.success(`Order ${orderNo} validated and approved`);
    fetchOrders();
  };

  const handleReject = async (id: string, orderNo: string) => {
    await supabase.from('lab_orders').update({ stage: 'In Analysis' }).eq('id', id);
    toast.info(`Order ${orderNo} sent back for retest`);
    fetchOrders();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Verification</h1>
        <p className="text-sm text-muted-foreground mt-1">Pathologist review, result validation & report approval</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Awaiting Validation</p>
          <p className="text-2xl font-bold text-foreground">{awaitingValidation.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Validated Today</p>
          <p className="text-2xl font-bold text-foreground">{validated.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Total Orders</p>
          <p className="text-2xl font-bold text-foreground">{orders.length}</p>
        </CardContent></Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search order, patient..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <div className="space-y-4">
        <h2 className="text-sm font-semibold text-foreground uppercase tracking-wider">Pending Validation</h2>
        {filtered.length === 0 ? (
          <div className="text-center py-8">
            <ClipboardCheck className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No orders awaiting validation</p>
          </div>
        ) : filtered.map(order => (
          <Card key={order.id} className="border-border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <ClipboardCheck className="h-4 w-4" />
                    <span className="font-mono">{order.order_no}</span>
                    <Badge variant={order.priority === 'Urgent' || order.priority === 'Emergency' ? 'default' : 'outline'} className="text-xs">{order.priority}</Badge>
                  </CardTitle>
                  <p className="text-sm text-foreground mt-1">{order.patient_name} <span className="text-muted-foreground">· {order.category}</span></p>
                  <p className="text-xs text-muted-foreground">Doctor: {order.doctor}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => handleReject(order.id, order.order_no)}>
                    <XCircle className="h-3.5 w-3.5 mr-1" /> Reject
                  </Button>
                  <Button size="sm" className="text-xs h-7" onClick={() => handleApprove(order.id, order.order_no)}>
                    <CheckCircle className="h-3.5 w-3.5 mr-1" /> Approve
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-0">
              <div className="border rounded-lg p-3 bg-accent/20">
                <p className="text-sm font-medium">{order.tests}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {validated.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-sm font-semibold text-foreground uppercase tracking-wider">Validation History</h2>
          <Card className="border-border">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order</TableHead>
                    <TableHead>Patient</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Tests</TableHead>
                    <TableHead>Doctor</TableHead>
                    <TableHead>Stage</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {validated.map(v => (
                    <TableRow key={v.id}>
                      <TableCell className="font-mono text-sm text-foreground">{v.order_no}</TableCell>
                      <TableCell><p className="text-sm font-medium text-foreground">{v.patient_name}</p></TableCell>
                      <TableCell><Badge variant="outline" className="text-xs">{v.category}</Badge></TableCell>
                      <TableCell className="text-sm max-w-[180px] truncate">{v.tests}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{v.doctor}</TableCell>
                      <TableCell><Badge variant="default" className="text-xs">{v.stage}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
