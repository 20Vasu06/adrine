import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { IndianRupee, TrendingUp, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const payStatusColor: Record<string, string> = {
  paid: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  partial: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  overdue: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

export default function BillingDashboard() {
  const { user } = useAuth();
  const [invoices, setInvoices] = useState<any[]>([]);

  useEffect(() => {
    if (!user?.orgId) return;
    supabase.from('invoices').select('*').eq('org_id', user.orgId).order('date', { ascending: false })
      .then(({ data }) => setInvoices(data || []));
  }, [user?.orgId]);

  const totalRevenue = invoices.reduce((s, i) => s + Number(i.paid), 0);
  const totalPending = invoices.filter(i => i.status === 'pending' || i.status === 'partial').reduce((s, i) => s + (Number(i.total) - Number(i.paid)), 0);

  const stats = [
    { label: "Total Revenue", value: `₹${totalRevenue.toLocaleString('en-IN')}`, icon: IndianRupee, trend: `${invoices.filter(i => i.status === 'paid').length} paid` },
    { label: "Pending Amount", value: `₹${totalPending.toLocaleString('en-IN')}`, icon: TrendingUp, trend: `${invoices.filter(i => i.status !== 'paid').length} invoices` },
    { label: "Total Invoices", value: String(invoices.length), icon: FileText, trend: "All invoices" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Billing & Finance Dashboard</h1>
        <p className="text-muted-foreground text-sm">Hospital financial operations overview</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {stats.map(s => (
          <Card key={s.label}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                  <p className="text-3xl font-bold text-foreground mt-1">{s.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{s.trend}</p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <s.icon className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Recent Invoices</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Paid</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No invoices yet.</TableCell></TableRow>
              ) : invoices.slice(0, 10).map(inv => (
                <TableRow key={inv.id}>
                  <TableCell className="font-mono text-sm">{inv.invoice_no}</TableCell>
                  <TableCell className="font-medium">{inv.patient_name}</TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{inv.category}</Badge></TableCell>
                  <TableCell className="font-medium">₹{Number(inv.total).toLocaleString('en-IN')}</TableCell>
                  <TableCell>₹{Number(inv.paid).toLocaleString('en-IN')}</TableCell>
                  <TableCell><span className={`px-2 py-1 rounded-full text-xs font-medium ${payStatusColor[inv.status] || ''}`}>{inv.status}</span></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
