import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Search, Eye, Plus, ShieldCheck, Send, CheckCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const statusColor: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  partial: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  paid: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  overdue: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

export default function BillingInsurance() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selected, setSelected] = useState<any>(null);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('invoices').select('*').eq('org_id', orgId).order('created_at', { ascending: false }),
      supabase.from('patients').select('id, uhid, name, insurance_provider, policy_no').eq('org_id', orgId).not('insurance_provider', 'is', null),
    ]).then(([invRes, patRes]) => {
      setInvoices(invRes.data || []);
      setPatients(patRes.data || []);
      setLoading(false);
    });
  }, [orgId]);

  // Build claims from invoices that have insurance patients
  const patientMap = new Map(patients.map(p => [p.id, p]));
  const claims = invoices.filter(inv => {
    const pat = patientMap.get(inv.patient_id);
    return pat?.insurance_provider;
  }).map(inv => {
    const pat = patientMap.get(inv.patient_id);
    return {
      id: inv.invoice_no,
      uhid: pat?.uhid || '',
      patient: inv.patient_name,
      provider: pat?.insurance_provider || 'Unknown',
      policyNo: pat?.policy_no || '',
      claimAmount: inv.total,
      approvedAmount: inv.status === 'paid' ? inv.paid : null,
      date: inv.date,
      status: inv.status,
      category: inv.category,
      invoiceId: inv.id,
    };
  });

  const filtered = claims.filter(c => {
    const matchSearch = c.patient.toLowerCase().includes(search.toLowerCase()) || c.id.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const totalClaimed = claims.reduce((s, c) => s + c.claimAmount, 0);
  const totalApproved = claims.filter(c => c.approvedAmount).reduce((s, c) => s + (c.approvedAmount || 0), 0);
  const pendingCount = claims.filter(c => c.status === 'pending' || c.status === 'partial').length;

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Insurance & TPA</h1>
          <p className="text-muted-foreground text-sm">Manage insurance claims, pre-authorizations, and settlements</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <Card><CardContent className="pt-6"><p className="text-sm text-muted-foreground">Total Claims</p><p className="text-2xl font-bold">{claims.length}</p></CardContent></Card>
        <Card><CardContent className="pt-6"><p className="text-sm text-muted-foreground">Total Claimed</p><p className="text-2xl font-bold">₹{totalClaimed.toLocaleString('en-IN')}</p></CardContent></Card>
        <Card><CardContent className="pt-6"><p className="text-sm text-muted-foreground">Approved Amount</p><p className="text-2xl font-bold text-green-600">₹{totalApproved.toLocaleString('en-IN')}</p></CardContent></Card>
        <Card><CardContent className="pt-6"><p className="text-sm text-muted-foreground">Pending Claims</p><p className="text-2xl font-bold text-yellow-600">{pendingCount}</p></CardContent></Card>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search patient or claim ID..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="partial">Partial</SelectItem>
            <SelectItem value="paid">Paid/Settled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Provider</TableHead>
                <TableHead>Policy No.</TableHead>
                <TableHead>Claimed</TableHead>
                <TableHead>Approved</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No insurance claims found</TableCell></TableRow>
              ) : filtered.map(c => (
                <TableRow key={c.id}>
                  <TableCell className="font-mono text-sm">{c.id}</TableCell>
                  <TableCell>
                    <div><span className="font-medium">{c.patient}</span><br /><span className="text-xs text-muted-foreground">{c.uhid}</span></div>
                  </TableCell>
                  <TableCell className="text-sm">{c.provider}</TableCell>
                  <TableCell className="font-mono text-xs">{c.policyNo || '—'}</TableCell>
                  <TableCell className="font-medium">₹{c.claimAmount.toLocaleString('en-IN')}</TableCell>
                  <TableCell className={c.approvedAmount ? "font-medium text-green-600" : "text-muted-foreground"}>{c.approvedAmount != null ? `₹${c.approvedAmount.toLocaleString('en-IN')}` : "—"}</TableCell>
                  <TableCell><span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor[c.status] || ''}`}>{c.status}</span></TableCell>
                  <TableCell><Button variant="ghost" size="icon" onClick={() => setSelected(c)}><Eye className="h-4 w-4" /></Button></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-lg">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5" /> Claim {selected.id}
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColor[selected.status] || ''}`}>{selected.status}</span>
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <div><span className="text-muted-foreground">Patient:</span> <span className="font-medium">{selected.patient}</span></div>
                  <div><span className="text-muted-foreground">UHID:</span> {selected.uhid}</div>
                  <div><span className="text-muted-foreground">Provider:</span> {selected.provider}</div>
                  <div><span className="text-muted-foreground">Policy:</span> {selected.policyNo || '—'}</div>
                  <div><span className="text-muted-foreground">Date:</span> {selected.date}</div>
                </div>
                <div className="border border-border rounded-lg p-3 space-y-2">
                  <div className="flex justify-between"><span className="text-muted-foreground">Claim Amount:</span><span className="font-medium">₹{selected.claimAmount.toLocaleString('en-IN')}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Approved:</span><span className={selected.approvedAmount ? "font-medium text-green-600" : "text-muted-foreground"}>{selected.approvedAmount != null ? `₹${selected.approvedAmount.toLocaleString('en-IN')}` : "Pending"}</span></div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
