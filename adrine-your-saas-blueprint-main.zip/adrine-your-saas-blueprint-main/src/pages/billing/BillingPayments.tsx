import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Search, Plus, IndianRupee } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const statusColor: Record<string, string> = {
  paid: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  partial: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  overdue: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

export default function BillingPayments() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showCollect, setShowCollect] = useState(false);
  const [collectInvId, setCollectInvId] = useState("");
  const [collectAmount, setCollectAmount] = useState("");
  const [collectMode, setCollectMode] = useState("Cash");

  useEffect(() => {
    if (!orgId) return;
    supabase.from('invoices').select('*').eq('org_id', orgId).order('created_at', { ascending: false })
      .then(({ data }) => { setInvoices(data || []); setLoading(false); });
  }, [orgId]);

  const unpaid = invoices.filter(i => i.status !== 'paid');
  const filtered = unpaid.filter(p =>
    p.patient_name.toLowerCase().includes(search.toLowerCase()) || p.invoice_no.toLowerCase().includes(search.toLowerCase())
  );

  const totalCollected = invoices.reduce((s, i) => s + i.paid, 0);
  const totalPending = invoices.reduce((s, i) => s + Math.max(0, i.total - i.paid), 0);

  const handleCollect = async () => {
    if (!collectInvId || !collectAmount) return;
    const inv = invoices.find(i => i.invoice_no === collectInvId || i.id === collectInvId);
    if (!inv) { toast.error('Invoice not found'); return; }
    const amount = Number(collectAmount);
    const newPaid = inv.paid + amount;
    const newStatus = newPaid >= inv.total ? 'paid' : 'partial';
    const { error } = await supabase.from('invoices').update({ paid: newPaid, status: newStatus as any, payment_mode: collectMode }).eq('id', inv.id);
    if (error) { toast.error('Payment failed'); return; }
    setInvoices(prev => prev.map(i => i.id === inv.id ? { ...i, paid: newPaid, status: newStatus, payment_mode: collectMode } : i));
    toast.success(`₹${amount.toLocaleString('en-IN')} collected`);
    setShowCollect(false);
    setCollectInvId("");
    setCollectAmount("");
  };

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Payments</h1>
          <p className="text-muted-foreground text-sm">Collect payments against pending invoices</p>
        </div>
        <Button onClick={() => setShowCollect(true)}><Plus className="h-4 w-4 mr-2" /> Collect Payment</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card><CardContent className="pt-6 flex items-center gap-3"><IndianRupee className="h-8 w-8 text-green-600" /><div><p className="text-2xl font-bold">₹{totalCollected.toLocaleString('en-IN')}</p><p className="text-xs text-muted-foreground">Total Collected</p></div></CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3"><IndianRupee className="h-8 w-8 text-yellow-600" /><div><p className="text-2xl font-bold">₹{totalPending.toLocaleString('en-IN')}</p><p className="text-xs text-muted-foreground">Total Pending</p></div></CardContent></Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search patient or invoice ID..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Paid</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No pending payments</TableCell></TableRow>
              ) : filtered.map(inv => (
                <TableRow key={inv.id}>
                  <TableCell className="font-mono text-sm">{inv.invoice_no}</TableCell>
                  <TableCell className="font-medium">{inv.patient_name}</TableCell>
                  <TableCell>₹{inv.total.toLocaleString('en-IN')}</TableCell>
                  <TableCell>₹{inv.paid.toLocaleString('en-IN')}</TableCell>
                  <TableCell className="font-medium">₹{(inv.total - inv.paid).toLocaleString('en-IN')}</TableCell>
                  <TableCell><span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor[inv.status] || ''}`}>{inv.status}</span></TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => { setCollectInvId(inv.invoice_no); setCollectAmount(String(inv.total - inv.paid)); setShowCollect(true); }}>
                      Collect
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={showCollect} onOpenChange={setShowCollect}>
        <DialogContent>
          <DialogHeader><DialogTitle>Collect Payment</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Invoice ID</Label><Input value={collectInvId} onChange={e => setCollectInvId(e.target.value)} placeholder="INV-XXXX" /></div>
            <div><Label>Amount (₹)</Label><Input type="number" value={collectAmount} onChange={e => setCollectAmount(e.target.value)} /></div>
            <div><Label>Payment Method</Label>
              <Select value={collectMode} onValueChange={setCollectMode}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Cash">Cash</SelectItem>
                  <SelectItem value="Card">Card</SelectItem>
                  <SelectItem value="UPI">UPI</SelectItem>
                  <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowCollect(false)}>Cancel</Button>
              <Button onClick={handleCollect}>Collect Payment</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
