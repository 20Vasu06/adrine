import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, ChevronRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

const statusStyles: Record<string, string> = {
  OPD: 'bg-emerald-500/10 text-emerald-600',
  IPD: 'bg-blue-500/10 text-blue-600',
  Emergency: 'bg-destructive/10 text-destructive',
};

const filterOptions = ['All', 'OPD', 'IPD', 'Emergency'];

export default function DoctorPatients() {
  const { user } = useAuth();
  const [patients, setPatients] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const navigate = useNavigate();

  useEffect(() => {
    if (!user?.orgId) return;
    supabase.from('patients').select('*').eq('org_id', user.orgId).order('created_at', { ascending: false })
      .then(({ data }) => setPatients(data || []));
  }, [user?.orgId]);

  const filtered = patients.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.uhid.toLowerCase().includes(search.toLowerCase()) ||
      (p.department || '').toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'All' || p.patient_type === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div className="space-y-6">
      <motion.div {...fadeIn(0)} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Patients</h1>
          <p className="text-sm text-muted-foreground mt-1">{patients.length} patients registered</p>
        </div>
      </motion.div>

      <motion.div {...fadeIn(1)} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search by name, UHID, or department..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {filterOptions.map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filter === f ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {f}
            </button>
          ))}
        </div>
      </motion.div>

      <motion.div {...fadeIn(2)} className="border rounded-xl bg-card overflow-hidden">
        <div className="divide-y">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">No patients found.</div>
          ) : filtered.map(p => (
            <div key={p.id} onClick={() => navigate(`/doctor/patients/${p.uhid}`)}
              className="flex items-center gap-3 px-4 py-3.5 hover:bg-accent/50 transition-colors cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                <span className="text-sm font-semibold">{p.name.split(' ').map((n: string) => n[0]).join('')}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold truncate">{p.name}</p>
                  <span className="text-[10px] font-mono text-muted-foreground">{p.uhid}</span>
                </div>
                <p className="text-[11px] text-muted-foreground truncate">
                  {p.age}y/{p.gender} · {p.department || 'General'} · {p.phone}
                </p>
              </div>
              <div className="text-right shrink-0 flex items-center gap-2">
                <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full ${statusStyles[p.patient_type] || 'bg-muted text-muted-foreground'}`}>
                  {p.patient_type}
                </span>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
