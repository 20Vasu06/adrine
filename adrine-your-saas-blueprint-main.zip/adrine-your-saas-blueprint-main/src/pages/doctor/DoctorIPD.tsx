import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BedDouble, Search, AlertTriangle, Clock, Activity, Plus } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

interface IPDPatient {
  id: string;
  bed: string;
  ward: string;
  name: string;
  age: number;
  gender: string;
  diagnosis: string;
  admittedOn: string;
  daysAdmitted: number;
  status: string;
}

const conditionStyle: Record<string, { badge: string; dot: string }> = {
  admitted: { badge: 'bg-blue-500/10 text-blue-600', dot: 'bg-blue-500' },
  critical: { badge: 'bg-destructive/10 text-destructive', dot: 'bg-destructive' },
  discharged: { badge: 'bg-muted text-muted-foreground', dot: 'bg-muted-foreground' },
};

export default function DoctorIPD() {
  const { user } = useAuth();
  const [search, setSearch] = useState('');
  const [ipdPatients, setIpdPatients] = useState<IPDPatient[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user?.orgId) return;
    supabase.from('admissions').select('*, beds(bed_no, ward), patients(age, gender)')
      .eq('org_id', user.orgId)
      .order('admission_date', { ascending: false })
      .then(({ data }) => {
        if (data) {
          setIpdPatients(data.map((a: any) => ({
            id: a.id,
            bed: a.beds?.bed_no || 'N/A',
            ward: a.beds?.ward || 'General',
            name: a.patient_name,
            age: a.patients?.age || 0,
            gender: a.patients?.gender || '',
            diagnosis: a.diagnosis || 'N/A',
            admittedOn: new Date(a.admission_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
            daysAdmitted: Math.max(1, Math.ceil((Date.now() - new Date(a.admission_date).getTime()) / 86400000)),
            status: a.status,
          })));
        }
      });
  }, [user?.orgId]);

  const filtered = ipdPatients.filter(p => {
    return p.name.toLowerCase().includes(search.toLowerCase()) || p.bed.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="space-y-6">
      <motion.div {...fadeIn(0)} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">IPD Rounds</h1>
          <p className="text-sm text-muted-foreground mt-1">{ipdPatients.length} admitted patients</p>
        </div>
      </motion.div>

      <motion.div {...fadeIn(1)} className="grid grid-cols-4 gap-3">
        {[
          { label: 'Total IPD', value: ipdPatients.length, icon: BedDouble, color: '' },
          { label: 'Admitted', value: ipdPatients.filter(p => p.status === 'admitted').length, icon: Activity, color: 'text-blue-600' },
          { label: 'Discharged', value: ipdPatients.filter(p => p.status === 'discharged').length, icon: Clock, color: 'text-muted-foreground' },
        ].map(s => (
          <div key={s.label} className="border rounded-xl p-4 bg-card flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
              <s.icon className="w-4 h-4 text-muted-foreground" />
            </div>
            <div>
              <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[11px] text-muted-foreground">{s.label}</p>
            </div>
          </div>
        ))}
      </motion.div>

      <motion.div {...fadeIn(2)} className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search by patient or bed..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </motion.div>

      <motion.div {...fadeIn(3)} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.length === 0 ? (
          <div className="col-span-full py-12 text-center text-sm text-muted-foreground">No IPD patients. Admissions appear here when patients are admitted from Reception.</div>
        ) : filtered.map(p => {
          const cond = conditionStyle[p.status] || conditionStyle.admitted;
          return (
            <div key={p.id} onClick={() => navigate(`/doctor/ipd/${p.id}`)}
              className="border rounded-xl p-4 bg-card hover:shadow-md transition-all cursor-pointer">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-bold bg-muted px-2 py-0.5 rounded">{p.bed}</span>
                <span className={`w-2 h-2 rounded-full ${cond.dot}`} />
              </div>
              <p className="text-sm font-semibold">{p.name}</p>
              <p className="text-[11px] text-muted-foreground">{p.age}y/{p.gender} · Day {p.daysAdmitted}</p>
              <p className="text-[11px] text-muted-foreground truncate mt-0.5">{p.diagnosis}</p>
              <div className="flex items-center justify-between mt-2">
                <span className={`text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full ${cond.badge}`}>{p.status}</span>
                <span className="text-[10px] text-muted-foreground">{p.ward}</span>
              </div>
            </div>
          );
        })}
      </motion.div>
    </div>
  );
}
