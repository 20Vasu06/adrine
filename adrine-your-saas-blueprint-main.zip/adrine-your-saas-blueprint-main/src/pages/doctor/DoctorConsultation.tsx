import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Sparkles, Monitor, Tablet, Mic } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ConsultationVitals from './consultation/ConsultationVitals';
import ConsultationComplaints, { type Complaint } from './consultation/ConsultationComplaints';
import ConsultationDiagnosis, { type Diagnosis } from './consultation/ConsultationDiagnosis';
import ConsultationExamination, { type ExamFindings } from './consultation/ConsultationExamination';
import ConsultationOrders, { type LabTest, type RadiologyOrder, type ProcedureOrder } from './consultation/ConsultationOrders';
import ConsultationMedications, { type Medication } from './consultation/ConsultationMedications';
import ConsultationRightPanel from './consultation/ConsultationRightPanel';
import PrescriptionPreview from './consultation/PrescriptionPreview';
import ConsultationAIScribe from './consultation/ConsultationAIScribe';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

export default function DoctorConsultation() {
  const { patientId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const orgId = user?.orgId;

  const [patient, setPatient] = useState<any>(null);

  useEffect(() => {
    if (!orgId || !patientId) return;
    supabase.from('patients').select('*').eq('org_id', orgId).eq('uhid', patientId).maybeSingle()
      .then(({ data }) => setPatient(data));
  }, [orgId, patientId]);

  const patientName = patient?.name ?? 'Patient';
  const patientInfo = patient
    ? `${patient.age}y / ${patient.gender}  •  UHID: ${patient.uhid}  •  ${patient.phone}`
    : `UHID: ${patientId}`;
  const patientAllergies = patient?.allergies ? patient.allergies.split(',').map((a: string) => a.trim()) : [];

  const [vitals, setVitals] = useState({ bp: '120/80', spo2: '98', temp: '98.6', pulse: '72', weight: '70', sugar: '110', height: '170', rr: '18', bmi: '24.2' });
  const [complaints, setComplaints] = useState<Complaint[]>([{ id: '1', text: 'Fever and headache', duration: '2 days', severity: 'moderate' }]);
  const [hpiNotes, setHpiNotes] = useState('');
  const [examFindings, setExamFindings] = useState<ExamFindings>({ general: '', cardiovascular: '', respiratory: '', neurological: '', abdominal: '', musculoskeletal: '', ent: '', dermatological: '' });
  const [diagnoses, setDiagnoses] = useState<Diagnosis[]>([]);
  const [labTests, setLabTests] = useState<LabTest[]>([]);
  const [radiologyOrders, setRadiologyOrders] = useState<RadiologyOrder[]>([]);
  const [procedures, setProcedures] = useState<ProcedureOrder[]>([]);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [treatmentPlan, setTreatmentPlan] = useState('');
  const [advice, setAdvice] = useState('');
  const [privateNotes, setPrivateNotes] = useState('');
  const [followUpDays, setFollowUpDays] = useState('15');
  const [followUpUnit, setFollowUpUnit] = useState('Days');
  const [viewMode, setViewMode] = useState<'Digital' | 'Tablet'>('Digital');
  const [leftTab, setLeftTab] = useState<'clinical' | 'orders'>('clinical');
  const [showPreview, setShowPreview] = useState(false);
  const [showAIScribe, setShowAIScribe] = useState(false);

  const handleAIScribeApply = (result: any) => {
    if (result.complaints.length > 0) setComplaints(result.complaints);
    if (result.diagnoses.length > 0) setDiagnoses(result.diagnoses);
    if (result.medications.length > 0) setMedications(result.medications);
    if (result.labTests.length > 0) setLabTests(result.labTests);
    if (result.radiologyOrders.length > 0) setRadiologyOrders(result.radiologyOrders);
    if (result.advice) setAdvice(result.advice);
    if (result.followUpDays) setFollowUpDays(result.followUpDays);
    if (result.vitals) {
      setVitals(prev => {
        const updated = { ...prev };
        Object.entries(result.vitals).forEach(([k, v]) => {
          if (v && typeof v === 'string' && v.trim()) (updated as any)[k] = v;
        });
        return updated;
      });
    }
  };

  const handleSaveConsultation = async () => {
    if (!orgId || !patientId) return;
    const department = patient?.department || 'General Medicine';
    const doctorName = user?.name || 'Dr. Doctor';

    // Save consultation
    await supabase.from('consultations').insert({
      org_id: orgId,
      patient_id: patient?.id,
      patient_name: patientName,
      doctor: doctorName,
      department,
      complaints: complaints.map(c => c.text).join(', '),
      diagnosis: diagnoses.map(d => d.text).join(', '),
      examination: Object.values(examFindings).filter(Boolean).join('; '),
      vitals: vitals as any,
      notes: advice,
      consultation_fee: 800,
    });

    // Save lab orders
    for (const t of labTests) {
      const orderNo = `LAB-${Date.now().toString(36).toUpperCase()}`;
      await supabase.from('lab_orders').insert({
        org_id: orgId, patient_id: patient?.id, patient_name: patientName,
        order_no: orderNo, tests: t.text, category: 'General', doctor: doctorName,
        priority: (t.priority === 'stat' ? 'Emergency' : t.priority === 'urgent' ? 'Urgent' : 'Routine') as any,
      });
    }

    // Save radiology orders
    for (const r of radiologyOrders) {
      const orderNo = `RAD-${Date.now().toString(36).toUpperCase()}`;
      await supabase.from('radiology_orders').insert({
        org_id: orgId, patient_id: patient?.id, patient_name: patientName,
        order_no: orderNo, study: `${r.type} - ${r.bodyPart}`, modality: r.type, doctor: doctorName,
        priority: (r.priority === 'urgent' ? 'Urgent' : 'Routine') as any,
      });
    }

    // Save prescription
    if (medications.length > 0) {
      const rxNo = `RX-${Date.now().toString(36).toUpperCase()}`;
      await supabase.from('prescriptions').insert({
        org_id: orgId, patient_id: patient?.id, patient_name: patientName,
        rx_no: rxNo, doctor: doctorName, department,
        medications: medications.map(m => ({ drug: m.name, dosage: m.dosage, frequency: m.frequency || 'OD', duration: m.duration || '7 days', route: m.route || 'Oral', qty: 10 })) as any,
      });
    }

    // Create invoice
    const invoiceNo = `INV-${Date.now().toString(36).toUpperCase()}`;
    await supabase.from('invoices').insert({
      org_id: orgId, patient_id: patient?.id, patient_name: patientName,
      invoice_no: invoiceNo, category: 'OPD' as any,
      items: [{ description: 'Consultation Fee', amount: 800 }] as any,
      total: 800,
    });

    toast.success('Consultation saved successfully');
    navigate(-1);
  };

  return (
    <div className="space-y-4">
      <motion.div {...fadeIn(0)} className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-accent transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl font-bold tracking-tight">{patientName}</h1>
            <p className="text-sm text-muted-foreground">{patientInfo}</p>
            {patientAllergies.length > 0 && (
              <div className="flex items-center gap-1 mt-0.5">
                <span className="text-[10px] font-semibold text-destructive bg-destructive/10 px-1.5 py-0.5 rounded-full">
                  ⚠ Allergy: {patientAllergies.join(', ')}
                </span>
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex border rounded-lg overflow-hidden">
            <button onClick={() => setViewMode('Digital')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium transition-colors ${viewMode === 'Digital' ? 'bg-muted text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              <Monitor className="w-3.5 h-3.5" /> Digital
            </button>
            <button onClick={() => setViewMode('Tablet')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium transition-colors ${viewMode === 'Tablet' ? 'bg-muted text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              <Tablet className="w-3.5 h-3.5" /> Tablet
            </button>
          </div>
          <Button size="sm" variant="outline" className="gap-1.5">
            <Mic className="w-3.5 h-3.5" /> Voice Dictation
          </Button>
          <Button size="sm" className="gap-1.5 bg-foreground text-background hover:bg-foreground/90" onClick={() => setShowAIScribe(true)}>
            <Sparkles className="w-3.5 h-3.5" /> AI Scribe
          </Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr_280px] gap-4">
        <motion.div {...fadeIn(1)} className="space-y-1">
          <div className="flex border rounded-lg overflow-hidden mb-3">
            <button onClick={() => setLeftTab('clinical')}
              className={`flex-1 px-3 py-1.5 text-xs font-medium transition-colors ${leftTab === 'clinical' ? 'bg-muted text-foreground' : 'text-muted-foreground'}`}>
              Clinical
            </button>
            <button onClick={() => setLeftTab('orders')}
              className={`flex-1 px-3 py-1.5 text-xs font-medium transition-colors ${leftTab === 'orders' ? 'bg-muted text-foreground' : 'text-muted-foreground'}`}>
              Orders
            </button>
          </div>

          {leftTab === 'clinical' ? (
            <div className="space-y-3 max-h-[calc(100vh-200px)] overflow-y-auto pr-1">
              <ConsultationVitals vitals={vitals} onChange={setVitals} />
              <ConsultationComplaints complaints={complaints} onChange={setComplaints} hpiNotes={hpiNotes} onHPIChange={setHpiNotes} />
              <ConsultationExamination findings={examFindings} onChange={setExamFindings} />
              <ConsultationDiagnosis diagnoses={diagnoses} onChange={setDiagnoses} />
            </div>
          ) : (
            <div className="space-y-3 max-h-[calc(100vh-200px)] overflow-y-auto pr-1">
              <ConsultationOrders
                labTests={labTests} onLabChange={setLabTests}
                radiologyOrders={radiologyOrders} onRadiologyChange={setRadiologyOrders}
                procedures={procedures} onProcedureChange={setProcedures}
              />
            </div>
          )}
        </motion.div>

        <motion.div {...fadeIn(2)}>
          <ConsultationMedications medications={medications} onChange={setMedications} allergies={patientAllergies} />
        </motion.div>

        <motion.div {...fadeIn(3)} className="max-h-[calc(100vh-200px)] overflow-y-auto pr-1">
          <ConsultationRightPanel
            advice={advice} onAdviceChange={setAdvice}
            privateNotes={privateNotes} onPrivateNotesChange={setPrivateNotes}
            followUpDays={followUpDays} onFollowUpDaysChange={setFollowUpDays}
            followUpUnit={followUpUnit} onFollowUpUnitChange={setFollowUpUnit}
            treatmentPlan={treatmentPlan} onTreatmentPlanChange={setTreatmentPlan}
            onSave={handleSaveConsultation} onDraft={() => {}}
            onPreview={() => setShowPreview(true)}
          />
        </motion.div>
      </div>

      <ConsultationAIScribe
        open={showAIScribe}
        onClose={() => setShowAIScribe(false)}
        onApply={handleAIScribeApply}
        patientName={patientName}
      />

      <PrescriptionPreview
        open={showPreview}
        onClose={() => setShowPreview(false)}
        data={{
          patientName,
          patientAge: patient?.age ?? 0,
          patientGender: patient?.gender ?? 'Male',
          uhid: patientId || '',
          phone: patient?.phone,
          doctorName: user?.name || 'Dr. Doctor',
          department: patient?.department || 'General Medicine',
          vitals,
          complaints,
          diagnoses,
          medications,
          labTests,
          radiologyOrders,
          advice,
          followUpDays,
          followUpUnit,
        }}
      />
    </div>
  );
}
