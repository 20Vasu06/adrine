import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Scan, Clock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

const statusStyle: Record<string, string> = {
  Ordered: 'bg-muted text-muted-foreground',
  Scheduled: 'bg-blue-500/10 text-blue-600',
  'In Progress': 'bg-amber-500/10 text-amber-600',
  Completed: 'bg-emerald-500/10 text-emerald-600',
  Reported: 'bg-foreground/10 text-foreground',
};

const priorityStyle: Record<string, string> = {
  Routine: 'text-muted-foreground',
  Urgent: 'text-amber-600',
  Emergency: 'text-destructive font-bold',
};

const filters = ['All', 'Ordered', 'In Progress', 'Completed', 'Reported'];

export default function DoctorRadiology() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [radiologyOrders, setRadiologyOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const [selected, setSelected] = useState<any>(null);

  useEffect(() => {
    if (!orgId) return;
    supabase.from('radiology_orders').select('*').eq('org_id', orgId).order('order_time', { ascending: false })
      .then(({ data }) => { setRadiologyOrders(data || []); setSelected(data?.[0] || null); setLoading(false); });
  }, [orgId]);

  const filtered = radiologyOrders.filter(o => {
    const matchSearch = o.patient_name.toLowerCase().includes(search.toLowerCase()) || o.order_no.toLowerCase().includes(search.toLowerCase()) || o.modality.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'All' || o.status === filter;
    return matchSearch && matchFilter;
  });

  const summary = {
    total: radiologyOrders.length,
    pending: radiologyOrders.filter(o => o.status === 'Ordered' || o.status === 'Scheduled').length,
    inProgress: radiologyOrders.filter(o => o.status === 'In Progress').length,
    reported: radiologyOrders.filter(o => o.status === 'Reported' || o.status === 'Completed').length,
  };

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6">
      <motion.div {...fadeIn(0)}>
        <h1 className="text-2xl font-bold tracking-tight">Radiology Orders</h1>
        <p className="text-sm text-muted-foreground mt-1">Track imaging requests and view reports</p>
      </motion.div>

      <motion.div {...fadeIn(1)} className="grid grid-cols-4 gap-3">
        {[
          { label: 'Total Orders', value: summary.total, color: '' },
          { label: 'Pending', value: summary.pending, color: 'text-blue-600' },
          { label: 'In Progress', value: summary.inProgress, color: 'text-amber-600' },
          { label: 'Reported', value: summary.reported, color: 'text-emerald-600' },
        ].map(s => (
          <div key={s.label} className="border rounded-xl p-4 bg-card text-center">
            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{s.label}</p>
          </div>
        ))}
      </motion.div>

      <motion.div {...fadeIn(2)} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search by patient, order ID, or modality..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="flex gap-1.5">
          {filters.map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filter === f ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {f}
            </button>
          ))}
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <motion.div {...fadeIn(3)} className="lg:col-span-1 border rounded-xl bg-card overflow-hidden">
          <div className="divide-y max-h-[600px] overflow-y-auto">
            {filtered.length === 0 && <p className="text-sm text-muted-foreground text-center py-12">No radiology orders found</p>}
            {filtered.map(o => (
              <div key={o.id} onClick={() => setSelected(o)}
                className={`px-4 py-3 hover:bg-accent/50 transition-colors cursor-pointer ${selected?.id === o.id ? 'bg-accent/70' : ''}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono font-semibold text-muted-foreground">{o.order_no}</span>
                  <span className={`text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full ${statusStyle[o.status] || 'bg-muted text-muted-foreground'}`}>{o.status}</span>
                </div>
                <p className="text-xs font-semibold">{o.patient_name}</p>
                <p className="text-[11px] text-muted-foreground">{o.modality} — {o.study}</p>
                <div className="flex items-center justify-between mt-1.5">
                  <span className="text-[10px] text-muted-foreground">{new Date(o.order_time).toLocaleString()}</span>
                  <span className={`text-[10px] uppercase ${priorityStyle[o.priority] || ''}`}>{o.priority}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div {...fadeIn(4)} className="lg:col-span-2 border rounded-xl bg-card">
          {selected ? (
            <div className="p-5 space-y-5">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold">{selected.modality} — {selected.study}</h3>
                  <span className={`text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full ${statusStyle[selected.status] || 'bg-muted text-muted-foreground'}`}>{selected.status}</span>
                </div>
                <p className="text-xs text-muted-foreground">{selected.patient_name}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">Ordered: {new Date(selected.order_time).toLocaleString()} · Priority: <span className={priorityStyle[selected.priority] || ''}>{selected.priority}</span></p>
                <p className="text-xs mt-2"><span className="text-muted-foreground">Doctor:</span> {selected.doctor}</p>
              </div>

              {selected.status === 'Reported' || selected.status === 'Completed' ? (
                <div className="border rounded-lg p-4">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Status</p>
                  <p className="text-sm leading-relaxed">{selected.status === 'Reported' ? 'Report available' : 'Imaging completed, report pending'}</p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16">
                  <Clock className="w-8 h-8 text-muted-foreground mb-3" />
                  <p className="text-sm font-medium">Report Pending</p>
                  <p className="text-xs text-muted-foreground mt-1">Status: {selected.status}</p>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20">
              <Scan className="w-8 h-8 text-muted-foreground mb-3" />
              <p className="text-sm font-medium">Select an order</p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
