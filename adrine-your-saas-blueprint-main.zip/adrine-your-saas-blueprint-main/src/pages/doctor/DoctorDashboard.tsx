import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Users, CalendarDays, FlaskConical, Building2,
  ArrowUpRight, ArrowDownRight, ChevronRight
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

const statusStyle: Record<string, string> = {
  completed: 'bg-emerald-500/10 text-emerald-600',
  in_consultation: 'bg-blue-500/10 text-blue-600',
  waiting: 'bg-amber-500/10 text-amber-600',
  scheduled: 'bg-muted text-muted-foreground',
  called: 'bg-amber-500/10 text-amber-600',
};

export default function DoctorDashboard() {
  const { user } = useAuth();
  const [patients, setPatients] = useState<any[]>([]);
  const [queue, setQueue] = useState<any[]>([]);
  const [labOrders, setLabOrders] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);

  useEffect(() => {
    if (!user?.orgId) return;
    const orgId = user.orgId;
    const todayStr = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('patients').select('*').eq('org_id', orgId).limit(100),
      supabase.from('queue_entries').select('*').eq('org_id', orgId).order('token_no'),
      supabase.from('lab_orders').select('*').eq('org_id', orgId).order('order_time', { ascending: false }).limit(50),
      supabase.from('appointments').select('*').eq('org_id', orgId).eq('date', todayStr),
      supabase.from('invoices').select('*').eq('org_id', orgId).limit(20),
    ]).then(([p, q, l, a, i]) => {
      setPatients(p.data || []);
      setQueue(q.data || []);
      setLabOrders(l.data || []);
      setAppointments(a.data || []);
      setInvoices(i.data || []);
    });
  }, [user?.orgId]);

  const waitingQueue = queue.filter(q => q.status === 'waiting').length;
  const completedQueue = queue.filter(q => q.status === 'completed').length;
  const pendingLabs = labOrders.filter(l => l.stage !== 'Validated' && l.stage !== 'Reported');

  const stats = [
    { label: 'My Patients', value: String(patients.length), change: `${appointments.length} today`, up: true, icon: Users },
    { label: 'OPD Queue', value: String(waitingQueue), change: `${completedQueue} done`, up: waitingQueue > 0, icon: CalendarDays },
    { label: 'Pending Reports', value: String(pendingLabs.length), change: `${labOrders.filter(l => l.stage === 'Validated').length} validated`, up: true, icon: FlaskConical },
    { label: 'Total Invoices', value: String(invoices.length), change: `₹${invoices.reduce((s, i) => s + Number(i.total), 0).toLocaleString('en-IN')}`, up: true, icon: Building2 },
  ];

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

  return (
    <div className="space-y-6">
      <motion.div {...fadeIn(0)}>
        <h1 className="text-2xl font-bold tracking-tight">
          {greeting}, {user?.name ?? 'Doctor'}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })} — You have <span className="font-semibold text-foreground">{appointments.length} appointments</span> today
        </p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <motion.div key={s.label} {...fadeIn(i + 1)} className="border rounded-xl p-5 bg-card hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center">
                <s.icon className="w-4 h-4 text-muted-foreground" />
              </div>
              <span className={`flex items-center gap-0.5 text-xs font-semibold ${s.up ? 'text-emerald-600' : 'text-amber-600'}`}>
                {s.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                {s.change}
              </span>
            </div>
            <p className="text-2xl font-bold tracking-tight">{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <motion.div {...fadeIn(5)} className="lg:col-span-2 border rounded-xl bg-card overflow-hidden">
          <div className="p-4 border-b">
            <h2 className="font-semibold text-sm">OPD Queue</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{queue.length} patients</p>
          </div>
          <div className="divide-y">
            {queue.length === 0 ? (
              <div className="py-12 text-center text-sm text-muted-foreground">No patients in queue yet.</div>
            ) : queue.slice(0, 8).map(q => (
              <div key={q.id} className="flex items-center gap-3 px-4 py-3 hover:bg-accent/50 transition-colors">
                <span className="text-xs font-mono font-medium text-muted-foreground w-12 shrink-0">#{q.token_no}</span>
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                  <span className="text-xs font-semibold">{q.patient_name.split(' ').map((n: string) => n[0]).join('')}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{q.patient_name}</p>
                  <p className="text-[11px] text-muted-foreground">{q.department} · {q.doctor}</p>
                </div>
                <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full ${statusStyle[q.status] || 'bg-muted text-muted-foreground'}`}>
                  {q.status.replace('_', ' ')}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        <div className="space-y-4">
          <motion.div {...fadeIn(6)} className="border rounded-xl bg-card overflow-hidden">
            <div className="p-4 border-b flex items-center justify-between">
              <h2 className="font-semibold text-sm flex items-center gap-1.5">
                <FlaskConical className="w-3.5 h-3.5 text-muted-foreground" /> Pending Lab Reports
              </h2>
              <span className="text-[11px] font-medium bg-muted px-2 py-0.5 rounded-full">{pendingLabs.length}</span>
            </div>
            <div className="divide-y">
              {pendingLabs.length === 0 ? (
                <div className="py-8 text-center text-xs text-muted-foreground">No pending lab orders</div>
              ) : pendingLabs.slice(0, 5).map(lab => (
                <div key={lab.id} className="flex items-center gap-3 px-4 py-2.5 hover:bg-accent/50 transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium truncate">{lab.patient_name}</p>
                    <p className="text-[11px] text-muted-foreground">{lab.tests}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`text-[10px] font-semibold uppercase ${lab.priority === 'Emergency' ? 'text-destructive' : lab.priority === 'Urgent' ? 'text-amber-600' : 'text-muted-foreground'}`}>
                      {lab.priority}
                    </span>
                    <p className="text-[10px] text-muted-foreground">{lab.stage}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
