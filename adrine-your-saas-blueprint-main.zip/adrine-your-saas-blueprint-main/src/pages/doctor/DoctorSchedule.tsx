import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Plus, Clock, User, MapPin, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const hours = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];

const typeColors: Record<string, { bg: string; border: string; text: string }> = {
  opd: { bg: 'bg-foreground/5', border: 'border-foreground/20', text: 'text-foreground' },
  'ipd-rounds': { bg: 'bg-blue-500/10', border: 'border-blue-500/30', text: 'text-blue-700' },
  surgery: { bg: 'bg-destructive/10', border: 'border-destructive/30', text: 'text-destructive' },
  break: { bg: 'bg-muted', border: 'border-border', text: 'text-muted-foreground' },
  meeting: { bg: 'bg-amber-500/10', border: 'border-amber-500/30', text: 'text-amber-700' },
};

export default function DoctorSchedule() {
  const { user } = useAuth();
  const [weekOffset, setWeekOffset] = useState(0);
  const [schedules, setSchedules] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.orgId) return;
    const load = async () => {
      setLoading(true);
      const { data } = await supabase.from('doctor_schedules').select('*').eq('org_id', user.orgId).eq('is_active', true);
      setSchedules(data || []);
      setLoading(false);
    };
    load();
  }, [user?.orgId]);

  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay() + 1 + weekOffset * 7);

  const dateLabels = days.map((_, i) => {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + i);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  });

  const isToday = (dayIdx: number) => {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + dayIdx);
    return d.toDateString() === today.toDateString();
  };

  // Map DB schedules to grid slots
  const slots = schedules.map(s => ({
    id: s.id,
    day: s.day_of_week,
    startHour: parseInt(s.start_time?.split(':')[0] || '9'),
    endHour: parseInt(s.end_time?.split(':')[0] || '17'),
    duration: Math.max(1, parseInt(s.end_time?.split(':')[0] || '17') - parseInt(s.start_time?.split(':')[0] || '9')),
    type: 'opd',
    title: `${s.doctor_name} - ${s.department}`,
    location: s.room || '',
    patients: s.max_patients || 0,
  }));

  const opdSlots = slots.filter(s => s.type === 'opd').length;
  const totalPatients = slots.reduce((sum, s) => sum + (s.patients || 0), 0);

  return (
    <div className="space-y-6">
      <motion.div {...fadeIn(0)} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Weekly Schedule</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage clinic hours and rounds</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setWeekOffset(w => w - 1)}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <button onClick={() => setWeekOffset(0)} className="text-xs font-medium px-3 py-1.5 rounded-lg bg-muted hover:bg-accent transition-colors">
            This Week
          </button>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setWeekOffset(w => w + 1)}>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </motion.div>

      <motion.div {...fadeIn(1)} className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Schedule Slots', value: String(schedules.length), sub: `${opdSlots} OPD slots` },
          { label: 'Max Patients', value: String(totalPatients), sub: 'across all slots' },
          { label: 'Active Schedules', value: String(schedules.filter(s => s.is_active).length), sub: 'currently active' },
          { label: 'Departments', value: String(new Set(schedules.map(s => s.department)).size), sub: 'departments covered' },
        ].map(s => (
          <div key={s.label} className="border rounded-xl p-4 bg-card">
            <p className="text-xl font-bold">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">{s.sub}</p>
          </div>
        ))}
      </motion.div>

      {loading ? (
        <div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : (
        <motion.div {...fadeIn(2)} className="border rounded-xl bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <div className="min-w-[900px]">
              <div className="grid grid-cols-[60px_repeat(7,1fr)] border-b">
                <div className="p-2" />
                {days.map((day, i) => (
                  <div key={day} className={`p-3 text-center border-l ${isToday(i) ? 'bg-foreground/5' : ''}`}>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wider">{day.slice(0, 3)}</p>
                    <p className={`text-sm font-semibold mt-0.5 ${isToday(i) ? 'text-foreground' : 'text-muted-foreground'}`}>{dateLabels[i]}</p>
                  </div>
                ))}
              </div>

              {hours.map((hour, hIdx) => (
                <div key={hour} className="grid grid-cols-[60px_repeat(7,1fr)] border-b last:border-b-0">
                  <div className="p-2 text-[11px] text-muted-foreground font-mono text-right pr-3 pt-3">{hour}</div>
                  {days.map((_, dayIdx) => {
                    const slot = slots.find(s => s.day === dayIdx && s.startHour === hIdx + 9);
                    const isCovered = slots.find(s => s.day === dayIdx && s.startHour < hIdx + 9 && s.startHour + s.duration > hIdx + 9);

                    if (isCovered) return <div key={dayIdx} className="border-l" />;

                    if (slot) {
                      const colors = typeColors[slot.type] || typeColors.opd;
                      return (
                        <div key={dayIdx} className={`border-l p-1.5 ${isToday(dayIdx) ? 'bg-foreground/[0.02]' : ''}`}>
                          <div className={`${colors.bg} border ${colors.border} rounded-lg p-2 h-full cursor-pointer hover:shadow-sm transition-shadow`}>
                            <p className={`text-[11px] font-semibold ${colors.text} truncate`}>{slot.title}</p>
                            {slot.location && (
                              <p className="text-[10px] text-muted-foreground flex items-center gap-0.5 mt-0.5">
                                <MapPin className="w-2.5 h-2.5" /> {slot.location}
                              </p>
                            )}
                            {slot.patients > 0 && (
                              <p className="text-[10px] text-muted-foreground flex items-center gap-0.5 mt-0.5">
                                <User className="w-2.5 h-2.5" /> {slot.patients} patients max
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    }

                    return <div key={dayIdx} className={`border-l min-h-[60px] ${isToday(dayIdx) ? 'bg-foreground/[0.02]' : ''}`} />;
                  })}
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {schedules.length === 0 && !loading && (
        <div className="text-center py-8">
          <p className="text-sm text-muted-foreground">No schedules configured. Add doctor schedules from Admin settings.</p>
        </div>
      )}
    </div>
  );
}
