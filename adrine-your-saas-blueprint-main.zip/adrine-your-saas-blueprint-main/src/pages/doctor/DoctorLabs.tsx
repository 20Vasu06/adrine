import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, FlaskConical, Clock, Eye, Download, FileText } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

const statusStyle: Record<string, string> = {
  'Pending Analysis': 'bg-muted text-muted-foreground',
  'In Analysis': 'bg-amber-500/10 text-amber-600',
  'Awaiting Validation': 'bg-blue-500/10 text-blue-600',
  'Validated': 'bg-emerald-500/10 text-emerald-600',
  'Reported': 'bg-emerald-500/10 text-emerald-600',
};

const filters = ['All', 'Pending Analysis', 'In Analysis', 'Validated'];

export default function DoctorLabs() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [labOrders, setLabOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    if (!orgId) return;
    supabase.from('lab_orders').select('*').eq('org_id', orgId).order('order_time', { ascending: false })
      .then(({ data }) => { setLabOrders(data || []); setLoading(false); });
  }, [orgId]);

  const filtered = labOrders.filter(l => {
    const matchSearch = l.patient_name.toLowerCase().includes(search.toLowerCase()) ||
      l.tests.toLowerCase().includes(search.toLowerCase()) ||
      l.order_no.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'All' || l.stage === filter;
    return matchSearch && matchFilter;
  });

  const summary = {
    total: labOrders.length,
    pending: labOrders.filter(l => l.stage === 'Pending Analysis').length,
    inAnalysis: labOrders.filter(l => l.stage === 'In Analysis').length,
    validated: labOrders.filter(l => l.stage === 'Validated' || l.stage === 'Reported').length,
  };

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6">
      <motion.div {...fadeIn(0)} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Lab Orders & Results</h1>
          <p className="text-sm text-muted-foreground mt-1">Track investigations and review reports</p>
        </div>
      </motion.div>

      <motion.div {...fadeIn(1)} className="grid grid-cols-4 gap-3">
        {[
          { label: 'Total Orders', value: summary.total, color: '' },
          { label: 'Pending', value: summary.pending, color: 'text-muted-foreground' },
          { label: 'In Analysis', value: summary.inAnalysis, color: 'text-amber-600' },
          { label: 'Validated', value: summary.validated, color: 'text-emerald-600' },
        ].map(s => (
          <div key={s.label} className="border rounded-xl p-4 bg-card text-center">
            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{s.label}</p>
          </div>
        ))}
      </motion.div>

      <motion.div {...fadeIn(2)} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search by patient, test, or lab ID..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="flex gap-1.5">
          {filters.map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filter === f ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {f}
            </button>
          ))}
        </div>
      </motion.div>

      <motion.div {...fadeIn(3)} className="border rounded-xl bg-card overflow-hidden">
        <div className="divide-y max-h-[600px] overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">No lab orders found.</div>
          ) : filtered.map(lab => (
            <div key={lab.id} className="px-4 py-3 hover:bg-accent/50 transition-colors cursor-pointer">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono font-semibold text-muted-foreground">{lab.order_no}</span>
                <span className={`text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full ${statusStyle[lab.stage] || 'bg-muted text-muted-foreground'}`}>
                  {lab.stage}
                </span>
              </div>
              <p className="text-xs font-semibold">{lab.patient_name}</p>
              <p className="text-[11px] text-muted-foreground">{lab.tests}</p>
              <div className="flex items-center justify-between mt-1.5">
                <span className="text-[10px] text-muted-foreground">{new Date(lab.order_time).toLocaleString()}</span>
                <span className={`text-[10px] uppercase ${lab.priority === 'Emergency' ? 'text-destructive font-bold' : lab.priority === 'Urgent' ? 'text-amber-600' : 'text-muted-foreground'}`}>{lab.priority}</span>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
