import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Phone, Mail, MapPin, AlertCircle, Activity, Calendar, FileText, Pill, CreditCard, Syringe, Heart, ShieldCheck, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

const tabOptions = ['History', 'Prescriptions', 'Labs', 'Medical History', 'ABDM'];

export default function DoctorPatientProfile() {
  const { patientId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('History');
  const [patient, setPatient] = useState<any>(null);
  const [consultations, setConsultations] = useState<any[]>([]);
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [labOrders, setLabOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!patientId || !user?.orgId) return;
    const orgId = user.orgId;

    const load = async () => {
      setLoading(true);
      const [pRes, cRes, rxRes, lRes] = await Promise.all([
        supabase.from('patients').select('*').eq('id', patientId).eq('org_id', orgId).single(),
        supabase.from('consultations').select('*').eq('patient_id', patientId).eq('org_id', orgId).order('date', { ascending: false }),
        supabase.from('prescriptions').select('*').eq('patient_id', patientId).eq('org_id', orgId).order('created_at', { ascending: false }),
        supabase.from('lab_orders').select('*').eq('patient_id', patientId).eq('org_id', orgId).order('order_time', { ascending: false }),
      ]);
      if (pRes.data) setPatient(pRes.data);
      if (cRes.data) setConsultations(cRes.data);
      if (rxRes.data) setPrescriptions(rxRes.data);
      if (lRes.data) setLabOrders(lRes.data);
      setLoading(false);
    };
    load();
  }, [patientId, user?.orgId]);

  if (loading || !patient) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const initials = patient.name.split(' ').map((n: string) => n[0]).join('').toUpperCase();
  const allergiesList = patient.allergies ? patient.allergies.split(',').map((a: string) => a.trim()).filter(Boolean) : [];
  const chronicList = patient.chronic_diseases ? patient.chronic_diseases.split(',').map((d: string) => d.trim()).filter(Boolean) : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div {...fadeIn(0)} className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/doctor/patients')} className="p-2 rounded-lg hover:bg-accent transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center border">
            <span className="text-lg font-bold">{initials}</span>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">{patient.name}</h1>
            <p className="text-sm text-muted-foreground">
              <span className="font-mono text-xs">{patient.uhid}</span>
              <span className="mx-2">·</span>{patient.age}y
              <span className="mx-2">·</span>{patient.gender}
              {patient.blood_group && <><span className="mx-2">·</span>{patient.blood_group}</>}
              {patient.abha_id && <><span className="mx-2">·</span><span className="text-blue-600 font-medium">◯ {patient.abha_id}</span></>}
            </p>
          </div>
        </div>
        <Button size="sm" className="gap-1.5 bg-foreground text-background hover:bg-foreground/90"
          onClick={() => navigate(`/doctor/consultation/${patient.id}`)}>
          Start Consultation
        </Button>
      </motion.div>

      {/* 3-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr_280px] gap-5">
        {/* Left Column */}
        <motion.div {...fadeIn(1)} className="space-y-4">
          {/* Contact */}
          <div className="border rounded-xl bg-card p-4 space-y-3">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Contact</p>
            <div className="space-y-2.5">
              <div className="flex items-center gap-2.5 text-sm"><Phone className="w-4 h-4 text-muted-foreground" /><span>{patient.phone}</span></div>
            </div>
          </div>

          {/* Allergies */}
          {allergiesList.length > 0 && (
            <div className="border border-destructive/20 bg-destructive/5 rounded-xl p-4">
              <p className="text-[10px] uppercase tracking-wider text-destructive font-semibold flex items-center gap-1.5 mb-2">
                <AlertCircle className="w-3.5 h-3.5" /> Allergies
              </p>
              <div className="space-y-1.5">
                {allergiesList.map((a: string) => (
                  <div key={a} className="text-xs">
                    <span className="font-medium text-destructive border border-destructive/30 rounded-full px-2.5 py-0.5">{a}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Chronic Diseases */}
          {chronicList.length > 0 && (
            <div className="border rounded-xl bg-card p-4">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5 mb-2">
                <Heart className="w-3.5 h-3.5" /> Chronic Conditions
              </p>
              <div className="space-y-1">
                {chronicList.map((d: string) => (
                  <p key={d} className="text-xs text-foreground">{d}</p>
                ))}
              </div>
            </div>
          )}

          {/* Patient Info */}
          <div className="border rounded-xl bg-card p-4 space-y-2.5">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Details</p>
            {[
              { label: 'Category', value: patient.category },
              { label: 'Type', value: patient.patient_type },
              { label: 'Department', value: patient.department || '—' },
              { label: 'Doctor', value: patient.assigned_doctor || '—' },
              { label: 'Insurance', value: patient.insurance_provider || '—' },
            ].map(v => (
              <div key={v.label} className="flex items-center justify-between">
                <p className="text-[10px] text-muted-foreground uppercase">{v.label}</p>
                <p className="text-sm font-medium">{v.value}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Center — Tabs */}
        <motion.div {...fadeIn(2)} className="border rounded-xl bg-card overflow-hidden">
          <div className="border-b">
            <div className="flex overflow-x-auto">
              {tabOptions.map(tab => (
                <button key={tab} onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3 text-sm font-medium transition-colors relative whitespace-nowrap ${activeTab === tab ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                  {tab}
                  {activeTab === tab && <motion.div layoutId="patientTab" className="absolute inset-x-2 -bottom-px h-0.5 bg-foreground rounded-full" />}
                </button>
              ))}
            </div>
          </div>

          <div className="p-5">
            {/* Visit History (consultations) */}
            {activeTab === 'History' && (
              <div className="space-y-3">
                {consultations.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <Calendar className="w-8 h-8 text-muted-foreground mb-3" />
                    <p className="text-sm font-medium">No consultation history</p>
                  </div>
                ) : consultations.map((c, i) => (
                  <div key={c.id} className="flex items-start justify-between py-3 border-b last:border-0">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold">{new Date(c.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{c.complaints || c.diagnosis || 'Consultation'}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{c.doctor} · {c.department}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Prescriptions */}
            {activeTab === 'Prescriptions' && (
              <div className="space-y-4">
                {prescriptions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <Pill className="w-8 h-8 text-muted-foreground mb-3" />
                    <p className="text-sm font-medium">No prescriptions yet</p>
                  </div>
                ) : prescriptions.map((rx) => {
                  const meds = Array.isArray(rx.medications) ? rx.medications : [];
                  return (
                    <div key={rx.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="text-sm font-semibold">{new Date(rx.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                          <p className="text-xs text-muted-foreground">{rx.doctor} · {rx.rx_no}</p>
                        </div>
                        <span className={`text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded-full ${rx.status === 'Dispensed' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-amber-500/10 text-amber-600'}`}>{rx.status}</span>
                      </div>
                      <div className="space-y-1.5">
                        {meds.map((d: any, j: number) => (
                          <div key={j} className="flex items-center justify-between text-xs">
                            <span className="font-medium">{j + 1}. {d.drug}</span>
                            <span className="text-muted-foreground">{d.dosage} · {d.frequency} · {d.duration}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Labs */}
            {activeTab === 'Labs' && (
              <div className="space-y-2">
                {labOrders.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <Activity className="w-8 h-8 text-muted-foreground mb-3" />
                    <p className="text-sm font-medium">No lab results</p>
                  </div>
                ) : labOrders.map((lab) => (
                  <div key={lab.id} className="flex items-center justify-between py-2.5 border-b last:border-0">
                    <div>
                      <p className="text-sm font-medium">{lab.tests}</p>
                      <p className="text-xs text-muted-foreground">{new Date(lab.order_time).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })} · {lab.doctor}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded-full ${lab.stage === 'Reported' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-muted text-muted-foreground'}`}>{lab.stage}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Medical History */}
            {activeTab === 'Medical History' && (
              <div className="space-y-6">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Chronic Conditions</p>
                  {chronicList.length > 0 ? (
                    <div className="space-y-1">{chronicList.map((h: string) => <p key={h} className="text-sm">{h}</p>)}</div>
                  ) : <p className="text-sm text-muted-foreground">No chronic conditions recorded</p>}
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Allergies</p>
                  {allergiesList.length > 0 ? (
                    <div className="space-y-1">{allergiesList.map((a: string) => <p key={a} className="text-sm">{a}</p>)}</div>
                  ) : <p className="text-sm text-muted-foreground">No allergies recorded</p>}
                </div>
              </div>
            )}

            {/* ABDM */}
            {activeTab === 'ABDM' && (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <ShieldCheck className="w-8 h-8 text-muted-foreground mb-3" />
                <p className="text-sm font-medium">ABDM Integration</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {patient.abha_id ? `ABHA ID: ${patient.abha_id}` : 'No ABHA ID linked'}
                </p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Right Column — Quick Stats */}
        <motion.div {...fadeIn(3)} className="space-y-4">
          <div className="border rounded-xl bg-card p-4 text-center">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Total Visits</p>
            <p className="text-3xl font-bold">{consultations.length}</p>
          </div>
          <div className="border rounded-xl bg-card p-4 text-center">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Prescriptions</p>
            <p className="text-3xl font-bold">{prescriptions.length}</p>
          </div>
          <div className="border rounded-xl bg-card p-4 text-center">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Lab Orders</p>
            <p className="text-3xl font-bold">{labOrders.length}</p>
          </div>
          <div className="border rounded-xl bg-card p-4">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Registered</p>
            <p className="text-sm font-medium">{new Date(patient.registered_on).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
          </div>
          {patient.last_visit && (
            <div className="border rounded-xl bg-card p-4">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Last Visit</p>
              <p className="text-sm font-medium">{new Date(patient.last_visit).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
