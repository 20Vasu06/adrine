import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Heart, Activity, Droplets, Thermometer, Pill, FileText, Plus, BedDouble, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const fadeIn = (i: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.04, duration: 0.3 },
});

const conditionColors: Record<string, string> = {
  stable: 'bg-emerald-500/10 text-emerald-600',
  critical: 'bg-destructive/10 text-destructive',
  improving: 'bg-blue-500/10 text-blue-600',
  observation: 'bg-amber-500/10 text-amber-600',
  admitted: 'bg-blue-500/10 text-blue-600',
  discharged: 'bg-muted text-muted-foreground',
};

const tabOptions = ['Summary', 'Notes', 'Medications', 'Labs', 'Discharge'];

export default function DoctorIPDPatientProfile() {
  const { patientId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('Summary');
  const [admission, setAdmission] = useState<any>(null);
  const [patient, setPatient] = useState<any>(null);
  const [consultations, setConsultations] = useState<any[]>([]);
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [labOrders, setLabOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newNote, setNewNote] = useState('');
  const [showOTRequest, setShowOTRequest] = useState(false);
  const [otData, setOtData] = useState({ procedure: '', anesthetist: '', date: '', duration: '', equipment: '' });

  useEffect(() => {
    if (!patientId || !user?.orgId) return;
    const orgId = user.orgId;

    const load = async () => {
      setLoading(true);
      // patientId could be admission id or patient id - try admission first
      const { data: admData } = await supabase.from('admissions').select('*').eq('id', patientId).eq('org_id', orgId).single();
      
      if (admData) {
        setAdmission(admData);
        const [pRes, cRes, rxRes, lRes] = await Promise.all([
          supabase.from('patients').select('*').eq('id', admData.patient_id).eq('org_id', orgId).single(),
          supabase.from('consultations').select('*').eq('patient_id', admData.patient_id).eq('org_id', orgId).order('date', { ascending: false }),
          supabase.from('prescriptions').select('*').eq('patient_id', admData.patient_id).eq('org_id', orgId).order('created_at', { ascending: false }),
          supabase.from('lab_orders').select('*').eq('patient_id', admData.patient_id).eq('org_id', orgId).order('order_time', { ascending: false }),
        ]);
        if (pRes.data) setPatient(pRes.data);
        if (cRes.data) setConsultations(cRes.data);
        if (rxRes.data) setPrescriptions(rxRes.data);
        if (lRes.data) setLabOrders(lRes.data);
      }
      setLoading(false);
    };
    load();
  }, [patientId, user?.orgId]);

  if (loading) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  if (!admission) {
    return <div className="flex flex-col items-center justify-center py-20"><p className="text-sm text-muted-foreground">Admission not found</p></div>;
  }

  const daysAdmitted = Math.max(1, Math.ceil((Date.now() - new Date(admission.admission_date).getTime()) / (1000 * 60 * 60 * 24)));

  const handleSaveNote = async () => {
    if (!newNote.trim() || !user?.orgId || !patient) return;
    await supabase.from('consultations').insert({
      org_id: user.orgId,
      patient_id: admission.patient_id,
      patient_name: admission.patient_name,
      doctor: user.name || 'Doctor',
      department: admission.department,
      notes: newNote,
    });
    setNewNote('');
    toast.success('Note saved');
    // Refresh consultations
    const { data } = await supabase.from('consultations').select('*').eq('patient_id', admission.patient_id).eq('org_id', user.orgId).order('date', { ascending: false });
    if (data) setConsultations(data);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div {...fadeIn(0)} className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/doctor/ipd')} className="p-2 rounded-lg hover:bg-accent transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight">{admission.patient_name}</h1>
              <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full ${conditionColors[admission.status] || 'bg-muted text-muted-foreground'}`}>{admission.status}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {admission.admission_no} · Day {daysAdmitted} · {admission.department} · {admission.doctor}
              {admission.diagnosis && ` · ${admission.diagnosis}`}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowOTRequest(!showOTRequest)}>OT Request</Button>
          <Button size="sm" className="bg-foreground text-background hover:bg-foreground/90" onClick={() => setActiveTab('Discharge')}>Discharge</Button>
        </div>
      </motion.div>

      {/* OT Request Panel */}
      {showOTRequest && (
        <motion.div {...fadeIn(0)} className="border rounded-xl bg-card p-4">
          <p className="text-sm font-semibold mb-3 flex items-center gap-1.5"><BedDouble className="w-4 h-4" /> Operation Theatre Request</p>
          <div className="grid grid-cols-2 gap-3">
            <Input placeholder="Procedure type" value={otData.procedure} onChange={e => setOtData({ ...otData, procedure: e.target.value })} className="h-8 text-xs" />
            <Input placeholder="Anesthetist" value={otData.anesthetist} onChange={e => setOtData({ ...otData, anesthetist: e.target.value })} className="h-8 text-xs" />
            <Input type="date" value={otData.date} onChange={e => setOtData({ ...otData, date: e.target.value })} className="h-8 text-xs" />
            <Input placeholder="Est. duration" value={otData.duration} onChange={e => setOtData({ ...otData, duration: e.target.value })} className="h-8 text-xs" />
          </div>
          <Button size="sm" className="mt-3 text-xs" onClick={() => { toast.success('OT request submitted'); setShowOTRequest(false); }}>Submit OT Request</Button>
        </motion.div>
      )}

      {/* Info cards */}
      <motion.div {...fadeIn(1)} className="grid grid-cols-4 gap-4">
        {[
          { label: 'Admitted', value: new Date(admission.admission_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }), icon: Activity, color: 'text-blue-500' },
          { label: 'Day', value: `Day ${daysAdmitted}`, icon: Heart, color: 'text-red-500' },
          { label: 'Doctor', value: admission.doctor, icon: Droplets, color: 'text-amber-500' },
          { label: 'Department', value: admission.department, icon: Thermometer, color: 'text-orange-500' },
        ].map(v => (
          <div key={v.label} className="border rounded-xl bg-card p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
              <v.icon className={`w-5 h-5 ${v.color}`} />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{v.label}</p>
              <p className="text-sm font-bold truncate">{v.value}</p>
            </div>
          </div>
        ))}
      </motion.div>

      {/* Tabs */}
      <motion.div {...fadeIn(2)} className="border rounded-xl bg-card overflow-hidden">
        <div className="border-b">
          <div className="flex overflow-x-auto">
            {tabOptions.map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={`px-5 py-3 text-sm font-medium transition-colors relative whitespace-nowrap ${activeTab === tab ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                {tab}
                {activeTab === tab && <motion.div layoutId="ipdTab" className="absolute inset-x-2 -bottom-px h-0.5 bg-foreground rounded-full" />}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6">
          {activeTab === 'Summary' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-3">Admission Info</p>
                  <div className="space-y-2.5">
                    {[
                      { label: 'Admission No', value: admission.admission_no },
                      { label: 'Admitted', value: new Date(admission.admission_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) },
                      { label: 'Day', value: `Day ${daysAdmitted}` },
                      { label: 'Doctor', value: admission.doctor },
                      { label: 'Department', value: admission.department },
                    ].map(row => (
                      <div key={row.label} className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">{row.label}</span>
                        <span className="font-medium">{row.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-3">Diagnosis</p>
                  <p className="text-sm">{admission.diagnosis || 'Not specified'}</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'Notes' && (
            <div className="space-y-4">
              <div className="border rounded-lg p-4 bg-accent/20">
                <p className="text-xs font-semibold mb-2">Add Clinical Note</p>
                <Textarea placeholder="Write clinical note..." value={newNote} onChange={e => setNewNote(e.target.value)} className="text-xs min-h-[60px] resize-none" />
                <Button size="sm" className="mt-2 text-xs" onClick={handleSaveNote}>Save Note</Button>
              </div>
              <div className="space-y-3">
                {consultations.map((note) => (
                  <div key={note.id} className="border rounded-xl p-4">
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="text-sm font-semibold">{note.doctor}</p>
                      <p className="text-[11px] text-muted-foreground">{new Date(note.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</p>
                    </div>
                    <p className="text-sm text-muted-foreground">{note.notes || note.complaints || note.diagnosis || 'No details'}</p>
                  </div>
                ))}
                {consultations.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No clinical notes yet</p>}
              </div>
            </div>
          )}

          {activeTab === 'Medications' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold">Prescriptions</p>
              </div>
              {prescriptions.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">No medications ordered</p>
              ) : prescriptions.map((rx) => {
                const meds = Array.isArray(rx.medications) ? rx.medications : [];
                return (
                  <div key={rx.id} className="border rounded-lg p-3">
                    <p className="text-xs text-muted-foreground mb-2">{rx.rx_no} · {rx.doctor} · {rx.status}</p>
                    {meds.map((med: any, i: number) => (
                      <div key={i} className="flex items-center justify-between text-xs py-1">
                        <span className="font-medium">{med.drug}</span>
                        <span className="text-muted-foreground">{med.dosage} · {med.frequency} · {med.route}</span>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'Labs' && (
            <div className="space-y-2">
              {labOrders.length === 0 ? (
                <div className="flex flex-col items-center py-16"><Activity className="w-8 h-8 text-muted-foreground mb-3" /><p className="text-sm">No lab results yet</p></div>
              ) : (
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3 text-muted-foreground font-semibold">Order</th>
                      <th className="text-left py-2 px-3 text-muted-foreground font-semibold">Tests</th>
                      <th className="text-left py-2 px-3 text-muted-foreground font-semibold">Priority</th>
                      <th className="text-left py-2 px-3 text-muted-foreground font-semibold">Stage</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {labOrders.map((r) => (
                      <tr key={r.id} className="hover:bg-accent/30">
                        <td className="py-2 px-3 font-mono">{r.order_no}</td>
                        <td className="py-2 px-3">{r.tests}</td>
                        <td className="py-2 px-3">{r.priority}</td>
                        <td className="py-2 px-3">{r.stage}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {activeTab === 'Discharge' && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Discharge planning for {admission.patient_name}</p>
              <div className="border rounded-lg p-4 bg-accent/20 text-center">
                <p className="text-sm font-medium">Discharge functionality</p>
                <p className="text-xs text-muted-foreground mt-1">Update admission status to discharge the patient</p>
                <Button size="sm" className="mt-3" onClick={async () => {
                  if (!user?.orgId) return;
                  await supabase.from('admissions').update({ status: 'discharged', discharge_date: new Date().toISOString() }).eq('id', admission.id).eq('org_id', user.orgId);
                  if (admission.bed_id) {
                    await supabase.from('beds').update({ is_occupied: false, patient_id: null }).eq('id', admission.bed_id).eq('org_id', user.orgId);
                  }
                  toast.success('Patient discharged');
                  navigate('/doctor/ipd');
                }}>Discharge Patient</Button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
