import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, ArrowRight, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_COLORS: Record<string, string> = {
  triaged: 'bg-amber-500/10 text-amber-600 border-border',
  'under_treatment': 'bg-foreground/10 text-foreground border-border',
  'under_observation': 'bg-accent text-accent-foreground border-border',
  admitted: 'bg-blue-500/10 text-blue-600 border-border',
  discharged: 'bg-muted text-muted-foreground border-border',
};

const TRIAGE_COLORS: Record<string, string> = {
  red: 'bg-destructive/10 text-destructive',
  yellow: 'bg-amber-500/10 text-amber-600',
  green: 'bg-emerald-500/10 text-emerald-600',
  blue: 'bg-blue-500/10 text-blue-600',
};

export default function EmergencyCases() {
  const { user } = useAuth();
  const [cases, setCases] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState('active');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.orgId) return;
    const load = async () => {
      setLoading(true);
      const { data } = await supabase.from('emergency_cases').select('*').eq('org_id', user.orgId).order('arrival_time', { ascending: false });
      setCases(data || []);
      setLoading(false);
    };
    load();

    const channel = supabase.channel('er-cases')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'emergency_cases' }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.orgId]);

  const activeCases = cases.filter(c => !['discharged'].includes(c.status));
  const closedCases = cases.filter(c => c.status === 'discharged');

  const currentList = tab === 'active' ? activeCases : closedCases;
  const filtered = currentList.filter(c => {
    if (search && !c.patient_name.toLowerCase().includes(search.toLowerCase()) && !c.case_no.includes(search)) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Emergency Cases</h1>
        <p className="text-sm text-muted-foreground mt-1">Track all ER patient cases and their status</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card className="border-border p-4">
          <p className="text-sm text-muted-foreground">Active Cases</p>
          <p className="text-2xl font-bold text-foreground">{activeCases.length}</p>
        </Card>
        <Card className="border-border p-4">
          <p className="text-sm text-muted-foreground">Critical</p>
          <p className="text-2xl font-bold text-destructive">{cases.filter(c => c.triage_level === 'red').length}</p>
        </Card>
        <Card className="border-border p-4">
          <p className="text-sm text-muted-foreground">MLC Cases</p>
          <p className="text-2xl font-bold text-amber-600">{cases.filter(c => c.is_mlc).length}</p>
        </Card>
        <Card className="border-border p-4">
          <p className="text-sm text-muted-foreground">Discharged</p>
          <p className="text-2xl font-bold text-muted-foreground">{closedCases.length}</p>
        </Card>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="active">Active ({activeCases.length})</TabsTrigger>
          <TabsTrigger value="closed">Closed ({closedCases.length})</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search patient or case no..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>

          <div className="space-y-3">
            {filtered.length === 0 ? (
              <div className="text-center py-12 text-sm text-muted-foreground">
                {loading ? 'Loading...' : 'No emergency cases found'}
              </div>
            ) : filtered.map(c => (
              <Card key={c.id} className={`border-l-4 p-4 ${c.triage_level === 'red' ? 'border-l-destructive' : c.triage_level === 'yellow' ? 'border-l-amber-500' : 'border-l-emerald-500'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-mono text-muted-foreground">{c.case_no}</span>
                      <Badge variant="outline" className={`text-xs ${TRIAGE_COLORS[c.triage_level] || ''}`}>{c.triage_level?.toUpperCase()}</Badge>
                      <span className={`text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded-full ${STATUS_COLORS[c.status] || 'bg-muted text-muted-foreground'}`}>{c.status.replace('_', ' ')}</span>
                      {c.is_mlc && <Badge variant="destructive" className="text-xs">MLC</Badge>}
                    </div>
                    <p className="text-sm font-semibold text-foreground">{c.patient_name}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {c.chief_complaint} · {c.arrival_mode} · {new Date(c.arrival_time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })}
                      {c.attending_doctor && ` · ${c.attending_doctor}`}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
