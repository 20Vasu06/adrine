import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Siren, Users, Clock, HeartPulse, AlertTriangle, Bed, ArrowRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function EmergencyDashboard() {
  const { user } = useAuth();
  const [cases, setCases] = useState<any[]>([]);

  useEffect(() => {
    if (!user?.orgId) return;
    supabase.from('emergency_cases').select('*').eq('org_id', user.orgId)
      .order('arrival_time', { ascending: false })
      .then(({ data }) => { if (data) setCases(data); });

    const channel = supabase
      .channel('er-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'emergency_cases' }, () => {
        supabase.from('emergency_cases').select('*').eq('org_id', user.orgId)
          .order('arrival_time', { ascending: false })
          .then(({ data }) => { if (data) setCases(data); });
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user?.orgId]);

  const active = cases.filter(c => c.status !== 'discharged' && c.status !== 'transferred');
  const critical = active.filter(c => c.triage_level === 'red' || c.triage_level === 'Critical');

  const stats = [
    { label: 'Active Cases', value: String(active.length), icon: Siren, accent: true },
    { label: 'Critical', value: String(critical.length), icon: AlertTriangle },
    { label: 'Total Today', value: String(cases.length), icon: Users },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Emergency Department</h1>
          <p className="text-sm text-muted-foreground mt-1">Real-time ER monitoring & case management</p>
        </div>
        <Button className="bg-destructive text-destructive-foreground hover:bg-destructive/90 gap-2">
          <Siren className="w-4 h-4" /> New Emergency Case
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {stats.map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card className={`p-5 ${s.accent ? 'border-destructive/30 bg-destructive/5' : ''}`}>
              <div className="flex items-center justify-between mb-3">
                <s.icon className={`w-5 h-5 ${s.accent ? 'text-destructive' : 'text-muted-foreground'}`} />
              </div>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-destructive" /> Active Cases
        </h2>
        {active.length === 0 ? (
          <div className="py-12 text-center text-sm text-muted-foreground">No active emergency cases</div>
        ) : active.map(c => (
          <Card key={c.id} className="p-4 hover:shadow-sm transition-shadow">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-muted-foreground">{c.case_no}</span>
                  <Badge variant={c.triage_level === 'red' ? 'destructive' : 'outline'} className="text-[10px]">{c.triage_level}</Badge>
                </div>
                <p className="font-medium text-sm text-foreground">{c.patient_name}</p>
                <p className="text-xs text-muted-foreground">{c.chief_complaint} · {c.attending_doctor || 'Unassigned'}</p>
              </div>
              <Badge variant="secondary" className="text-[10px]">{c.status}</Badge>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
