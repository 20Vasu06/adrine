import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, User, Activity } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

type TriageCategory = 'red' | 'yellow' | 'green' | 'blue';

const TRIAGE_CONFIG: Record<TriageCategory, { label: string; color: string; badge: 'destructive' | 'outline' | 'secondary' | 'default' }> = {
  red: { label: 'Critical (Immediate)', color: 'border-l-destructive', badge: 'destructive' },
  yellow: { label: 'Urgent', color: 'border-l-amber-500', badge: 'outline' },
  green: { label: 'Semi-Urgent', color: 'border-l-emerald-500', badge: 'secondary' },
  blue: { label: 'Non-Urgent', color: 'border-l-blue-500', badge: 'default' },
};

export default function EmergencyTriage() {
  const { user } = useAuth();
  const [cases, setCases] = useState<any[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.orgId) return;
    const load = async () => {
      setLoading(true);
      const { data } = await supabase.from('emergency_cases').select('*').eq('org_id', user.orgId).neq('status', 'discharged').order('arrival_time', { ascending: false });
      setCases(data || []);
      setLoading(false);
    };
    load();

    const channel = supabase.channel('er-triage')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'emergency_cases' }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.orgId]);

  const filtered = cases.filter(p => {
    if (filter !== 'all' && p.triage_level !== filter) return false;
    if (search && !p.patient_name.toLowerCase().includes(search.toLowerCase()) && !p.case_no.includes(search)) return false;
    return true;
  });

  const updateTriage = async (caseId: string, level: TriageCategory) => {
    await supabase.from('emergency_cases').update({ triage_level: level }).eq('id', caseId);
    toast.success(`Triage updated to ${level}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Triage</h1>
          <p className="text-sm text-muted-foreground mt-1">Assess and prioritize emergency patients</p>
        </div>
      </div>

      {/* Triage Category Cards */}
      <div className="grid grid-cols-4 gap-3">
        {(Object.entries(TRIAGE_CONFIG) as [TriageCategory, typeof TRIAGE_CONFIG[TriageCategory]][]).map(([key, cfg]) => {
          const count = cases.filter(p => p.triage_level === key).length;
          return (
            <Card key={key} className={`border-l-4 ${cfg.color} p-4 cursor-pointer hover:bg-accent/30 transition-colors`} onClick={() => setFilter(filter === key ? 'all' : key)}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{cfg.label}</p>
                  <p className="text-2xl font-bold">{count}</p>
                </div>
                <Activity className="w-5 h-5 text-muted-foreground" />
              </div>
            </Card>
          );
        })}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search patient or case no..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-sm text-muted-foreground">
            {loading ? 'Loading...' : 'No cases in triage'}
          </div>
        ) : filtered.map(p => {
          const triageLevel = p.triage_level as TriageCategory;
          const cfg = TRIAGE_CONFIG[triageLevel] || TRIAGE_CONFIG.green;
          return (
            <Card key={p.id} className={`border-l-4 ${cfg.color} p-4`}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono text-muted-foreground">{p.case_no}</span>
                    <Badge variant={cfg.badge} className="text-xs">{triageLevel?.toUpperCase()}</Badge>
                    <span className="text-xs text-muted-foreground">{p.arrival_mode}</span>
                  </div>
                  <p className="text-sm font-semibold text-foreground">{p.patient_name}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{p.chief_complaint}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Arrived: {new Date(p.arrival_time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })}
                    {p.attending_doctor && ` · Dr: ${p.attending_doctor}`}
                  </p>
                </div>
                <div className="flex gap-1">
                  {(Object.keys(TRIAGE_CONFIG) as TriageCategory[]).map(level => (
                    <Button key={level} size="sm" variant={triageLevel === level ? 'default' : 'outline'} className="text-[10px] h-6 px-2"
                      onClick={() => updateTriage(p.id, level)}>
                      {level.toUpperCase()}
                    </Button>
                  ))}
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
