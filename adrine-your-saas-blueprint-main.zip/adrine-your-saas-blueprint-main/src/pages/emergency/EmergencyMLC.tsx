import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Shield, FileText, AlertTriangle, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function EmergencyMLC() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [cases, setCases] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from('emergency_cases')
        .select('*')
        .eq('org_id', orgId)
        .eq('is_mlc', true)
        .order('arrival_time', { ascending: false });
      setCases(data || []);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  const filtered = cases.filter(c =>
    !search || c.patient_name?.toLowerCase().includes(search.toLowerCase()) || c.case_no?.includes(search)
  );

  const mlcDetails = (c: any) => (c.mlc_details || {}) as Record<string, any>;
  const activeCases = cases.filter(c => c.status === 'triaged' || c.status === 'treating');
  const closedCases = cases.filter(c => c.status === 'discharged' || c.status === 'transferred');

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading MLC cases...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Medico-Legal Cases</h1>
          <p className="text-sm text-muted-foreground mt-1">Track MLC registrations, police notifications, and legal documentation</p>
        </div>
        <Button className="gap-2"><Shield className="w-4 h-4" />Register MLC</Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4 border-l-4 border-l-destructive">
          <p className="text-2xl font-bold text-foreground">{activeCases.length}</p>
          <p className="text-xs text-muted-foreground">Active MLCs</p>
        </Card>
        <Card className="p-4">
          <p className="text-2xl font-bold text-foreground">{cases.filter(c => !mlcDetails(c).police_report).length}</p>
          <p className="text-xs text-muted-foreground">Pending Police Report</p>
        </Card>
        <Card className="p-4">
          <p className="text-2xl font-bold text-foreground">{closedCases.length}</p>
          <p className="text-xs text-muted-foreground">Closed</p>
        </Card>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search MLC cases..." className="pl-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="space-y-3">
        {filtered.map((c) => {
          const mlc = mlcDetails(c);
          return (
            <Card key={c.id} className="p-4 border-l-4 border-l-warning hover:shadow-sm transition-shadow">
              <div className="flex items-start justify-between">
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-muted-foreground">{c.case_no}</span>
                    <Badge variant={c.status === 'triaged' || c.status === 'treating' ? 'destructive' : 'secondary'} className="text-[10px]">{c.status}</Badge>
                    <Badge variant="outline" className="text-[10px]">{mlc.incident || c.chief_complaint}</Badge>
                  </div>
                  <p className="font-medium text-sm text-foreground">{c.patient_name}</p>
                  <p className="text-xs text-muted-foreground">{c.treatment_notes || 'No details recorded.'}</p>
                  <div className="flex items-center gap-4 text-[11px] text-muted-foreground mt-2">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(c.arrival_time).toLocaleString()}</span>
                    {mlc.police_report ? (
                      <span className="flex items-center gap-1"><FileText className="w-3 h-3" />{mlc.police_report} {mlc.station ? `· ${mlc.station}` : ''}</span>
                    ) : (
                      <span className="text-warning flex items-center gap-1"><AlertTriangle className="w-3 h-3" />FIR Pending</span>
                    )}
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="text-xs">View Details</Button>
              </div>
            </Card>
          );
        })}
        {filtered.length === 0 && <p className="text-center text-muted-foreground py-8">No MLC cases found.</p>}
      </div>
    </div>
  );
}
