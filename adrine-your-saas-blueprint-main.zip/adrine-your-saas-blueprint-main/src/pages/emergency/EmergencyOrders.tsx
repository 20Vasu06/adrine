import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FlaskConical, ScanLine, Pill, Clock, CheckCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const TYPE_ICONS: Record<string, React.ElementType> = { Lab: FlaskConical, Radiology: ScanLine, Pharmacy: Pill };
const STATUS_STYLE: Record<string, string> = {
  Pending: 'bg-warning/10 text-warning',
  'Pending Analysis': 'bg-warning/10 text-warning',
  Ordered: 'bg-warning/10 text-warning',
  'In Progress': 'bg-info/10 text-info',
  'In Analysis': 'bg-info/10 text-info',
  Completed: 'bg-success/10 text-success',
  Reported: 'bg-success/10 text-success',
  Validated: 'bg-success/10 text-success',
  Dispensed: 'bg-success/10 text-success',
};

interface UnifiedOrder {
  id: string;
  type: 'Lab' | 'Radiology' | 'Pharmacy';
  item: string;
  patient_name: string;
  priority: string;
  status: string;
  time: string;
  order_no: string;
}

export default function EmergencyOrders() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [orders, setOrders] = useState<UnifiedOrder[]>([]);
  const [tab, setTab] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const today = new Date().toISOString().split('T')[0];
      const [labRes, radRes, rxRes] = await Promise.all([
        supabase.from('lab_orders').select('*').eq('org_id', orgId).gte('order_time', today).order('order_time', { ascending: false }),
        supabase.from('radiology_orders').select('*').eq('org_id', orgId).gte('order_time', today).order('order_time', { ascending: false }),
        supabase.from('prescriptions').select('*').eq('org_id', orgId).gte('date', today).order('created_at', { ascending: false }),
      ]);

      const unified: UnifiedOrder[] = [
        ...(labRes.data || []).map((o: any) => ({
          id: o.id, type: 'Lab' as const, item: o.tests, patient_name: o.patient_name,
          priority: o.priority, status: o.stage, time: new Date(o.order_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          order_no: o.order_no,
        })),
        ...(radRes.data || []).map((o: any) => ({
          id: o.id, type: 'Radiology' as const, item: `${o.modality}: ${o.study}`, patient_name: o.patient_name,
          priority: o.priority, status: o.status, time: new Date(o.order_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          order_no: o.order_no,
        })),
        ...(rxRes.data || []).map((o: any) => ({
          id: o.id, type: 'Pharmacy' as const, item: 'Prescription', patient_name: o.patient_name,
          priority: o.priority, status: o.status, time: new Date(o.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          order_no: o.rx_no,
        })),
      ];
      setOrders(unified);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  const filtered = tab === 'all' ? orders : orders.filter(o => o.type === tab);
  const statPending = orders.filter(o => (o.priority === 'Emergency' || o.priority === 'Urgent') && (o.status === 'Pending' || o.status === 'Ordered' || o.status === 'Pending Analysis')).length;
  const completed = orders.filter(o => ['Completed', 'Dispensed', 'Reported', 'Validated'].includes(o.status)).length;
  const inProgress = orders.filter(o => ['In Progress', 'In Analysis'].includes(o.status)).length;

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading orders...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Emergency Orders</h1>
          <p className="text-sm text-muted-foreground mt-1">Lab, radiology, and pharmacy orders</p>
        </div>
        <Button className="gap-2">New Order</Button>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Total Orders', value: orders.length, icon: AlertTriangle },
          { label: 'STAT Pending', value: statPending, icon: Clock },
          { label: 'Completed', value: completed, icon: CheckCircle },
          { label: 'In Progress', value: inProgress, icon: FlaskConical },
        ].map(s => (
          <Card key={s.label} className="p-4">
            <s.icon className="w-4 h-4 text-muted-foreground mb-2" />
            <p className="text-xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </Card>
        ))}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="all">All ({orders.length})</TabsTrigger>
          <TabsTrigger value="Lab">Lab ({orders.filter(o => o.type === 'Lab').length})</TabsTrigger>
          <TabsTrigger value="Radiology">Radiology ({orders.filter(o => o.type === 'Radiology').length})</TabsTrigger>
          <TabsTrigger value="Pharmacy">Pharmacy ({orders.filter(o => o.type === 'Pharmacy').length})</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4 space-y-3">
          {filtered.map(o => {
            const Icon = TYPE_ICONS[o.type] || FlaskConical;
            return (
              <Card key={o.id} className="p-4 hover:shadow-sm transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded bg-muted flex items-center justify-center mt-0.5">
                      <Icon className="w-4 h-4 text-foreground" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-muted-foreground">{o.order_no}</span>
                        <Badge variant={o.priority === 'Emergency' || o.priority === 'Urgent' ? 'destructive' : 'outline'} className="text-[10px]">{o.priority}</Badge>
                        <Badge className={`text-[10px] ${STATUS_STYLE[o.status] || ''}`}>{o.status}</Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground">{o.item}</p>
                      <p className="text-xs text-muted-foreground">{o.patient_name}</p>
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" />{o.time}</span>
                </div>
              </Card>
            );
          })}
          {filtered.length === 0 && <p className="text-center text-muted-foreground py-8">No orders found.</p>}
        </TabsContent>
      </Tabs>
    </div>
  );
}
