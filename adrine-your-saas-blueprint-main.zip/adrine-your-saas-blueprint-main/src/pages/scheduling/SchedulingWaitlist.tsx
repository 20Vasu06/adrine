import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Clock, Bell, UserPlus, ArrowRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';

const PRIORITY_STYLE: Record<string, string> = {
  Emergency: 'bg-destructive/10 text-destructive',
  Urgent: 'bg-destructive/10 text-destructive',
  Routine: 'bg-muted text-muted-foreground',
};

export default function SchedulingWaitlist() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [appointments, setAppointments] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      // Waitlisted = scheduled appointments with notes containing 'waitlist'
      // Or we show all scheduled future appointments as a queue
      const today = format(new Date(), 'yyyy-MM-dd');
      const { data } = await supabase
        .from('appointments')
        .select('*')
        .eq('org_id', orgId)
        .eq('status', 'scheduled')
        .gte('date', today)
        .order('date')
        .order('time');
      setAppointments(data || []);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  const filtered = appointments.filter(a =>
    !search || a.patient_name?.toLowerCase().includes(search.toLowerCase()) || a.appointment_no?.includes(search)
  );

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading waitlist...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Waitlist</h1>
          <p className="text-sm text-muted-foreground mt-1">Upcoming scheduled appointments</p>
        </div>
        <Button className="gap-2"><UserPlus className="w-4 h-4" />Add to Waitlist</Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4"><p className="text-xl font-bold text-foreground">{appointments.length}</p><p className="text-xs text-muted-foreground">Total Scheduled</p></Card>
        <Card className="p-4"><p className="text-xl font-bold text-foreground">{appointments.filter(a => a.date === format(new Date(), 'yyyy-MM-dd')).length}</p><p className="text-xs text-muted-foreground">Today</p></Card>
        <Card className="p-4"><p className="text-xl font-bold text-foreground">{appointments.filter(a => a.date > format(new Date(), 'yyyy-MM-dd')).length}</p><p className="text-xs text-muted-foreground">Future</p></Card>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search patient..." className="pl-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="space-y-3">
        {filtered.map(a => (
          <Card key={a.id} className="p-4 hover:shadow-sm transition-shadow">
            <div className="flex items-start justify-between">
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-muted-foreground">{a.appointment_no}</span>
                  <Badge variant="outline" className="text-[10px]">{a.type}</Badge>
                </div>
                <p className="text-sm font-medium text-foreground">{a.patient_name}</p>
                <p className="text-xs text-muted-foreground">{a.doctor} · {a.department}</p>
                <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{a.date} at {a.time}</span>
                </div>
              </div>
              <Button size="sm" variant="outline" className="text-xs">Check In</Button>
            </div>
          </Card>
        ))}
        {filtered.length === 0 && <p className="text-center text-muted-foreground py-8">No appointments in waitlist.</p>}
      </div>
    </div>
  );
}
