import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Monitor, Stethoscope, Bed, DoorOpen, Settings, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_STYLE: Record<string, string> = {
  available: 'bg-success/10 text-success',
  'in_use': 'bg-info/10 text-info',
  in_surgery: 'bg-info/10 text-info',
  maintenance: 'bg-destructive/10 text-destructive',
  operational: 'bg-success/10 text-success',
  'under_maintenance': 'bg-destructive/10 text-destructive',
};

const TYPE_ICONS: Record<string, React.ElementType> = {
  Imaging: Monitor,
  'Operation Theatre': DoorOpen,
  Consultation: Stethoscope,
  Equipment: Settings,
  Laboratory: Settings,
};

export default function SchedulingResources() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [resources, setResources] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const [equipRes, otRes] = await Promise.all([
        supabase.from('equipment').select('*').eq('org_id', orgId).order('name'),
        supabase.from('ot_rooms').select('*').eq('org_id', orgId).order('room_name'),
      ]);

      const combined = [
        ...(otRes.data || []).map((r: any) => ({
          id: r.id, name: r.room_name, type: 'Operation Theatre', dept: 'Surgery',
          status: r.status, nextAvailable: r.status === 'available' ? 'Now' : '—',
        })),
        ...(equipRes.data || []).map((e: any) => ({
          id: e.id, name: e.name, type: 'Equipment', dept: e.department || '—',
          status: e.status, nextAvailable: e.status === 'operational' ? 'Now' : '—',
        })),
      ];
      setResources(combined);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  const available = resources.filter(r => r.status === 'available' || r.status === 'operational').length;
  const inUse = resources.filter(r => r.status === 'in_use' || r.status === 'in_surgery').length;

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading resources...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Resource Scheduling</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage OT rooms, equipment, and resources</p>
        </div>
        <Button className="gap-2"><Settings className="w-4 h-4" />Manage Resources</Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4"><p className="text-xl font-bold text-foreground">{available}</p><p className="text-xs text-muted-foreground">Available Now</p></Card>
        <Card className="p-4"><p className="text-xl font-bold text-foreground">{inUse}</p><p className="text-xs text-muted-foreground">In Use</p></Card>
        <Card className="p-4"><p className="text-xl font-bold text-foreground">{resources.length}</p><p className="text-xs text-muted-foreground">Total Resources</p></Card>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All ({resources.length})</TabsTrigger>
          <TabsTrigger value="Operation Theatre">OT</TabsTrigger>
          <TabsTrigger value="Equipment">Equipment</TabsTrigger>
        </TabsList>

        {['all', 'Operation Theatre', 'Equipment'].map(tab => (
          <TabsContent key={tab} value={tab} className="mt-4">
            <div className="grid md:grid-cols-2 gap-4">
              {resources
                .filter(r => tab === 'all' || r.type === tab)
                .map(r => {
                  const Icon = TYPE_ICONS[r.type] || Settings;
                  return (
                    <Card key={r.id} className="p-4 hover:shadow-sm transition-shadow">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-start gap-3">
                          <div className="w-9 h-9 rounded bg-muted flex items-center justify-center">
                            <Icon className="w-4 h-4 text-foreground" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-foreground">{r.name}</p>
                            <p className="text-xs text-muted-foreground">{r.type} · {r.dept}</p>
                          </div>
                        </div>
                        <Badge className={`text-[10px] ${STATUS_STYLE[r.status] || 'bg-muted text-muted-foreground'}`}>{r.status}</Badge>
                      </div>
                      <div className="text-xs">
                        <span className="text-muted-foreground">Next Available: </span>
                        <span className="font-medium text-foreground">{r.nextAvailable}</span>
                      </div>
                    </Card>
                  );
                })}
            </div>
            {resources.filter(r => tab === 'all' || r.type === tab).length === 0 && (
              <p className="text-center text-muted-foreground py-8">No resources found.</p>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
