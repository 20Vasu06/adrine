import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Monitor, Video, Clock, Link, Plus, CheckCircle, Phone } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';

const STATUS_STYLE: Record<string, string> = {
  scheduled: 'bg-info/10 text-info',
  checked_in: 'bg-success/10 text-success',
  completed: 'bg-muted text-muted-foreground',
  cancelled: 'bg-destructive/10 text-destructive',
  no_show: 'bg-destructive/10 text-destructive',
};

export default function SchedulingTeleconsult() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from('appointments')
        .select('*')
        .eq('org_id', orgId)
        .eq('type', 'teleconsultation')
        .order('date', { ascending: false })
        .order('time')
        .limit(50);
      setAppointments(data || []);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  const today = format(new Date(), 'yyyy-MM-dd');
  const todayAppts = appointments.filter(a => a.date === today);
  const completedToday = todayAppts.filter(a => a.status === 'completed').length;

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading teleconsultations...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Teleconsultation</h1>
          <p className="text-sm text-muted-foreground mt-1">Schedule and manage remote consultation sessions</p>
        </div>
        <Button className="gap-2"><Plus className="w-4 h-4" />Schedule Teleconsult</Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4"><Monitor className="w-4 h-4 text-muted-foreground mb-2" /><p className="text-xl font-bold text-foreground">{todayAppts.length}</p><p className="text-xs text-muted-foreground">Today's Sessions</p></Card>
        <Card className="p-4 border-success/30"><Video className="w-4 h-4 text-success mb-2" /><p className="text-xl font-bold text-foreground">{todayAppts.filter(a => a.status === 'checked_in').length}</p><p className="text-xs text-muted-foreground">In Progress</p></Card>
        <Card className="p-4"><CheckCircle className="w-4 h-4 text-muted-foreground mb-2" /><p className="text-xl font-bold text-foreground">{completedToday}</p><p className="text-xs text-muted-foreground">Completed Today</p></Card>
      </div>

      <Tabs defaultValue="today">
        <TabsList>
          <TabsTrigger value="today">Today ({todayAppts.length})</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        {['today', 'upcoming', 'completed'].map(tab => (
          <TabsContent key={tab} value={tab} className="mt-4 space-y-3">
            {appointments
              .filter(a => {
                if (tab === 'today') return a.date === today && a.status !== 'completed';
                if (tab === 'upcoming') return a.date > today && a.status === 'scheduled';
                return a.status === 'completed';
              })
              .map(a => (
                <Card key={a.id} className={`p-4 hover:shadow-sm transition-shadow ${a.status === 'checked_in' ? 'border-success/30' : ''}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded bg-muted flex items-center justify-center">
                        {a.status === 'checked_in' ? <Video className="w-5 h-5 text-success animate-pulse" /> : <Monitor className="w-5 h-5 text-foreground" />}
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs text-muted-foreground">{a.appointment_no}</span>
                          <Badge className={`text-[10px] ${STATUS_STYLE[a.status] || ''}`}>{a.status}</Badge>
                        </div>
                        <p className="text-sm font-medium text-foreground">{a.patient_name}</p>
                        <p className="text-xs text-muted-foreground">{a.doctor} · {a.department}</p>
                        <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{a.date} at {a.time}</span>
                          <span>Duration: {a.duration || 15} min</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {a.status === 'checked_in' && <Button size="sm" className="text-xs gap-1 bg-success hover:bg-success/90 text-success-foreground"><Video className="w-3 h-3" />Join</Button>}
                    </div>
                  </div>
                </Card>
              ))}
            {appointments.filter(a => {
              if (tab === 'today') return a.date === today && a.status !== 'completed';
              if (tab === 'upcoming') return a.date > today;
              return a.status === 'completed';
            }).length === 0 && <p className="text-center text-muted-foreground py-8">No sessions found.</p>}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
