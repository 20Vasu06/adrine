import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Clock, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function SchedulingDoctors() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');
  const [schedules, setSchedules] = useState<any[]>([]);
  const [todayAppointments, setTodayAppointments] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('doctor_schedules').select('*').eq('org_id', orgId).eq('is_active', true),
      supabase.from('appointments').select('doctor').eq('org_id', orgId).eq('date', today),
    ]).then(([sRes, aRes]) => {
      setSchedules(sRes.data || []);
      setTodayAppointments(aRes.data || []);
    });
  }, [orgId]);

  // Group schedules by doctor
  const doctorMap = new Map<string, any[]>();
  schedules.forEach(s => {
    const existing = doctorMap.get(s.doctor_name) || [];
    existing.push(s);
    doctorMap.set(s.doctor_name, existing);
  });

  const doctors = Array.from(doctorMap.entries()).map(([name, scheds]) => {
    const days = [...new Set(scheds.map(s => DAY_NAMES[s.day_of_week]))];
    const first = scheds[0];
    const totalSlots = scheds.reduce((sum, s) => sum + (s.max_patients || 20), 0);
    const bookedToday = todayAppointments.filter(a => a.doctor === name).length;
    return {
      name,
      dept: first.department,
      days,
      hours: `${first.start_time?.substring(0, 5)} – ${first.end_time?.substring(0, 5)}`,
      slotDuration: first.slot_duration,
      totalSlots,
      bookedToday,
    };
  });

  const departments = [...new Set(doctors.map(d => d.dept))];
  const filtered = doctors.filter(d => {
    if (search && !d.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (deptFilter !== 'all' && d.dept !== deptFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Doctor Availability</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage doctor schedules, slots, and availability</p>
        </div>
        <Button className="gap-2"><Calendar className="w-4 h-4" />Configure Slots</Button>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search doctors..." className="pl-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={deptFilter} onValueChange={setDeptFilter}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="All Departments" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            {departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {filtered.length > 0 ? filtered.map((d, i) => (
          <motion.div key={d.name} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
            <Card className="p-4 hover:shadow-sm transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-sm font-medium text-foreground">{d.name}</p>
                  <p className="text-xs text-muted-foreground">{d.dept}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <p className="text-muted-foreground mb-1">Working Days</p>
                  <div className="flex flex-wrap gap-1">
                    {d.days.map(day => <Badge key={day} variant="secondary" className="text-[10px]">{day}</Badge>)}
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Hours</p>
                  <p className="text-foreground font-medium flex items-center gap-1"><Clock className="w-3 h-3" />{d.hours}</p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Slot Duration</p>
                  <p className="text-foreground font-medium">{d.slotDuration} min</p>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-border">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-muted-foreground">Today's slots</span>
                  <span className="font-medium text-foreground">{d.bookedToday}/{d.totalSlots}</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-foreground rounded-full" style={{ width: `${Math.min(100, (d.bookedToday / (d.totalSlots || 1)) * 100)}%` }} />
                </div>
              </div>
            </Card>
          </motion.div>
        )) : (
          <p className="text-sm text-muted-foreground col-span-2 text-center py-8">No doctor schedules configured</p>
        )}
      </div>
    </div>
  );
}
