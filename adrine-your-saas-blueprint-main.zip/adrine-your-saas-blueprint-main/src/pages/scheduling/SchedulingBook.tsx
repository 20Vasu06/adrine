import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { CalendarIcon, Search, Clock, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const appointmentTypes = ['OPD Consultation', 'Follow-up', 'Teleconsultation', 'Specialist Referral', 'Diagnostic', 'Surgery Pre-Assessment'];

export default function SchedulingBook() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [date, setDate] = useState<Date>();
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [patientSearch, setPatientSearch] = useState('');
  const [notes, setNotes] = useState('');
  const [schedules, setSchedules] = useState<any[]>([]);
  const [departments, setDepartments] = useState<string[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<any>(null);
  const [booked, setBooked] = useState(false);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from('doctor_schedules')
        .select('*')
        .eq('org_id', orgId)
        .eq('is_active', true);
      setSchedules(data || []);
      const depts = [...new Set((data || []).map((s: any) => s.department))];
      setDepartments(depts);
    };
    fetch();
  }, [orgId]);

  useEffect(() => {
    if (!orgId || patientSearch.length < 2) return;
    const search = async () => {
      const { data } = await supabase
        .from('patients')
        .select('id, name, uhid, phone, age, gender')
        .eq('org_id', orgId)
        .or(`name.ilike.%${patientSearch}%,uhid.ilike.%${patientSearch}%,phone.ilike.%${patientSearch}%`)
        .limit(5);
      setPatients(data || []);
    };
    search();
  }, [orgId, patientSearch]);

  const filteredDoctors = schedules
    .filter(s => !selectedDept || s.department === selectedDept)
    .reduce((acc: any[], s) => {
      if (!acc.find(d => d.name === s.doctor_name)) acc.push({ name: s.doctor_name, dept: s.department });
      return acc;
    }, []);

  const dayOfWeek = date ? date.getDay() : -1;
  const doctorSlots = schedules
    .filter(s => s.doctor_name === selectedDoctor && s.day_of_week === dayOfWeek)
    .flatMap(s => {
      const slots: string[] = [];
      const [sh, sm] = s.start_time.split(':').map(Number);
      const [eh] = s.end_time.split(':').map(Number);
      let h = sh, m = sm;
      while (h < eh || (h === eh && m === 0)) {
        const ampm = h >= 12 ? 'PM' : 'AM';
        const h12 = h > 12 ? h - 12 : h === 0 ? 12 : h;
        slots.push(`${h12}:${m.toString().padStart(2, '0')} ${ampm}`);
        m += s.slot_duration;
        if (m >= 60) { h++; m -= 60; }
      }
      return slots;
    });

  const handleBook = async () => {
    if (!orgId || !selectedPatient || !date || !selectedDoctor || !selectedSlot) return;
    const apptNo = `APT-${Date.now().toString().slice(-6)}`;
    // Convert 12h slot to 24h time
    const slotMatch = selectedSlot.match(/(\d+):(\d+)\s*(AM|PM)/i);
    let timeStr = '09:00';
    if (slotMatch) {
      let h = parseInt(slotMatch[1]);
      const m = slotMatch[2];
      const ampm = slotMatch[3].toUpperCase();
      if (ampm === 'PM' && h !== 12) h += 12;
      if (ampm === 'AM' && h === 12) h = 0;
      timeStr = `${h.toString().padStart(2, '0')}:${m}`;
    }
    const apptType = selectedType === 'Follow-up' ? 'follow-up' as const : selectedType === 'Teleconsultation' ? 'teleconsultation' as const : 'new' as const;
    const { error } = await supabase.from('appointments').insert([{
      org_id: orgId, appointment_no: apptNo, patient_id: selectedPatient.id,
      patient_name: selectedPatient.name, phone: selectedPatient.phone,
      doctor: selectedDoctor, department: selectedDept,
      date: format(date, 'yyyy-MM-dd'), time: timeStr,
      type: apptType,
      notes: notes || null,
    }]);
    if (error) { toast.error('Failed to book appointment'); return; }
    toast.success('Appointment booked successfully');
    setBooked(true);
  };

  if (booked) return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] text-center">
      <CheckCircle className="w-16 h-16 text-success mb-4" />
      <h2 className="text-2xl font-bold mb-2">Appointment Booked!</h2>
      <p className="text-muted-foreground mb-4">{selectedPatient?.name} with {selectedDoctor} on {date && format(date, 'PPP')} at {selectedSlot}</p>
      <Button onClick={() => { setBooked(false); setSelectedPatient(null); setSelectedSlot(''); }}>Book Another</Button>
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Book Appointment</h1>
        <p className="text-sm text-muted-foreground mt-1">Schedule a new appointment</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6 space-y-4">
          <div>
            <Label>Search Patient</Label>
            <Input placeholder="Name, UHID, or phone..." value={patientSearch} onChange={e => setPatientSearch(e.target.value)} />
            {patients.length > 0 && !selectedPatient && (
              <div className="mt-1 border rounded-md divide-y">
                {patients.map(p => (
                  <div key={p.id} className="p-2 hover:bg-accent cursor-pointer text-sm" onClick={() => { setSelectedPatient(p); setPatientSearch(p.name); }}>
                    <span className="font-medium">{p.name}</span> <span className="text-muted-foreground">({p.uhid}) • {p.age}{p.gender?.[0]} • {p.phone}</span>
                  </div>
                ))}
              </div>
            )}
            {selectedPatient && <Badge className="mt-1">{selectedPatient.name} ({selectedPatient.uhid})</Badge>}
          </div>

          <div>
            <Label>Department</Label>
            <Select value={selectedDept} onValueChange={v => { setSelectedDept(v); setSelectedDoctor(''); }}>
              <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
              <SelectContent>{departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div>
            <Label>Doctor</Label>
            <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
              <SelectTrigger><SelectValue placeholder="Select doctor" /></SelectTrigger>
              <SelectContent>{filteredDoctors.map(d => <SelectItem key={d.name} value={d.name}>{d.name} — {d.dept}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div>
            <Label>Appointment Type</Label>
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
              <SelectContent>{appointmentTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div><Label>Notes</Label><Textarea placeholder="Optional notes..." value={notes} onChange={e => setNotes(e.target.value)} /></div>
        </Card>

        <Card className="p-6 space-y-4">
          <div>
            <Label>Select Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn('w-full justify-start text-left font-normal', !date && 'text-muted-foreground')}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, 'PPP') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={date} onSelect={setDate} initialFocus disabled={d => d < new Date(new Date().setHours(0, 0, 0, 0))} /></PopoverContent>
            </Popover>
          </div>

          {selectedDoctor && date && (
            <div>
              <Label>Available Slots</Label>
              {doctorSlots.length > 0 ? (
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {doctorSlots.map(slot => (
                    <Button key={slot} variant={selectedSlot === slot ? 'default' : 'outline'} size="sm"
                      className="gap-1" onClick={() => setSelectedSlot(slot)}>
                      <Clock className="w-3 h-3" />{slot}
                    </Button>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground mt-2">No slots available for this day.</p>
              )}
            </div>
          )}

          <Button className="w-full" disabled={!selectedPatient || !date || !selectedDoctor || !selectedSlot} onClick={handleBook}>
            Confirm Booking
          </Button>
        </Card>
      </div>
    </div>
  );
}
