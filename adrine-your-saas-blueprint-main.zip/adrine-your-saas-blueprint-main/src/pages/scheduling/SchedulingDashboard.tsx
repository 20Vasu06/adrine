import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CalendarCheck, Clock, Users, UserX, Monitor, Plus, ArrowRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_STYLE: Record<string, string> = {
  'checked-in': 'bg-success/10 text-success',
  confirmed: 'bg-info/10 text-info',
  scheduled: 'bg-muted text-muted-foreground',
  completed: 'bg-muted text-muted-foreground',
  cancelled: 'bg-destructive/10 text-destructive',
  'no-show': 'bg-warning/10 text-warning',
};

export default function SchedulingDashboard() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [appointments, setAppointments] = useState<any[]>([]);
  const [schedules, setSchedules] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('appointments').select('*').eq('org_id', orgId).eq('date', today).order('time'),
      supabase.from('doctor_schedules').select('*').eq('org_id', orgId).eq('is_active', true),
    ]).then(([aRes, sRes]) => {
      setAppointments(aRes.data || []);
      setSchedules(sRes.data || []);
    });
  }, [orgId]);

  const total = appointments.length;
  const remaining = appointments.filter(a => ['scheduled', 'confirmed'].includes(a.status)).length;
  const noShows = appointments.filter(a => a.status === 'no-show').length;

  const stats = [
    { label: "Today's Appointments", value: String(total), icon: CalendarCheck, change: `${remaining} remaining` },
    { label: 'Avg Wait Time', value: '—', icon: Clock, change: 'Live data' },
    { label: 'No-Shows Today', value: String(noShows), icon: UserX, change: total ? `${((noShows / total) * 100).toFixed(1)}% rate` : '0%', accent: noShows > 0 },
    { label: 'Teleconsults', value: String(appointments.filter(a => a.type === 'teleconsultation').length), icon: Monitor, change: '' },
  ];

  // Dept load from schedules
  const deptMap = new Map<string, { booked: number; capacity: number }>();
  schedules.forEach(s => {
    const existing = deptMap.get(s.department) || { booked: 0, capacity: 0 };
    existing.capacity += s.max_patients || 20;
    deptMap.set(s.department, existing);
  });
  appointments.forEach(a => {
    const existing = deptMap.get(a.department) || { booked: 0, capacity: 20 };
    existing.booked += 1;
    deptMap.set(a.department, existing);
  });
  const deptLoad = Array.from(deptMap.entries()).map(([dept, data]) => ({
    dept, booked: data.booked, capacity: data.capacity || 20, pct: Math.min(100, Math.round((data.booked / (data.capacity || 20)) * 100)),
  }));

  const upcoming = appointments.filter(a => ['scheduled', 'confirmed', 'checked-in'].includes(a.status)).slice(0, 6);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Appointment Scheduling</h1>
          <p className="text-sm text-muted-foreground mt-1">Global scheduling engine & resource coordination</p>
        </div>
        <Button className="gap-2"><Plus className="w-4 h-4" />Book Appointment</Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card className={`p-5 ${s.accent ? 'border-destructive/30 bg-destructive/5' : ''}`}>
              <div className="flex items-center justify-between mb-3">
                <s.icon className={`w-5 h-5 ${s.accent ? 'text-destructive' : 'text-muted-foreground'}`} />
                <span className="text-[11px] text-muted-foreground">{s.change}</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-3">
          <h2 className="text-sm font-semibold text-foreground">Upcoming Slots</h2>
          {upcoming.length > 0 ? upcoming.map((s, i) => (
            <motion.div key={s.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
              <Card className="p-3 hover:shadow-sm transition-shadow">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-14 text-center"><p className="text-xs font-bold text-foreground">{s.time?.substring(0, 5)}</p></div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{s.patient_name}</p>
                      <p className="text-xs text-muted-foreground">{s.doctor} · {s.department}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] capitalize">{s.type}</Badge>
                    <Badge className={`text-[10px] ${STATUS_STYLE[s.status] || ''}`}>{s.status}</Badge>
                  </div>
                </div>
              </Card>
            </motion.div>
          )) : (
            <p className="text-sm text-muted-foreground text-center py-4">No upcoming appointments</p>
          )}
        </div>

        <div>
          <h2 className="text-sm font-semibold text-foreground mb-3">Department Load</h2>
          <Card className="p-4 space-y-3">
            {deptLoad.length > 0 ? deptLoad.map(d => (
              <div key={d.dept}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-foreground font-medium">{d.dept}</span>
                  <span className="text-muted-foreground">{d.booked}/{d.capacity}</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${d.pct >= 90 ? 'bg-destructive' : d.pct >= 75 ? 'bg-warning' : 'bg-foreground'}`} style={{ width: `${d.pct}%` }} />
                </div>
              </div>
            )) : (
              <p className="text-xs text-muted-foreground text-center py-2">No department data</p>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
