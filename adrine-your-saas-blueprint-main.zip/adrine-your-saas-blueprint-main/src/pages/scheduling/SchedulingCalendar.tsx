import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { format, addDays, startOfWeek } from 'date-fns';

const timeSlots = [
  '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
  '12:00 PM', '12:30 PM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM', '4:00 PM',
];

type SlotStatus = 'booked' | 'available' | 'blocked' | 'break';
const STATUS_CLASSES: Record<SlotStatus, string> = {
  booked: 'bg-primary/15 text-primary border-primary/20 cursor-pointer hover:bg-primary/25',
  available: 'bg-success/10 text-success border-success/20 cursor-pointer hover:bg-success/20',
  blocked: 'bg-muted text-muted-foreground border-border/40',
  break: 'bg-muted/50 text-muted-foreground border-border/20 italic',
};

export default function SchedulingCalendar() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [doctors, setDoctors] = useState<string[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [deptFilter, setDeptFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      const [apptRes, schedRes] = await Promise.all([
        supabase.from('appointments').select('*').eq('org_id', orgId).eq('date', dateStr),
        supabase.from('doctor_schedules').select('doctor_name, department').eq('org_id', orgId).eq('is_active', true),
      ]);
      setAppointments(apptRes.data || []);
      const uniqueDocs = [...new Set((schedRes.data || []).map((s: any) => s.doctor_name))];
      setDoctors(uniqueDocs);
      setLoading(false);
    };
    fetch();
  }, [orgId, selectedDate]);

  const getSlotData = (doctor: string, slot: string) => {
    if (slot === '12:00 PM' || slot === '12:30 PM') return { status: 'break' as SlotStatus };
    const appt = appointments.find(a => a.doctor === doctor && a.time?.startsWith(slot.replace(' AM', '').replace(' PM', '')));
    if (appt) return { status: 'booked' as SlotStatus, patient: appt.patient_name };
    return { status: 'available' as SlotStatus };
  };

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading calendar...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Appointment Calendar</h1>
          <p className="text-sm text-muted-foreground mt-1">Visual schedule for {format(selectedDate, 'EEEE, d MMMM yyyy')}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => setSelectedDate(d => addDays(d, -1))}><ChevronLeft className="w-4 h-4" /></Button>
          <Button variant="outline" size="sm" onClick={() => setSelectedDate(new Date())}>Today</Button>
          <Button variant="outline" size="icon" onClick={() => setSelectedDate(d => addDays(d, 1))}><ChevronRight className="w-4 h-4" /></Button>
        </div>
      </div>

      {doctors.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">No doctor schedules configured.</p>
      ) : (
        <Card className="overflow-auto">
          <div className="min-w-[800px]">
            <div className="grid" style={{ gridTemplateColumns: `120px repeat(${doctors.length}, 1fr)` }}>
              <div className="p-2 border-b border-r border-border bg-muted text-xs font-medium text-muted-foreground">Time</div>
              {doctors.map(doc => (
                <div key={doc} className="p-2 border-b border-r border-border bg-muted text-xs font-medium text-center truncate">{doc}</div>
              ))}
              {timeSlots.map(slot => (
                <>
                  <div key={`t-${slot}`} className="p-2 border-b border-r border-border text-[11px] font-mono text-muted-foreground">{slot}</div>
                  {doctors.map(doc => {
                    const data = getSlotData(doc, slot);
                    return (
                      <div key={`${doc}-${slot}`} className={`p-1.5 border-b border-r border-border ${STATUS_CLASSES[data.status]}`}>
                        {data.status === 'booked' && <span className="text-[10px] font-medium truncate block">{(data as any).patient}</span>}
                        {data.status === 'break' && <span className="text-[10px]">Break</span>}
                      </div>
                    );
                  })}
                </>
              ))}
            </div>
          </div>
        </Card>
      )}

      <div className="flex gap-3 text-xs">
        {[
          { status: 'booked', label: 'Booked' },
          { status: 'available', label: 'Available' },
          { status: 'break', label: 'Break' },
        ].map(s => (
          <div key={s.status} className="flex items-center gap-1.5">
            <div className={`w-3 h-3 rounded ${STATUS_CLASSES[s.status as SlotStatus].split(' ')[0]}`} />
            <span className="text-muted-foreground">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
