import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bed, Search, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export default function NurseWard() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [admissions, setAdmissions] = useState<any[]>([]);
  const [beds, setBeds] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.orgId) return;
    const load = async () => {
      setLoading(true);
      const [aRes, bRes] = await Promise.all([
        supabase.from('admissions').select('*').eq('org_id', user.orgId).eq('status', 'admitted').order('admission_date', { ascending: false }),
        supabase.from('beds').select('*').eq('org_id', user.orgId).order('ward'),
      ]);
      setAdmissions(aRes.data || []);
      setBeds(bRes.data || []);
      setLoading(false);
    };
    load();

    const channel = supabase.channel('nurse-ward')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'admissions' }, () => load())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'beds' }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.orgId]);

  const wards = [...new Set(beds.map(b => b.ward))];
  const occupiedBeds = beds.filter(b => b.is_occupied);

  const filtered = admissions.filter(a =>
    a.patient_name.toLowerCase().includes(search.toLowerCase()) || a.admission_no.includes(search)
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">My Ward</h1>
          <p className="text-sm text-muted-foreground mt-1">Admitted patients and bed assignments</p>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Admitted Patients</p>
          <p className="text-2xl font-bold text-foreground">{admissions.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Total Beds</p>
          <p className="text-2xl font-bold text-foreground">{beds.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Occupied</p>
          <p className="text-2xl font-bold text-amber-600">{occupiedBeds.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Available</p>
          <p className="text-2xl font-bold text-emerald-600">{beds.length - occupiedBeds.length}</p>
        </CardContent></Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search patient or admission no..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <Card className="border-border">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Admission No</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Doctor</TableHead>
                <TableHead>Diagnosis</TableHead>
                <TableHead>Admitted</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-12 text-sm text-muted-foreground">
                  {loading ? 'Loading...' : 'No admitted patients. Patients are admitted from Reception IPD.'}
                </TableCell></TableRow>
              ) : filtered.map(a => (
                <TableRow key={a.id}>
                  <TableCell className="font-mono text-sm">{a.admission_no}</TableCell>
                  <TableCell className="font-medium">{a.patient_name}</TableCell>
                  <TableCell>{a.department}</TableCell>
                  <TableCell className="text-muted-foreground">{a.doctor}</TableCell>
                  <TableCell className="text-sm max-w-[200px] truncate">{a.diagnosis || '—'}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{new Date(a.admission_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</TableCell>
                  <TableCell><Badge variant="default" className="text-xs">{a.status}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
