import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Circle, Clock, ListTodo, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const priorityColor = (p: string) => {
  if (p === "urgent" || p === "high") return "destructive" as const;
  if (p === "normal") return "default" as const;
  return "outline" as const;
};

export default function NurseTasks() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.orgId) return;
    const load = async () => {
      setLoading(true);
      const { data } = await supabase.from('nursing_tasks').select('*').eq('org_id', user.orgId).order('due_at', { ascending: true });
      setTasks(data || []);
      setLoading(false);
    };
    load();

    const channel = supabase.channel('nursing-tasks')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'nursing_tasks' }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.orgId]);

  const pendingTasks = tasks.filter(t => t.status === 'pending' || t.status === 'in_progress');
  const completedTasks = tasks.filter(t => t.status === 'completed');

  const handleComplete = async (taskId: string) => {
    await supabase.from('nursing_tasks').update({ status: 'completed', completed_at: new Date().toISOString() }).eq('id', taskId);
    toast.success('Task completed');
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Nursing Tasks</h1>
        <p className="text-sm text-muted-foreground mt-1">Task list and medication administration</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Pending</p>
          <p className="text-2xl font-bold text-amber-600">{pendingTasks.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Completed</p>
          <p className="text-2xl font-bold text-emerald-600">{completedTasks.length}</p>
        </CardContent></Card>
        <Card className="border-border"><CardContent className="p-4">
          <p className="text-sm text-muted-foreground">Total</p>
          <p className="text-2xl font-bold text-foreground">{tasks.length}</p>
        </CardContent></Card>
      </div>

      <Tabs defaultValue="pending">
        <TabsList>
          <TabsTrigger value="pending"><Clock className="h-3.5 w-3.5 mr-1" /> Pending ({pendingTasks.length})</TabsTrigger>
          <TabsTrigger value="completed"><CheckCircle className="h-3.5 w-3.5 mr-1" /> Completed ({completedTasks.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-4 space-y-3">
          {pendingTasks.length === 0 ? (
            <div className="text-center py-12">
              <ListTodo className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No pending tasks</p>
            </div>
          ) : pendingTasks.map(task => (
            <Card key={task.id} className="border-border">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-semibold text-foreground">{task.description}</p>
                      <Badge variant={priorityColor(task.priority)} className="text-xs">{task.priority}</Badge>
                      <Badge variant="outline" className="text-xs">{task.task_type}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {task.patient_name} · {task.ward || ''} {task.bed_no || ''} · Due: {new Date(task.due_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })}
                    </p>
                    {task.assigned_to && <p className="text-xs text-muted-foreground mt-0.5">Assigned to: {task.assigned_to}</p>}
                  </div>
                  <Button size="sm" className="text-xs h-7" onClick={() => handleComplete(task.id)}>
                    <CheckCircle className="h-3.5 w-3.5 mr-1" /> Complete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="completed" className="mt-4 space-y-3">
          {completedTasks.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-12">No completed tasks yet</p>
          ) : completedTasks.map(task => (
            <Card key={task.id} className="border-border opacity-60">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <p className="text-sm font-medium text-foreground line-through">{task.description}</p>
                </div>
                <p className="text-xs text-muted-foreground">{task.patient_name} · Completed: {task.completed_at ? new Date(task.completed_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }) : ''}</p>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
