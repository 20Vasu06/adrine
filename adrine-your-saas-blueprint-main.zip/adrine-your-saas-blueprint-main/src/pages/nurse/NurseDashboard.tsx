import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Activity, AlertTriangle, Bed, CheckCircle, Clock, Pill, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export default function NurseDashboard() {
  const { user } = useAuth();
  const [admissions, setAdmissions] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);

  useEffect(() => {
    if (!user?.orgId) return;
    Promise.all([
      supabase.from('admissions').select('*').eq('org_id', user.orgId).eq('status', 'admitted').order('admission_date', { ascending: false }),
      supabase.from('nursing_tasks').select('*').eq('org_id', user.orgId).neq('status', 'completed').order('due_at', { ascending: true }),
    ]).then(([aRes, tRes]) => {
      if (aRes.data) setAdmissions(aRes.data);
      if (tRes.data) setTasks(tRes.data);
    });
  }, [user?.orgId]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Nursing Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">Ward overview & task management</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Admitted Patients", value: admissions.length, icon: Users },
          { label: "Pending Tasks", value: tasks.length, icon: Clock },
          { label: "Urgent Tasks", value: tasks.filter(t => t.priority === 'urgent').length, icon: AlertTriangle },
        ].map(s => (
          <Card key={s.label} className="border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">{s.label}</span>
                <s.icon className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><Bed className="h-4 w-4" /> Admitted Patients</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Doctor</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {admissions.length === 0 ? (
                  <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No admitted patients</TableCell></TableRow>
                ) : admissions.map(a => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.patient_name}</TableCell>
                    <TableCell className="text-muted-foreground">{a.department}</TableCell>
                    <TableCell className="text-muted-foreground">{a.doctor}</TableCell>
                    <TableCell><Badge variant="outline" className="text-xs">{a.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><CheckCircle className="h-4 w-4" /> Pending Tasks</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {tasks.length === 0 ? (
                <div className="py-8 text-center text-sm text-muted-foreground">No pending tasks</div>
              ) : tasks.slice(0, 8).map(t => (
                <div key={t.id} className="px-4 py-3">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-foreground">{t.description}</p>
                    <Badge variant={t.priority === "urgent" ? "destructive" : "outline"} className="text-xs">{t.priority}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{t.patient_name} · {t.ward || 'General'}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
