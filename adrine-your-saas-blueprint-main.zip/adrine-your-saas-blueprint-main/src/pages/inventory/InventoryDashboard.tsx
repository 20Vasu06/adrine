import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, TrendingDown, AlertTriangle, IndianRupee, Truck, Clock, ClipboardList, Boxes, ArrowRight, ShieldAlert } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const container = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.35 } } };

export default function InventoryDashboard() {
  const { user } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const [requisitions, setRequisitions] = useState<any[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<any[]>([]);

  useEffect(() => {
    if (!user?.orgId) return;
    Promise.all([
      supabase.from('inventory_items').select('*').eq('org_id', user.orgId).eq('is_active', true),
      supabase.from('requisitions').select('*').eq('org_id', user.orgId).eq('status', 'pending').order('created_at', { ascending: false }),
      supabase.from('purchase_orders').select('*').eq('org_id', user.orgId).order('created_at', { ascending: false }),
    ]).then(([iRes, rRes, pRes]) => {
      if (iRes.data) setItems(iRes.data);
      if (rRes.data) setRequisitions(rRes.data);
      if (pRes.data) setPurchaseOrders(pRes.data);
    });
  }, [user?.orgId]);

  const lowStock = items.filter(i => i.current_stock < i.reorder_level);
  const totalValue = items.reduce((s, i) => s + (Number(i.current_stock) * Number(i.unit_price)), 0);
  const pendingPOs = purchaseOrders.filter(p => p.status !== 'received').length;

  const STATS = [
    { label: 'Total Items', value: String(items.length), sub: 'Active items', icon: Package, color: 'text-foreground' },
    { label: 'Stock Value', value: `₹${(totalValue / 100000).toFixed(1)}L`, sub: 'Total value', icon: IndianRupee, color: 'text-foreground' },
    { label: 'Low Stock', value: String(lowStock.length), sub: `${lowStock.filter(i => i.current_stock === 0).length} out of stock`, icon: TrendingDown, color: 'text-destructive' },
    { label: 'Pending Requisitions', value: String(requisitions.length), sub: 'Awaiting approval', icon: ClipboardList, color: 'text-foreground' },
    { label: 'Pending Orders', value: String(pendingPOs), sub: 'Purchase orders', icon: Truck, color: 'text-foreground' },
  ];

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item}>
        <h1 className="text-2xl font-bold tracking-tight">Central Store</h1>
        <p className="text-sm text-muted-foreground">Inventory management & supply chain overview</p>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {STATS.map(s => (
          <motion.div key={s.label} variants={item}>
            <Card className="border-border/60 hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <s.icon className={`h-5 w-5 mb-3 ${s.color}`} strokeWidth={1.5} />
                <p className="text-2xl font-bold tracking-tight">{s.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
                <p className={`text-xs mt-1 ${s.color}`}>{s.sub}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {lowStock.length > 0 && (
        <motion.div variants={item}>
          <Card className="bg-destructive/5 border-destructive/20">
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <ShieldAlert className="h-4 w-4 text-destructive" />
                <span className="text-xs font-medium tracking-[0.1em] uppercase text-destructive">Low Stock Items</span>
              </div>
              <div className="grid md:grid-cols-4 gap-3">
                {lowStock.slice(0, 4).map((i) => (
                  <div key={i.id} className="p-3 rounded-lg bg-background border border-border/60">
                    <p className="text-sm font-semibold">{i.name}</p>
                    <div className="flex items-baseline gap-1 mt-1">
                      <span className="text-lg font-bold text-destructive">{i.current_stock}</span>
                      <span className="text-[10px] text-muted-foreground">/ {i.reorder_level} min · {i.unit}</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-muted mt-2">
                      <div className="h-full rounded-full bg-destructive" style={{ width: `${Math.min((i.current_stock / i.reorder_level) * 100, 100)}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      <motion.div variants={item}>
        <Card className="border-border/60">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <ClipboardList className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
              <span className="text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground">Pending Requisitions</span>
            </div>
            {requisitions.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No pending requisitions</p>
            ) : (
              <div className="space-y-3">
                {requisitions.slice(0, 5).map(r => (
                  <div key={r.id} className="p-3 rounded-lg border border-border/60 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-mono font-semibold">{r.req_no}</span>
                      <Badge className={`text-[10px] ${r.priority === 'urgent' ? 'bg-destructive/10 text-destructive' : ''}`}>{r.priority}</Badge>
                    </div>
                    <p className="text-sm font-semibold">{r.from_department}</p>
                    <div className="flex items-center justify-between mt-1 text-[10px] text-muted-foreground">
                      <span>{Array.isArray(r.items) ? r.items.length : 0} items</span>
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {new Date(r.created_at).toLocaleDateString('en-IN')}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
