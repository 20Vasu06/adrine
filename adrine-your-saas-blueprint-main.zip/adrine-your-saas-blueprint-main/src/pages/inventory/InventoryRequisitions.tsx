import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, Plus, ArrowRight, CheckCircle2, Clock, 
  XCircle, Package, Building2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const STATUS_CONFIG: Record<string, { label: string; class: string; icon: any }> = {
  pending: { label: 'Pending', class: 'bg-warning/10 text-warning border-warning/20', icon: Clock },
  approved: { label: 'Approved', class: 'bg-info/10 text-info border-info/20', icon: CheckCircle2 },
  partial: { label: 'Partially Issued', class: 'bg-warning/10 text-warning border-warning/20', icon: Package },
  issued: { label: 'Issued', class: 'bg-success/10 text-success border-success/20', icon: CheckCircle2 },
  rejected: { label: 'Rejected', class: 'bg-destructive/10 text-destructive border-destructive/20', icon: XCircle },
};

const PRIORITY_CONFIG: Record<string, string> = {
  high: 'bg-destructive/10 text-destructive border-destructive/20',
  normal: 'bg-muted text-muted-foreground',
  low: 'bg-muted text-muted-foreground',
  urgent: 'bg-destructive/10 text-destructive border-destructive/20',
};

const container = { hidden: {}, show: { transition: { staggerChildren: 0.03 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function InventoryRequisitions() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [requisitions, setRequisitions] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from('requisitions')
        .select('*')
        .eq('org_id', orgId)
        .order('created_at', { ascending: false });
      setRequisitions(data || []);
      setLoading(false);
    };
    fetch();
  }, [orgId]);

  const filtered = requisitions.filter(r => {
    const matchSearch = r.from_department?.toLowerCase().includes(search.toLowerCase()) || r.req_no?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'All' || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const handleStatusUpdate = async (id: string, newStatus: string) => {
    const { error } = await supabase.from('requisitions').update({ status: newStatus }).eq('id', id);
    if (error) { toast.error('Failed to update'); return; }
    toast.success(`Requisition ${newStatus}`);
    setRequisitions(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r));
  };

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading requisitions...</div>;

  return (
    <motion.div className="space-y-6" variants={container} initial="hidden" animate="show">
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Requisitions</h1>
          <p className="text-sm text-muted-foreground">Department stock requests & approvals</p>
        </div>
        <Button size="sm" className="gap-1.5"><Plus className="h-3.5 w-3.5" /> New Requisition</Button>
      </motion.div>

      <motion.div variants={item} className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search requisitions..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9" />
        </div>
        <div className="flex gap-1 bg-muted p-0.5 rounded-lg">
          {['All', 'pending', 'approved', 'issued', 'partial'].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors capitalize ${statusFilter === s ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              {s}
            </button>
          ))}
        </div>
      </motion.div>

      <div className="space-y-3">
        {filtered.map(req => {
          const statusCfg = STATUS_CONFIG[req.status] || STATUS_CONFIG.pending;
          const StatusIcon = statusCfg.icon;
          const items = (req.items || []) as { name: string; qty: number; unit: string }[];
          return (
            <motion.div key={req.id} variants={item}>
              <Card className="border-border/60 hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-foreground text-background flex items-center justify-center">
                        <Building2 className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-mono font-bold">{req.req_no}</span>
                          <Badge className={`${statusCfg.class} text-[10px]`}>{statusCfg.label}</Badge>
                          <Badge className={`${PRIORITY_CONFIG[req.priority] || PRIORITY_CONFIG.normal} text-[10px]`}>{req.priority}</Badge>
                        </div>
                        <p className="text-[11px] text-muted-foreground">{req.from_department} {req.requested_by ? `• ${req.requested_by}` : ''}</p>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{new Date(req.created_at).toLocaleDateString()}</p>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-2">
                    {items.map((itm, i) => (
                      <span key={i} className="px-2.5 py-1 rounded-md bg-muted text-xs">
                        {itm.name} <span className="font-mono font-semibold">×{itm.qty}</span> {itm.unit}
                      </span>
                    ))}
                  </div>

                  {req.notes && (
                    <p className="text-[11px] text-warning bg-warning/5 px-2.5 py-1.5 rounded-md border border-warning/20 mt-2">{req.notes}</p>
                  )}

                  {req.status === 'pending' && (
                    <div className="flex gap-2 mt-3 pt-2 border-t border-border/40">
                      <Button size="sm" className="h-7 text-[11px]" onClick={() => handleStatusUpdate(req.id, 'approved')}>Approve & Issue</Button>
                      <Button variant="outline" size="sm" className="h-7 text-[11px]" onClick={() => handleStatusUpdate(req.id, 'rejected')}>Reject</Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
        {filtered.length === 0 && <p className="text-center text-muted-foreground py-8">No requisitions found.</p>}
      </div>
    </motion.div>
  );
}
