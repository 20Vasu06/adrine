import { useAuth, UserRole } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { ROLE_BASE_PATH } from '@/config/roleNavigation';
import { ROLE_LABELS } from '@/types/roles';
import { motion } from 'framer-motion';
import {
  Shield, Stethoscope, Heart, ClipboardList, FlaskConical,
  Pill, Receipt, Scan, Scissors, Package, Siren, Users,
  CalendarClock, Droplets,
} from 'lucide-react';

const ROLE_ICONS: Record<UserRole, React.ElementType> = {
  admin: Shield,
  doctor: Stethoscope,
  nurse: Heart,
  receptionist: ClipboardList,
  lab_technician: FlaskConical,
  pharmacist: Pill,
  billing: Receipt,
  radiologist: Scan,
  ot_coordinator: Scissors,
  inventory_manager: Package,
  emergency: Siren,
  hr_manager: Users,
  scheduler: CalendarClock,
  dialysis_tech: Droplets,
};

const ROLE_DESCRIPTIONS: Record<UserRole, string> = {
  admin: 'Full system control, staff management & analytics',
  doctor: 'OPD consultations, patient records & prescriptions',
  nurse: 'Ward management, medications & vitals',
  receptionist: 'Registration, appointments & check-in',
  lab_technician: 'Lab orders, sample processing & reports',
  pharmacist: 'Prescriptions, drug inventory & dispensing',
  billing: 'Invoices, payments & revenue tracking',
  radiologist: 'Imaging orders, worklist & reporting',
  ot_coordinator: 'Surgery scheduling, teams & inventory',
  inventory_manager: 'Stock management, procurement & distribution',
  emergency: 'Triage, emergency cases & trauma',
  hr_manager: 'Staff records, attendance & payroll',
  scheduler: 'Appointment slots, doctor schedules & resources',
  dialysis_tech: 'Dialysis sessions, machines & consumables',
};

// Map frontend roles to module_key values
const ROLE_TO_MODULE: Record<UserRole, string> = {
  admin: 'admin',
  doctor: 'doctor',
  nurse: 'nurse',
  receptionist: 'reception',
  lab_technician: 'lab',
  pharmacist: 'pharmacy',
  billing: 'billing',
  radiologist: 'radiology',
  ot_coordinator: 'ot',
  inventory_manager: 'inventory',
  emergency: 'emergency',
  hr_manager: 'hr',
  scheduler: 'scheduling',
  dialysis_tech: 'dialysis',
};

export default function RoleSelectionPage() {
  const { user, setActiveRole, availableRoles, enabledModules } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const allRoles = availableRoles.length > 0 ? availableRoles : [user.role];

  // Filter roles: admin always visible; others only if their module is enabled
  // If no modules are configured yet (empty array), show all roles
  const roles = enabledModules.length > 0
    ? allRoles.filter(role => role === 'admin' || enabledModules.includes(ROLE_TO_MODULE[role]))
    : allRoles;

  const handleSelectRole = (role: UserRole) => {
    setActiveRole(role);
    navigate(ROLE_BASE_PATH[role], { replace: true });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-3xl"
      >
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold tracking-tight text-foreground mb-2">
            Welcome, {user.name.split(' ')[0]}
          </h1>
          <p className="text-sm text-muted-foreground">
            {roles.length > 1
              ? 'Select a role to continue'
              : 'Continue to your workspace'}
          </p>
          {user.orgName && (
            <p className="text-xs text-muted-foreground mt-1">{user.orgName}</p>
          )}
        </div>

        <div className={`grid gap-3 ${roles.length <= 2 ? 'grid-cols-1 max-w-md mx-auto' : roles.length <= 4 ? 'grid-cols-2' : 'grid-cols-2 md:grid-cols-3'}`}>
          {roles.map((role, i) => {
            const Icon = ROLE_ICONS[role] || Shield;
            return (
              <motion.button
                key={role}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => handleSelectRole(role)}
                className="group flex items-start gap-4 p-5 rounded-xl border border-border hover:border-foreground/30 hover:bg-accent/50 transition-all text-left"
              >
                <div className="w-10 h-10 rounded-lg bg-foreground/5 group-hover:bg-foreground/10 flex items-center justify-center shrink-0 transition-colors">
                  <Icon className="w-5 h-5 text-foreground/70" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{ROLE_LABELS[role] || role}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                    {ROLE_DESCRIPTIONS[role] || 'Access your workspace'}
                  </p>
                </div>
              </motion.button>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
