import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, UserPlus, Mail, Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_STYLE: Record<string, string> = {
  true: 'bg-success/10 text-success',
  false: 'bg-muted text-muted-foreground',
};

export default function HRStaff() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');
  const [profiles, setProfiles] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    supabase.from('profiles').select('*').eq('org_id', orgId).order('full_name').then(({ data }) => setProfiles(data || []));
  }, [orgId]);

  const departments = [...new Set(profiles.map(s => s.department).filter(Boolean))];

  const filtered = profiles.filter(s => {
    if (search && !s.full_name.toLowerCase().includes(search.toLowerCase()) && !(s.employee_id || '').includes(search)) return false;
    if (deptFilter !== 'all' && s.department !== deptFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Staff Profiles</h1>
          <p className="text-sm text-muted-foreground mt-1">{profiles.length} staff members</p>
        </div>
        <Button className="gap-2"><UserPlus className="w-4 h-4" />Add Staff Member</Button>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search by name or ID..." className="pl-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={deptFilter} onValueChange={setDeptFilter}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Department" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            {departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((s, i) => (
          <motion.div key={s.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
            <Card className="p-4 hover:shadow-sm transition-shadow cursor-pointer">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-full bg-foreground/10 flex items-center justify-center text-sm font-bold text-foreground">
                  {s.full_name.split(' ').map((n: string) => n[0]).join('').slice(0, 2)}
                </div>
                <Badge className={`text-[10px] ${STATUS_STYLE[String(s.is_active)]}`}>{s.is_active ? 'Active' : 'Inactive'}</Badge>
              </div>
              <h3 className="font-medium text-sm text-foreground">{s.full_name}</h3>
              <p className="text-xs text-muted-foreground">{s.designation || 'Staff'}</p>
              <div className="flex items-center gap-2 mt-2">
                {s.department && <Badge variant="secondary" className="text-[10px]">{s.department}</Badge>}
              </div>
              <div className="mt-3 space-y-1 text-[11px] text-muted-foreground">
                {s.email && <p className="flex items-center gap-1"><Mail className="w-3 h-3" />{s.email}</p>}
                {s.phone && <p className="flex items-center gap-1"><Phone className="w-3 h-3" />{s.phone}</p>}
              </div>
              {s.employee_id && <p className="text-[10px] text-muted-foreground mt-2">ID: {s.employee_id}</p>}
            </Card>
          </motion.div>
        ))}
        {filtered.length === 0 && <p className="text-sm text-muted-foreground col-span-3 text-center py-8">No staff found</p>}
      </div>
    </div>
  );
}
