import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Download, Clock, CheckCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_STYLE: Record<string, string> = {
  present: 'bg-success/10 text-success',
  late: 'bg-warning/10 text-warning',
  absent: 'bg-destructive/10 text-destructive',
  on_leave: 'bg-info/10 text-info',
};

export default function HRAttendance() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [attendance, setAttendance] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('staff_attendance').select('*').eq('org_id', orgId).eq('date', today),
      supabase.from('profiles').select('user_id, full_name, department, employee_id').eq('org_id', orgId).eq('is_active', true),
    ]).then(([attRes, profRes]) => {
      setAttendance(attRes.data || []);
      setProfiles(profRes.data || []);
    });
  }, [orgId]);

  // Merge attendance with profiles
  const merged = profiles.map(p => {
    const att = attendance.find(a => a.user_id === p.user_id);
    return {
      ...p,
      checkIn: att?.check_in || '—',
      checkOut: att?.check_out || '—',
      status: att?.status || 'absent',
      shift: att?.shift || '—',
    };
  });

  const filtered = merged.filter(a => {
    if (search && !a.full_name.toLowerCase().includes(search.toLowerCase())) return false;
    if (statusFilter !== 'all' && a.status !== statusFilter) return false;
    return true;
  });

  const present = merged.filter(a => a.status === 'present').length;
  const late = merged.filter(a => a.status === 'late').length;
  const absent = merged.filter(a => a.status === 'absent').length;
  const onLeave = merged.filter(a => a.status === 'on_leave').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Attendance</h1>
          <p className="text-sm text-muted-foreground mt-1">Daily staff attendance tracking</p>
        </div>
        <Button variant="outline" className="gap-2 text-sm"><Download className="w-4 h-4" />Export</Button>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <Card className="p-4"><div className="flex items-center gap-2 mb-1"><CheckCircle className="w-4 h-4 text-success" /><span className="text-xs text-muted-foreground">Present</span></div><p className="text-xl font-bold text-foreground">{present}</p></Card>
        <Card className="p-4"><div className="flex items-center gap-2 mb-1"><Clock className="w-4 h-4 text-warning" /><span className="text-xs text-muted-foreground">Late</span></div><p className="text-xl font-bold text-foreground">{late}</p></Card>
        <Card className="p-4"><div className="flex items-center gap-2 mb-1"><AlertTriangle className="w-4 h-4 text-destructive" /><span className="text-xs text-muted-foreground">Absent</span></div><p className="text-xl font-bold text-foreground">{absent}</p></Card>
        <Card className="p-4"><div className="flex items-center gap-2 mb-1"><Clock className="w-4 h-4 text-info" /><span className="text-xs text-muted-foreground">On Leave</span></div><p className="text-xl font-bold text-foreground">{onLeave}</p></Card>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search staff..." className="pl-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="present">Present</SelectItem>
            <SelectItem value="late">Late</SelectItem>
            <SelectItem value="absent">Absent</SelectItem>
            <SelectItem value="on_leave">On Leave</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-xs">Employee ID</TableHead>
              <TableHead className="text-xs">Name</TableHead>
              <TableHead className="text-xs">Department</TableHead>
              <TableHead className="text-xs">Check-In</TableHead>
              <TableHead className="text-xs">Check-Out</TableHead>
              <TableHead className="text-xs">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map(a => (
              <TableRow key={a.user_id}>
                <TableCell className="font-mono text-xs">{a.employee_id || '—'}</TableCell>
                <TableCell className="text-sm font-medium">{a.full_name}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{a.department || '—'}</TableCell>
                <TableCell className="text-xs">{a.checkIn}</TableCell>
                <TableCell className="text-xs">{a.checkOut}</TableCell>
                <TableCell><Badge className={`text-[10px] ${STATUS_STYLE[a.status] || ''}`}>{a.status}</Badge></TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No attendance records</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
