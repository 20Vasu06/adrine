import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_STYLE: Record<string, 'destructive' | 'outline' | 'default'> = {
  pending: 'outline',
  approved: 'default',
  rejected: 'destructive',
};

const TYPE_COLORS: Record<string, string> = {
  casual: 'bg-info/10 text-info',
  sick: 'bg-warning/10 text-warning',
  annual: 'bg-success/10 text-success',
  emergency: 'bg-destructive/10 text-destructive',
};

export default function HRLeave() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [leaves, setLeaves] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    supabase.from('leave_requests').select('*').eq('org_id', orgId).order('created_at', { ascending: false }).then(({ data }) => setLeaves(data || []));
  }, [orgId]);

  const pending = leaves.filter(l => l.status === 'pending').length;

  const handleAction = async (id: string, status: string) => {
    const { error } = await supabase.from('leave_requests').update({ status }).eq('id', id);
    if (!error) {
      setLeaves(prev => prev.map(l => l.id === id ? { ...l, status } : l));
      toast.success(`Leave ${status}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Leave Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Process leave requests and track balances</p>
        </div>
        <Badge variant="outline" className="text-sm px-3 py-1">{pending} Pending Approvals</Badge>
      </div>

      <div className="space-y-3">
        {leaves.length > 0 ? leaves.map(l => (
          <Card key={l.id} className="p-4 hover:shadow-sm transition-shadow">
            <div className="flex items-start justify-between">
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2">
                  <Badge className={`text-[10px] ${TYPE_COLORS[l.leave_type] || ''}`}>{l.leave_type}</Badge>
                  <Badge variant={STATUS_STYLE[l.status] || 'outline'} className="text-[10px]">{l.status}</Badge>
                </div>
                <p className="text-sm font-medium text-foreground">{l.employee_name}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{l.from_date} → {l.to_date}</span>
                  <span>{l.days} day{l.days > 1 ? 's' : ''}</span>
                </div>
                {l.reason && <p className="text-xs text-muted-foreground">Reason: {l.reason}</p>}
              </div>
              {l.status === 'pending' && (
                <div className="flex gap-2">
                  <Button size="sm" className="text-xs gap-1" onClick={() => handleAction(l.id, 'approved')}><CheckCircle className="w-3 h-3" />Approve</Button>
                  <Button size="sm" variant="outline" className="text-xs gap-1" onClick={() => handleAction(l.id, 'rejected')}><XCircle className="w-3 h-3" />Reject</Button>
                </div>
              )}
            </div>
          </Card>
        )) : (
          <p className="text-sm text-muted-foreground text-center py-8">No leave requests</p>
        )}
      </div>
    </div>
  );
}
