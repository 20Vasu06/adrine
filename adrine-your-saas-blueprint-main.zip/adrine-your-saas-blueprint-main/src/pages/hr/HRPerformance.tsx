import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Star, Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function HRPerformance() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [deptFilter, setDeptFilter] = useState('all');
  const [profiles, setProfiles] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('profiles').select('*').eq('org_id', orgId).eq('is_active', true),
      supabase.from('departments').select('name').eq('org_id', orgId).eq('is_active', true),
    ]).then(([profRes, deptRes]) => {
      setProfiles(profRes.data || []);
      setDepartments(deptRes.data || []);
    });
  }, [orgId]);

  // Generate performance data from profiles
  const performanceData = profiles.map(p => ({
    name: p.full_name,
    dept: p.department || 'General',
    designation: p.designation || 'Staff',
    score: Math.floor(Math.random() * 20) + 75, // placeholder until real performance tracking
  }));

  const filtered = deptFilter === 'all' ? performanceData : performanceData.filter(p => p.dept === deptFilter);

  // Dept chart
  const deptGroups = new Map<string, number[]>();
  performanceData.forEach(p => {
    const arr = deptGroups.get(p.dept) || [];
    arr.push(p.score);
    deptGroups.set(p.dept, arr);
  });
  const deptChart = Array.from(deptGroups.entries()).map(([dept, scores]) => ({
    dept,
    avg: Math.round(scores.reduce((a, b) => a + b, 0) / scores.length),
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Performance</h1>
          <p className="text-sm text-muted-foreground mt-1">Staff productivity metrics and performance reviews</p>
        </div>
        <Button variant="outline" className="gap-2 text-sm"><Download className="w-4 h-4" />Export</Button>
      </div>

      {deptChart.length > 0 && (
        <Card className="p-4">
          <h3 className="text-sm font-semibold text-foreground mb-4">Department Average Performance Score</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={deptChart}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="dept" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
              <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} domain={[70, 100]} />
              <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="avg" fill="hsl(var(--foreground))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      )}

      <div className="flex items-center gap-3">
        <Select value={deptFilter} onValueChange={setDeptFilter}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="All Departments" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            {departments.map(d => <SelectItem key={d.name} value={d.name}>{d.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-3">
        {filtered.map(p => (
          <Card key={p.name} className="p-4 hover:shadow-sm transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-foreground">{p.name}</p>
                  <Badge variant="outline" className="text-[10px]">{p.designation}</Badge>
                  <Badge variant="secondary" className="text-[10px]">{p.dept}</Badge>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Star className={`w-4 h-4 ${p.score >= 90 ? 'text-warning fill-warning' : 'text-muted-foreground'}`} />
                <span className="text-lg font-bold text-foreground">{p.score}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Progress value={p.score} className={`h-2 flex-1 ${p.score >= 90 ? '[&>div]:bg-success' : p.score >= 80 ? '' : '[&>div]:bg-warning'}`} />
              <span className="text-xs text-muted-foreground">{p.score}%</span>
            </div>
          </Card>
        ))}
        {filtered.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No staff data</p>}
      </div>
    </div>
  );
}
