import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CalendarDays, Clock, Users, Plus, Sun, Moon, Sunset } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const SHIFT_ICONS: Record<string, React.ElementType> = { morning: Sun, evening: Sunset, night: Moon };
const SHIFT_TIMES: Record<string, string> = { morning: '7:00 AM – 2:00 PM', evening: '2:00 PM – 9:00 PM', night: '9:00 PM – 7:00 AM' };

export default function HRScheduling() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [shiftFilter, setShiftFilter] = useState('all');
  const [attendance, setAttendance] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('staff_attendance').select('*').eq('org_id', orgId).eq('date', today),
      supabase.from('profiles').select('user_id, full_name, department').eq('org_id', orgId).eq('is_active', true),
    ]).then(([attRes, profRes]) => {
      setAttendance(attRes.data || []);
      setProfiles(profRes.data || []);
    });
  }, [orgId]);

  // Group by shift and department
  const shiftGroups = new Map<string, Map<string, string[]>>();
  attendance.forEach(a => {
    const shift = a.shift || 'general';
    const prof = profiles.find(p => p.user_id === a.user_id);
    const dept = prof?.department || 'General';
    const name = prof?.full_name || 'Unknown';
    if (!shiftGroups.has(shift)) shiftGroups.set(shift, new Map());
    const deptMap = shiftGroups.get(shift)!;
    if (!deptMap.has(dept)) deptMap.set(dept, []);
    deptMap.get(dept)!.push(name);
  });

  const todaySchedule = Array.from(shiftGroups.entries()).flatMap(([shift, deptMap]) =>
    Array.from(deptMap.entries()).map(([dept, staff]) => ({
      shift,
      department: dept,
      staff,
      coverage: 'Full',
    }))
  );

  const filtered = shiftFilter === 'all' ? todaySchedule : todaySchedule.filter(s => s.shift === shiftFilter);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Staff Scheduling</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage shifts, duty rosters, and on-call assignments</p>
        </div>
        <Button className="gap-2"><Plus className="w-4 h-4" />Create Shift</Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {Object.entries(SHIFT_TIMES).map(([shift, time]) => {
          const Icon = SHIFT_ICONS[shift];
          const count = todaySchedule.filter(s => s.shift === shift).flatMap(s => s.staff).length;
          return (
            <Card key={shift} className="p-4 cursor-pointer hover:shadow-sm transition-shadow" onClick={() => setShiftFilter(shift)}>
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-semibold text-foreground capitalize">{shift} Shift</span>
              </div>
              <p className="text-xs text-muted-foreground">{time}</p>
              <p className="text-lg font-bold text-foreground mt-1">{count} staff</p>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="today">
        <TabsList>
          <TabsTrigger value="today">Today's Schedule</TabsTrigger>
        </TabsList>

        <div className="mt-2">
          <Select value={shiftFilter} onValueChange={setShiftFilter}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="All Shifts" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Shifts</SelectItem>
              <SelectItem value="morning">Morning</SelectItem>
              <SelectItem value="evening">Evening</SelectItem>
              <SelectItem value="night">Night</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <TabsContent value="today" className="mt-4 space-y-3">
          {filtered.length > 0 ? filtered.map((s, i) => {
            const Icon = SHIFT_ICONS[s.shift] || Sun;
            return (
              <Card key={i} className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded bg-muted flex items-center justify-center">
                      <Icon className="w-4 h-4 text-foreground" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-foreground">{s.department}</span>
                        <Badge variant="outline" className="text-[10px] capitalize">{s.shift}</Badge>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {s.staff.map(name => (
                          <Badge key={name} variant="secondary" className="text-[10px]">{name}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  <Badge variant="default" className="text-[10px]">{s.coverage}</Badge>
                </div>
              </Card>
            );
          }) : (
            <p className="text-sm text-muted-foreground text-center py-8">No schedule data for today</p>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
