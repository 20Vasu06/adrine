import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Download, FileText, Users, Clock, TrendingUp } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function HRReports() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [staffCount, setStaffCount] = useState(0);
  const [deptDistribution, setDeptDistribution] = useState<{ name: string; value: number; color: string }[]>([]);
  const [leaveCount, setLeaveCount] = useState(0);

  const COLORS = ['hsl(var(--foreground))', 'hsl(var(--muted-foreground))', 'hsl(var(--info))', 'hsl(var(--warning))', 'hsl(var(--success))', 'hsl(var(--destructive))'];

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('profiles').select('department').eq('org_id', orgId).eq('is_active', true),
      supabase.from('leave_requests').select('id', { count: 'exact', head: true }).eq('org_id', orgId),
    ]).then(([profRes, leaveRes]) => {
      const profiles = profRes.data || [];
      setStaffCount(profiles.length);
      setLeaveCount(leaveRes.count || 0);

      // Group by department
      const deptMap = new Map<string, number>();
      profiles.forEach(p => {
        const dept = p.department || 'General';
        deptMap.set(dept, (deptMap.get(dept) || 0) + 1);
      });
      setDeptDistribution(Array.from(deptMap.entries()).map(([name, value], i) => ({
        name, value, color: COLORS[i % COLORS.length],
      })));
    });
  }, [orgId]);

  const reportTemplates = [
    { title: 'Staff Attendance Report', desc: 'Monthly attendance summary with late/absent details', icon: Clock },
    { title: 'Department Staffing Report', desc: 'Current staffing levels across all departments', icon: Users },
    { title: 'Leave Utilization Report', desc: 'Leave type distribution and balance summary', icon: FileText },
    { title: 'Training Compliance Report', desc: 'Mandatory training completion rates', icon: FileText },
    { title: 'Staff Turnover Analysis', desc: 'Hiring vs attrition trends', icon: TrendingUp },
    { title: 'Credential Expiry Report', desc: 'Upcoming license and certification renewals', icon: FileText },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">HR Reports & Analytics</h1>
          <p className="text-sm text-muted-foreground mt-1">Workforce analytics and HR documentation</p>
        </div>
        <Button variant="outline" className="gap-2 text-sm"><Download className="w-4 h-4" />Export All</Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Staff', value: staffCount.toString() },
          { label: 'Leave Requests', value: leaveCount.toString() },
          { label: 'Departments', value: deptDistribution.length.toString() },
          { label: 'Training Programs', value: '6' },
        ].map(s => (
          <Card key={s.label} className="p-4">
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="analytics">
        <TabsList>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="templates">Report Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="analytics" className="mt-4 space-y-6">
          {deptDistribution.length > 0 && (
            <Card className="p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Staff Distribution by Department</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={deptDistribution} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({ name, value }) => `${name}: ${value}`} fontSize={11}>
                    {deptDistribution.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="templates" className="mt-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {reportTemplates.map(r => (
              <Card key={r.title} className="p-4 hover:shadow-sm transition-shadow cursor-pointer">
                <r.icon className="w-5 h-5 text-muted-foreground mb-3" />
                <h3 className="text-sm font-semibold text-foreground">{r.title}</h3>
                <p className="text-xs text-muted-foreground mt-1">{r.desc}</p>
                <Button variant="outline" size="sm" className="text-xs mt-3 gap-1"><Download className="w-3 h-3" />Generate</Button>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
