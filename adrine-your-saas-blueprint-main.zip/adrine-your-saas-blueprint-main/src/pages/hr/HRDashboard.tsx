import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Users, Clock, CalendarCheck, AlertTriangle, UserPlus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function HRDashboard() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [profiles, setProfiles] = useState<any[]>([]);
  const [leaveRequests, setLeaveRequests] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('profiles').select('*').eq('org_id', orgId),
      supabase.from('leave_requests').select('*').eq('org_id', orgId).order('created_at', { ascending: false }).limit(10),
    ]).then(([pRes, lRes]) => {
      setProfiles(pRes.data || []);
      setLeaveRequests(lRes.data || []);
    });
  }, [orgId]);

  const totalStaff = profiles.length;
  const activeStaff = profiles.filter(p => p.is_active).length;
  const pendingLeaves = leaveRequests.filter(l => l.status === 'pending').length;
  const onLeave = leaveRequests.filter(l => l.status === 'approved' && new Date(l.from_date) <= new Date() && new Date(l.to_date) >= new Date()).length;

  const stats = [
    { label: 'Total Staff', value: String(totalStaff), icon: Users, change: `${activeStaff} active` },
    { label: 'On Duty Today', value: String(activeStaff - onLeave), icon: CalendarCheck, change: `${totalStaff ? Math.round(((activeStaff - onLeave) / totalStaff) * 100) : 0}% workforce` },
    { label: 'On Leave', value: String(onLeave), icon: Clock, change: `${pendingLeaves} pending` },
    { label: 'Pending Actions', value: String(pendingLeaves), icon: AlertTriangle, change: 'Leave requests', accent: pendingLeaves > 0 },
  ];

  // Group by department
  const deptMap = new Map<string, { total: number; active: number }>();
  profiles.forEach(p => {
    const dept = p.department || 'Unassigned';
    const existing = deptMap.get(dept) || { total: 0, active: 0 };
    existing.total += 1;
    if (p.is_active) existing.active += 1;
    deptMap.set(dept, existing);
  });
  const departmentStaffing = Array.from(deptMap.entries()).map(([dept, data]) => ({ dept, ...data }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">HR & Staff Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Workforce overview and staff operations</p>
        </div>
        <Button className="gap-2"><UserPlus className="w-4 h-4" />Add Staff</Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card className={`p-5 ${s.accent ? 'border-destructive/30 bg-destructive/5' : ''}`}>
              <div className="flex items-center justify-between mb-3">
                <s.icon className={`w-5 h-5 ${s.accent ? 'text-destructive' : 'text-muted-foreground'}`} />
                <span className="text-[11px] text-muted-foreground">{s.change}</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <h2 className="text-sm font-semibold text-foreground mb-3">Department Staffing</h2>
          <Card className="p-4">
            <div className="space-y-3">
              {departmentStaffing.length > 0 ? departmentStaffing.map(d => (
                <div key={d.dept} className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-sm font-medium text-foreground w-24">{d.dept}</span>
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-foreground rounded-full" style={{ width: `${(d.active / d.total) * 100}%` }} />
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground ml-4">{d.active}/{d.total}</span>
                </div>
              )) : (
                <p className="text-xs text-muted-foreground text-center py-2">No staff data</p>
              )}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="text-sm font-semibold text-foreground mb-3">Recent Leave Requests</h2>
            <div className="space-y-2">
              {leaveRequests.slice(0, 5).map(l => (
                <Card key={l.id} className="p-3">
                  <p className="text-xs font-medium text-foreground">{l.employee_name}</p>
                  <p className="text-[11px] text-muted-foreground">{l.leave_type} — {l.from_date} to {l.to_date}</p>
                  <Badge variant={l.status === 'approved' ? 'default' : l.status === 'rejected' ? 'destructive' : 'outline'} className="text-[10px] mt-1">{l.status}</Badge>
                </Card>
              ))}
              {leaveRequests.length === 0 && <p className="text-xs text-muted-foreground text-center py-2">No leave requests</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
