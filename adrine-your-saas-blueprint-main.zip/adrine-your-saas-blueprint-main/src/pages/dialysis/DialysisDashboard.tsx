import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Activity, Users, Clock, AlertTriangle, CheckCircle, Droplets, Settings, Cpu } from "lucide-react";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function DialysisDashboard() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [sessions, setSessions] = useState<any[]>([]);
  const [machines, setMachines] = useState<any[]>([]);
  const [patientCount, setPatientCount] = useState(0);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    Promise.all([
      supabase.from('dialysis_sessions').select('*').eq('org_id', orgId).eq('session_date', today).order('start_time'),
      supabase.from('dialysis_machines').select('*').eq('org_id', orgId),
      supabase.from('dialysis_sessions').select('patient_id', { count: 'exact' }).eq('org_id', orgId),
    ]).then(([sRes, mRes, pRes]) => {
      setSessions(sRes.data || []);
      setMachines(mRes.data || []);
      // Count distinct patients (approximate)
      const uniquePatients = new Set((pRes.data || []).map((r: any) => r.patient_id));
      setPatientCount(uniquePatients.size);
    });
  }, [orgId]);

  const inProgress = sessions.filter(s => s.status === 'in_progress').length;
  const availableMachines = machines.filter(m => m.status === 'available').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dialysis Unit Dashboard</h1>
          <p className="text-sm text-muted-foreground">{new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
        <Button variant="outline" size="sm"><Settings className="w-4 h-4 mr-2" /> Unit Settings</Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card><CardContent className="pt-6"><div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10"><Droplets className="w-5 h-5 text-primary" /></div>
          <div><p className="text-2xl font-bold">{sessions.length}</p><p className="text-xs text-muted-foreground">Today's Sessions</p></div>
        </div></CardContent></Card>
        <Card><CardContent className="pt-6"><div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-success/10"><CheckCircle className="w-5 h-5 text-success" /></div>
          <div><p className="text-2xl font-bold">{inProgress}</p><p className="text-xs text-muted-foreground">In Progress</p></div>
        </div></CardContent></Card>
        <Card><CardContent className="pt-6"><div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-info/10"><Cpu className="w-5 h-5 text-info" /></div>
          <div><p className="text-2xl font-bold">{availableMachines} / {machines.length}</p><p className="text-xs text-muted-foreground">Machines Available</p></div>
        </div></CardContent></Card>
        <Card><CardContent className="pt-6"><div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-warning/10"><Users className="w-5 h-5 text-warning" /></div>
          <div><p className="text-2xl font-bold">{patientCount}</p><p className="text-xs text-muted-foreground">Active Patients</p></div>
        </div></CardContent></Card>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Clock className="w-4 h-4" /> Today's Sessions</CardTitle></CardHeader>
            <CardContent>
              {sessions.length > 0 ? (
                <div className="space-y-3">
                  {sessions.map(s => (
                    <div key={s.id} className="flex items-center gap-4 p-3 rounded-lg border bg-card">
                      <div className="min-w-[70px] text-xs font-mono text-muted-foreground">{s.start_time?.substring(0, 5) || '—'}</div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{s.patient_name}</p>
                        <p className="text-xs text-muted-foreground">Tech: {s.technician || '—'}</p>
                      </div>
                      <Badge variant={s.status === 'in_progress' ? 'default' : s.status === 'completed' ? 'secondary' : 'outline'} className="text-xs">{s.status}</Badge>
                      <Button variant="ghost" size="sm" className="text-xs">View</Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">No sessions today</p>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Cpu className="w-4 h-4" /> Machine Status</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {machines.map(m => (
                <div key={m.id} className={`p-3 rounded-lg border text-center ${m.status === 'in_use' ? 'border-primary/30 bg-primary/5' : m.status === 'maintenance' ? 'border-destructive/30 bg-destructive/5' : 'border-border bg-card'}`}>
                  <Cpu className="w-5 h-5 mx-auto mb-1 text-muted-foreground" />
                  <p className="font-bold text-sm">{m.machine_no}</p>
                  <p className="text-[10px] text-muted-foreground">{m.machine_name}</p>
                  <Badge variant={m.status === 'available' ? 'secondary' : m.status === 'maintenance' ? 'destructive' : 'default'} className="mt-1 text-[10px]">{m.status}</Badge>
                </div>
              ))}
              {machines.length === 0 && <p className="text-xs text-muted-foreground text-center col-span-2 py-4">No machines configured</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
