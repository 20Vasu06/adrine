import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarClock, Plus, ChevronLeft, ChevronRight } from "lucide-react";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { format, startOfWeek, addDays, addWeeks } from 'date-fns';

const weekDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const shifts = [
  { label: "Shift 1", time: "06:00 – 10:00", start: "06:00", end: "10:00" },
  { label: "Shift 2", time: "10:00 – 14:00", start: "10:00", end: "14:00" },
  { label: "Shift 3", time: "14:00 – 18:00", start: "14:00", end: "18:00" },
  { label: "Shift 4", time: "18:00 – 22:00", start: "18:00", end: "22:00" },
];

export default function DialysisSchedule() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [showNewSession, setShowNewSession] = useState(false);
  const [weekOffset, setWeekOffset] = useState(0);
  const [sessions, setSessions] = useState<any[]>([]);
  const [machines, setMachines] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);

  const weekStart = startOfWeek(addWeeks(new Date(), weekOffset), { weekStartsOn: 1 });

  useEffect(() => {
    if (!orgId) return;
    const from = format(weekStart, 'yyyy-MM-dd');
    const to = format(addDays(weekStart, 5), 'yyyy-MM-dd');

    Promise.all([
      supabase.from('dialysis_sessions').select('*').eq('org_id', orgId).gte('session_date', from).lte('session_date', to),
      supabase.from('dialysis_machines').select('*').eq('org_id', orgId),
      supabase.from('patients').select('id, name, uhid').eq('org_id', orgId).eq('patient_type', 'OPD'),
    ]).then(([sessRes, machRes, patRes]) => {
      setSessions(sessRes.data || []);
      setMachines(machRes.data || []);
      setPatients(patRes.data || []);
    });
  }, [orgId, weekOffset]);

  const getWeekLabel = () => {
    const end = addDays(weekStart, 5);
    return `${format(weekStart, 'd MMM')} – ${format(end, 'd MMM yyyy')}`;
  };

  // Group sessions by day and shift
  const getSessionsForDayShift = (day: string, shift: typeof shifts[0]) => {
    const dayIndex = weekDays.indexOf(day);
    const date = format(addDays(weekStart, dayIndex), 'yyyy-MM-dd');
    return sessions.filter(s => {
      if (s.session_date !== date) return false;
      if (!s.start_time) return shift.label === 'Shift 1';
      const hour = parseInt(s.start_time.split(':')[0]);
      if (hour >= 6 && hour < 10) return shift.label === 'Shift 1';
      if (hour >= 10 && hour < 14) return shift.label === 'Shift 2';
      if (hour >= 14 && hour < 18) return shift.label === 'Shift 3';
      if (hour >= 18 && hour < 22) return shift.label === 'Shift 4';
      return false;
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dialysis Schedule</h1>
          <p className="text-sm text-muted-foreground">Recurring session scheduling with machine & technician allocation</p>
        </div>
        <Dialog open={showNewSession} onOpenChange={setShowNewSession}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="w-4 h-4 mr-2" /> Schedule Session</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Schedule Dialysis Session</DialogTitle></DialogHeader>
            <div className="grid gap-4 mt-4">
              <div><Label>Patient</Label>
                <Select><SelectTrigger className="mt-1"><SelectValue placeholder="Select patient" /></SelectTrigger>
                  <SelectContent>
                    {patients.map(p => <SelectItem key={p.id} value={p.id}>{p.name} ({p.uhid})</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Recurring Days</Label>
                <div className="flex flex-wrap gap-3 mt-2">
                  {weekDays.map(d => (
                    <label key={d} className="flex items-center gap-1.5 text-sm">
                      <Checkbox defaultChecked={["Monday","Wednesday","Friday"].includes(d)} />
                      {d.slice(0,3)}
                    </label>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Shift</Label>
                  <Select><SelectTrigger className="mt-1"><SelectValue placeholder="Select shift" /></SelectTrigger>
                    <SelectContent>{shifts.map(s => <SelectItem key={s.label} value={s.label}>{s.label} ({s.time})</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Machine</Label>
                  <Select><SelectTrigger className="mt-1"><SelectValue placeholder="Auto-assign" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto-assign</SelectItem>
                      {machines.map(m => <SelectItem key={m.id} value={m.id}>{m.machine_no} - {m.machine_name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Start Date</Label><Input type="date" className="mt-1" /></div>
                <div><Label>End Date (optional)</Label><Input type="date" className="mt-1" /></div>
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setShowNewSession(false)}>Cancel</Button>
              <Button onClick={() => { setShowNewSession(false); toast.success("Dialysis schedule created successfully"); }}>Create Schedule</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Week Navigator */}
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => setWeekOffset(w => w - 1)}><ChevronLeft className="w-4 h-4" /></Button>
        <div className="flex items-center gap-2">
          <CalendarClock className="w-4 h-4 text-muted-foreground" />
          <span className="font-medium text-sm">{getWeekLabel()}</span>
        </div>
        <Button variant="outline" size="icon" onClick={() => setWeekOffset(w => w + 1)}><ChevronRight className="w-4 h-4" /></Button>
        <Button variant="ghost" size="sm" onClick={() => setWeekOffset(0)}>This Week</Button>
      </div>

      {/* Weekly Grid */}
      <div className="grid grid-cols-6 gap-3">
        {weekDays.map(day => {
          const daySessions = sessions.filter(s => {
            const dayIndex = weekDays.indexOf(day);
            return s.session_date === format(addDays(weekStart, dayIndex), 'yyyy-MM-dd');
          });
          return (
            <Card key={day} className={daySessions.length === 0 ? 'opacity-50' : ''}>
              <CardHeader className="py-3 px-4">
                <CardTitle className="text-sm">{day}</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                {daySessions.length > 0 ? (
                  <div className="space-y-3">
                    {shifts.map(shift => {
                      const shiftSessions = getSessionsForDayShift(day, shift);
                      if (shiftSessions.length === 0) return null;
                      return (
                        <div key={shift.label}>
                          <p className="text-[10px] font-semibold text-muted-foreground uppercase mb-1">{shift.label} <span className="font-normal">({shift.time})</span></p>
                          <div className="space-y-1.5">
                            {shiftSessions.map((s) => (
                              <div key={s.id} className="p-2 rounded border bg-muted/30 text-xs">
                                <p className="font-medium">{s.patient_name}</p>
                                <p className="text-muted-foreground">{s.technician || 'Unassigned'}</p>
                                <Badge variant={s.status === 'scheduled' ? 'default' : 'secondary'} className="mt-1 text-[9px]">{s.status}</Badge>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground text-center py-4">No sessions</p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
