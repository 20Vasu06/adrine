import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart3, FileText, Download, Activity,
  Users, IndianRupee
} from "lucide-react";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function DialysisReports() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [sessions, setSessions] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('dialysis_sessions').select('*').eq('org_id', orgId).order('session_date', { ascending: false }).limit(200),
      supabase.from('patients').select('id, name, uhid').eq('org_id', orgId),
    ]).then(([sessRes, patRes]) => {
      setSessions(sessRes.data || []);
      setPatients(patRes.data || []);
    });
  }, [orgId]);

  // Build patient summary from real sessions
  const patientMap = new Map<string, { name: string; uhid: string; sessions: number; complications: number }>();
  sessions.forEach(s => {
    const key = s.patient_id;
    const existing = patientMap.get(key) || { name: s.patient_name, uhid: '', sessions: 0, complications: 0 };
    existing.sessions++;
    if (s.complications) existing.complications++;
    const pat = patients.find(p => p.id === key);
    if (pat) existing.uhid = pat.uhid;
    patientMap.set(key, existing);
  });

  const patientSummaries = Array.from(patientMap.values());
  const totalSessions = sessions.length;
  const completedSessions = sessions.filter(s => s.status === 'completed').length;

  const reportTemplates = [
    { name: 'Daily Dialysis Sessions Report', desc: 'All sessions conducted today with patient, machine, technician details', records: sessions.filter(s => s.session_date === new Date().toISOString().split('T')[0]).length },
    { name: 'Dialysis Patient List', desc: 'Complete list of active dialysis patients with profiles', records: patientSummaries.length },
    { name: 'Machine Utilization Report', desc: 'Machine-wise utilization rate, downtime, sessions count', records: '—' },
    { name: 'Complication Report', desc: 'All dialysis complications logged with outcomes', records: sessions.filter(s => s.complications).length },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dialysis Reports</h1>
          <p className="text-sm text-muted-foreground">Operational, clinical & financial reporting</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <BarChart3 className="w-5 h-5 text-primary" />
          <div><p className="text-2xl font-bold">{totalSessions}</p><p className="text-xs text-muted-foreground">Total Sessions</p></div>
        </CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <Activity className="w-5 h-5 text-green-600" />
          <div><p className="text-2xl font-bold">{completedSessions}</p><p className="text-xs text-muted-foreground">Completed</p></div>
        </CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <Users className="w-5 h-5 text-blue-600" />
          <div><p className="text-2xl font-bold">{patientSummaries.length}</p><p className="text-xs text-muted-foreground">Unique Patients</p></div>
        </CardContent></Card>
      </div>

      <Tabs defaultValue="reports">
        <TabsList>
          <TabsTrigger value="reports"><FileText className="w-3.5 h-3.5 mr-1.5" />Reports</TabsTrigger>
          <TabsTrigger value="patient-history"><Users className="w-3.5 h-3.5 mr-1.5" />Patient History</TabsTrigger>
        </TabsList>

        <TabsContent value="reports">
          <div className="space-y-3">
            {reportTemplates.map((r, i) => (
              <Card key={i}>
                <CardContent className="py-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-2 rounded-lg bg-primary/10"><FileText className="w-4 h-4 text-primary" /></div>
                    <div>
                      <p className="font-semibold text-sm">{r.name}</p>
                      <p className="text-xs text-muted-foreground">{r.desc}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm font-mono">{r.records} records</span>
                    <Button variant="outline" size="sm"><Download className="w-3.5 h-3.5 mr-1.5" />Export</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="patient-history">
          <Card>
            <CardHeader className="py-3"><CardTitle className="text-sm">Patient Treatment Summary</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Patient</TableHead>
                    <TableHead>Total Sessions</TableHead>
                    <TableHead>Complications</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {patientSummaries.map((p, i) => (
                    <TableRow key={i}>
                      <TableCell>
                        <div><p className="font-medium text-sm">{p.name}</p><p className="text-[10px] text-muted-foreground">{p.uhid}</p></div>
                      </TableCell>
                      <TableCell className="font-mono">{p.sessions}</TableCell>
                      <TableCell>
                        <Badge variant={p.complications > 10 ? "destructive" : "secondary"} className="text-[10px]">{p.complications}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {patientSummaries.length === 0 && (
                    <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-8">No data</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
