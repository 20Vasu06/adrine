import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Search, AlertTriangle, Package, TrendingDown } from "lucide-react";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function DialysisConsumables() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState("");
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    supabase.from('inventory_items').select('*').eq('org_id', orgId).eq('is_active', true)
      .order('name')
      .then(({ data }) => setItems(data || []));
  }, [orgId]);

  const lowStock = items.filter(i => i.current_stock <= i.reorder_level);
  const filtered = items.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));
  const totalValue = items.reduce((a, i) => a + (i.current_stock * i.unit_price), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Consumables Tracking</h1>
        <p className="text-sm text-muted-foreground">Dialysis consumables inventory & per-session usage</p>
      </div>

      {lowStock.length > 0 && (
        <Card className="border-orange-300 bg-orange-50 dark:bg-orange-950/20">
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-orange-600" />
              <span className="font-semibold text-sm text-orange-800 dark:text-orange-400">Low Stock Alerts</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {lowStock.map(i => (
                <Badge key={i.id} variant="outline" className="border-orange-400 text-orange-700 dark:text-orange-300 text-xs">
                  {i.name}: {i.current_stock} left (reorder at {i.reorder_level})
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <Package className="w-5 h-5 text-primary" />
          <div><p className="text-2xl font-bold">{items.length}</p><p className="text-xs text-muted-foreground">Item Types</p></div>
        </CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-orange-600" />
          <div><p className="text-2xl font-bold text-orange-600">{lowStock.length}</p><p className="text-xs text-muted-foreground">Low Stock</p></div>
        </CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <TrendingDown className="w-5 h-5 text-blue-600" />
          <div><p className="text-2xl font-bold">₹{(totalValue / 1000).toFixed(0)}K</p><p className="text-xs text-muted-foreground">Inventory Value</p></div>
        </CardContent></Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search consumables..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <Card>
        <CardHeader className="py-3"><CardTitle className="text-sm">Current Inventory</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Stock</TableHead>
                <TableHead>Stock Level</TableHead>
                <TableHead>Unit Cost</TableHead>
                <TableHead>Manufacturer</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(item => {
                const pct = Math.min((item.current_stock / (item.reorder_level * 3)) * 100, 100);
                const isLow = item.current_stock <= item.reorder_level;
                return (
                  <TableRow key={item.id} className={isLow ? 'bg-orange-50/50 dark:bg-orange-950/10' : ''}>
                    <TableCell className="font-medium text-sm">{item.name}</TableCell>
                    <TableCell><Badge variant="outline" className="text-[10px]">{item.category}</Badge></TableCell>
                    <TableCell className={`font-mono ${isLow ? 'text-orange-600 font-bold' : ''}`}>{item.current_stock} {item.unit}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={pct} className="h-1.5 w-16" />
                        {isLow && <AlertTriangle className="w-3 h-3 text-orange-500" />}
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm">₹{item.unit_price}</TableCell>
                    <TableCell className="text-sm">{item.manufacturer || '—'}</TableCell>
                  </TableRow>
                );
              })}
              {filtered.length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No items found</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
