import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Activity, Clock, Plus, AlertTriangle, CheckCircle,
  Droplets, Pill, FileText, Heart
} from "lucide-react";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function DialysisSession() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [activeTab, setActiveTab] = useState("flowchart");
  const [sessions, setSessions] = useState<any[]>([]);
  const [activeSession, setActiveSession] = useState<any>(null);

  useEffect(() => {
    if (!orgId) return;
    const today = new Date().toISOString().split('T')[0];
    supabase.from('dialysis_sessions').select('*').eq('org_id', orgId).eq('session_date', today)
      .in('status', ['in_progress', 'scheduled'])
      .order('start_time')
      .then(({ data }) => {
        setSessions(data || []);
        if (data && data.length > 0) {
          setActiveSession(data.find((s: any) => s.status === 'in_progress') || data[0]);
        }
      });
  }, [orgId]);

  const preVitals = activeSession?.pre_vitals as Record<string, any> || {};
  const postVitals = activeSession?.post_vitals as Record<string, any> || {};

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dialysis Session — Flow Chart</h1>
          <p className="text-sm text-muted-foreground">
            {activeSession ? `Session ${activeSession.id.slice(0,8)} · Real-time monitoring` : 'No active session today'}
          </p>
        </div>
        <div className="flex gap-2">
          {activeSession?.status === 'in_progress' && (
            <Badge variant="default" className="text-xs py-1">● LIVE SESSION</Badge>
          )}
          <Button variant="outline" size="sm"><FileText className="w-4 h-4 mr-2" /> Generate PDF</Button>
        </div>
      </div>

      {activeSession ? (
        <>
          {/* Patient & Session Info */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="py-3"><CardTitle className="text-sm">Patient Information</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-y-2 text-sm">
                  <div><span className="text-muted-foreground">Name:</span> <strong>{activeSession.patient_name}</strong></div>
                  <div><span className="text-muted-foreground">Technician:</span> {activeSession.technician || '—'}</div>
                  <div><span className="text-muted-foreground">Dialyzer:</span> {activeSession.dialyzer_type || '—'}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="py-3"><CardTitle className="text-sm">Dialysis Parameters</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-y-2 text-sm">
                  <div><span className="text-muted-foreground">Duration:</span> {activeSession.duration_minutes || 240} min</div>
                  <div><span className="text-muted-foreground">Pre Weight:</span> {activeSession.pre_weight || '—'} kg</div>
                  <div><span className="text-muted-foreground">Post Weight:</span> {activeSession.post_weight || '—'} kg</div>
                  <div><span className="text-muted-foreground">UF Goal:</span> {activeSession.uf_goal || '—'} ml</div>
                  <div><span className="text-muted-foreground">BFR:</span> {activeSession.blood_flow_rate || '—'} ml/min</div>
                  <div><span className="text-muted-foreground">DFR:</span> {activeSession.dialysate_flow_rate || '—'} ml/min</div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="flowchart"><Activity className="w-3.5 h-3.5 mr-1.5" />Flow Chart</TabsTrigger>
              <TabsTrigger value="complications"><AlertTriangle className="w-3.5 h-3.5 mr-1.5" />Complications</TabsTrigger>
              <TabsTrigger value="summary"><CheckCircle className="w-3.5 h-3.5 mr-1.5" />Summary</TabsTrigger>
            </TabsList>

            <TabsContent value="flowchart" className="space-y-4">
              <Card>
                <CardHeader className="py-3"><CardTitle className="text-sm">Record New Reading</CardTitle></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-6 gap-3">
                    <div><Label className="text-xs">Time</Label><Input type="time" className="mt-1" /></div>
                    <div><Label className="text-xs">BP (Sys/Dia)</Label><Input placeholder="120/80" className="mt-1" /></div>
                    <div><Label className="text-xs">Pulse</Label><Input type="number" placeholder="72" className="mt-1" /></div>
                    <div><Label className="text-xs">UF Rate (ml/hr)</Label><Input type="number" placeholder="500" className="mt-1" /></div>
                    <div><Label className="text-xs">Blood Flow Rate</Label><Input type="number" placeholder="300" className="mt-1" /></div>
                    <div className="flex items-end"><Button className="w-full">Save</Button></div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="complications">
              <Card>
                <CardHeader className="py-3 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm">Complications Log</CardTitle>
                  <Button size="sm" variant="outline"><Plus className="w-3.5 h-3.5 mr-1.5" /> Log Complication</Button>
                </CardHeader>
                <CardContent>
                  {activeSession.complications ? (
                    <div className="p-4 rounded-lg border border-orange-300 bg-orange-50 dark:bg-orange-950/20">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="w-4 h-4 text-orange-600" />
                        <span className="font-semibold text-sm">Complication</span>
                      </div>
                      <p className="text-sm">{activeSession.complications}</p>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-8">No complications recorded</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="summary">
              <Card>
                <CardHeader className="py-3"><CardTitle className="text-sm">Session Treatment Summary</CardTitle></CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-y-3 text-sm">
                        <div className="text-muted-foreground">Duration</div><div className="font-medium">{activeSession.duration_minutes || 240} min</div>
                        <div className="text-muted-foreground">Pre Weight → Post Weight</div><div className="font-medium">{activeSession.pre_weight || '—'} → {activeSession.post_weight || '—'} kg</div>
                        <div className="text-muted-foreground">UF Goal</div><div className="font-medium">{activeSession.uf_goal || '—'} ml</div>
                        <div className="text-muted-foreground">Complications</div><div className="font-medium">{activeSession.complications || 'None'}</div>
                        <div className="text-muted-foreground">Status</div><div className="font-medium">{activeSession.status}</div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <Label className="text-xs">Notes</Label>
                        <Textarea className="mt-1" placeholder="Session notes..." defaultValue={activeSession.notes || ''} />
                      </div>
                      <Button className="w-full" onClick={async () => {
                        await supabase.from('dialysis_sessions').update({ status: 'completed' }).eq('id', activeSession.id);
                        toast.success("Session completed");
                      }}><CheckCircle className="w-4 h-4 mr-2" /> Complete Session</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">No active dialysis sessions today</p>
        </Card>
      )}

      {/* Other sessions today */}
      {sessions.length > 1 && (
        <div>
          <h3 className="text-sm font-semibold mb-2">Other Sessions Today</h3>
          <div className="grid md:grid-cols-3 gap-3">
            {sessions.filter(s => s.id !== activeSession?.id).map(s => (
              <Card key={s.id} className="p-3 cursor-pointer hover:shadow-sm" onClick={() => setActiveSession(s)}>
                <p className="text-sm font-medium">{s.patient_name}</p>
                <p className="text-xs text-muted-foreground">{s.start_time || '—'} · {s.technician || 'Unassigned'}</p>
                <Badge variant={s.status === 'in_progress' ? 'default' : 'secondary'} className="text-[9px] mt-1">{s.status}</Badge>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
