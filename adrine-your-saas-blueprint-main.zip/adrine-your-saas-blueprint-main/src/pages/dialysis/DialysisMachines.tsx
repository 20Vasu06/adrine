import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Cpu, Plus } from "lucide-react";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function DialysisMachines() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [machines, setMachines] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ machine_no: '', machine_name: '', manufacturer: '', model: '' });

  useEffect(() => {
    if (!orgId) return;
    supabase.from('dialysis_machines').select('*').eq('org_id', orgId).order('machine_no').then(({ data }) => setMachines(data || []));
  }, [orgId]);

  const handleAdd = async () => {
    if (!orgId || !form.machine_no || !form.machine_name) return;
    const { error } = await supabase.from('dialysis_machines').insert({
      org_id: orgId, machine_no: form.machine_no, machine_name: form.machine_name,
      manufacturer: form.manufacturer || null, model: form.model || null,
    });
    if (!error) {
      toast.success("Machine registered");
      setShowAdd(false);
      setForm({ machine_no: '', machine_name: '', manufacturer: '', model: '' });
      supabase.from('dialysis_machines').select('*').eq('org_id', orgId).order('machine_no').then(({ data }) => setMachines(data || []));
    } else toast.error(error.message);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Machine Management</h1>
          <p className="text-sm text-muted-foreground">{machines.length} machines registered</p>
        </div>
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-2" /> Add Machine</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Register New Machine</DialogTitle></DialogHeader>
            <div className="grid gap-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Machine ID</Label><Input placeholder="HD-07" className="mt-1" value={form.machine_no} onChange={e => setForm(f => ({ ...f, machine_no: e.target.value }))} /></div>
                <div><Label>Name</Label><Input placeholder="Machine name" className="mt-1" value={form.machine_name} onChange={e => setForm(f => ({ ...f, machine_name: e.target.value }))} /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Manufacturer</Label><Input placeholder="e.g. Fresenius" className="mt-1" value={form.manufacturer} onChange={e => setForm(f => ({ ...f, manufacturer: e.target.value }))} /></div>
                <div><Label>Model</Label><Input placeholder="e.g. 5008S" className="mt-1" value={form.model} onChange={e => setForm(f => ({ ...f, model: e.target.value }))} /></div>
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
              <Button onClick={handleAdd}>Register</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {machines.length > 0 ? machines.map(m => (
          <Card key={m.id} className={m.status === 'maintenance' ? 'border-destructive/30' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-muted-foreground" />
                  <span className="font-bold text-lg">{m.machine_no}</span>
                </div>
                <Badge variant={m.status === 'available' ? 'secondary' : m.status === 'maintenance' ? 'destructive' : 'default'} className="text-xs">{m.status}</Badge>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Name</span><span>{m.machine_name}</span></div>
                {m.manufacturer && <div className="flex justify-between"><span className="text-muted-foreground">Manufacturer</span><span>{m.manufacturer}</span></div>}
                {m.model && <div className="flex justify-between"><span className="text-muted-foreground">Model</span><span>{m.model}</span></div>}
                {m.last_maintenance && <div className="flex justify-between"><span className="text-muted-foreground">Last PM</span><span className="text-xs">{m.last_maintenance}</span></div>}
                {m.next_maintenance && <div className="flex justify-between"><span className="text-muted-foreground">Next PM</span>
                  <span className={`text-xs ${new Date(m.next_maintenance) < new Date() ? 'text-destructive font-bold' : ''}`}>
                    {m.next_maintenance}{new Date(m.next_maintenance) < new Date() ? ' ⚠ OVERDUE' : ''}
                  </span>
                </div>}
              </div>
            </CardContent>
          </Card>
        )) : (
          <p className="text-sm text-muted-foreground col-span-3 text-center py-8">No machines registered</p>
        )}
      </div>
    </div>
  );
}
