import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Plus, User, Droplets, TrendingUp } from "lucide-react";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function DialysisPatients() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [search, setSearch] = useState("");
  const [patients, setPatients] = useState<any[]>([]);
  const [sessionCounts, setSessionCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    if (!orgId) return;
    // Get patients who have had dialysis sessions
    supabase.from('dialysis_sessions').select('patient_id, patient_name').eq('org_id', orgId).then(({ data }) => {
      const map = new Map<string, { name: string; count: number }>();
      (data || []).forEach((s: any) => {
        const existing = map.get(s.patient_id) || { name: s.patient_name, count: 0 };
        existing.count += 1;
        map.set(s.patient_id, existing);
      });
      const patientList = Array.from(map.entries()).map(([id, info]) => ({ id, name: info.name, sessions: info.count }));
      setPatients(patientList);
      const counts: Record<string, number> = {};
      map.forEach((v, k) => { counts[k] = v.count; });
      setSessionCounts(counts);
    });
  }, [orgId]);

  const filtered = patients.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const totalSessions = Object.values(sessionCounts).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dialysis Patients</h1>
          <p className="text-sm text-muted-foreground">Chronic dialysis patient registry</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <User className="w-5 h-5 text-primary" />
          <div><p className="text-2xl font-bold">{patients.length}</p><p className="text-xs text-muted-foreground">Active Patients</p></div>
        </CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <Droplets className="w-5 h-5 text-info" />
          <div><p className="text-2xl font-bold">{totalSessions}</p><p className="text-xs text-muted-foreground">Total Sessions</p></div>
        </CardContent></Card>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search by name..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Patient</TableHead>
                <TableHead>Sessions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length > 0 ? filtered.map(p => (
                <TableRow key={p.id} className="cursor-pointer hover:bg-muted/50">
                  <TableCell className="font-medium text-sm">{p.name}</TableCell>
                  <TableCell className="font-mono text-sm">{p.sessions}</TableCell>
                </TableRow>
              )) : (
                <TableRow><TableCell colSpan={2} className="text-center text-muted-foreground py-8">No dialysis patients found</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
