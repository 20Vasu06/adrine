import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreditCard, Package, TrendingUp, Plus, FileText, IndianRupee } from "lucide-react";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export default function DialysisBilling() {
  const { user } = useAuth();
  const orgId = user?.orgId;
  const [showInvoice, setShowInvoice] = useState(false);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      supabase.from('invoices').select('*').eq('org_id', orgId).eq('category', 'OPD').order('date', { ascending: false }).limit(50),
      supabase.from('patients').select('id, name, uhid').eq('org_id', orgId),
    ]).then(([invRes, patRes]) => {
      setInvoices(invRes.data || []);
      setPatients(patRes.data || []);
    });
  }, [orgId]);

  const totalRevenue = invoices.reduce((sum, i) => sum + (i.total || 0), 0);
  const paidCount = invoices.filter(i => i.status === 'paid').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dialysis Billing & Packages</h1>
          <p className="text-sm text-muted-foreground">Session billing, package management & revenue tracking</p>
        </div>
        <Dialog open={showInvoice} onOpenChange={setShowInvoice}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="w-4 h-4 mr-2" /> New Invoice</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Generate Dialysis Invoice</DialogTitle></DialogHeader>
            <div className="grid gap-4 mt-4">
              <div><Label>Patient</Label>
                <Select><SelectTrigger className="mt-1"><SelectValue placeholder="Select patient" /></SelectTrigger>
                  <SelectContent>{patients.map(p => <SelectItem key={p.id} value={p.id}>{p.name} ({p.uhid})</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Session Date</Label><Input type="date" className="mt-1" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Session Charge</Label><Input defaultValue="2500" className="mt-1" /></div>
                <div><Label>Consumables</Label><Input defaultValue="850" className="mt-1" /></div>
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setShowInvoice(false)}>Cancel</Button>
              <Button onClick={() => { setShowInvoice(false); toast.success("Invoice generated successfully"); }}>Generate Invoice</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Revenue Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <IndianRupee className="w-5 h-5 text-primary" />
          <div><p className="text-2xl font-bold">₹{(totalRevenue / 100000).toFixed(1)}L</p><p className="text-xs text-muted-foreground">Total Revenue</p></div>
        </CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <FileText className="w-5 h-5 text-blue-600" />
          <div><p className="text-2xl font-bold">{invoices.length}</p><p className="text-xs text-muted-foreground">Total Invoices</p></div>
        </CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <Package className="w-5 h-5 text-green-600" />
          <div><p className="text-2xl font-bold">{paidCount}</p><p className="text-xs text-muted-foreground">Paid</p></div>
        </CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3">
          <TrendingUp className="w-5 h-5 text-orange-600" />
          <div><p className="text-2xl font-bold">₹{invoices.length > 0 ? Math.round(totalRevenue / invoices.length).toLocaleString() : 0}</p><p className="text-xs text-muted-foreground">Avg/Invoice</p></div>
        </CardContent></Card>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice #</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Paid</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map(inv => (
                <TableRow key={inv.id}>
                  <TableCell className="font-mono text-xs">{inv.invoice_no}</TableCell>
                  <TableCell className="font-medium text-sm">{inv.patient_name}</TableCell>
                  <TableCell className="text-xs">{inv.date}</TableCell>
                  <TableCell className="font-mono font-bold text-sm">₹{inv.total?.toLocaleString()}</TableCell>
                  <TableCell className="font-mono text-sm">₹{inv.paid?.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant={inv.status === 'paid' ? 'default' : inv.status === 'pending' ? 'secondary' : 'destructive'} className="text-[10px]">
                      {inv.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
              {invoices.length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No invoices found</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
