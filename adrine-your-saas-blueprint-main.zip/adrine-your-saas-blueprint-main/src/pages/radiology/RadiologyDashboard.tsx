import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScanLine, Clock, CheckCircle, Monitor } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const statusColor: Record<string, string> = {
  Ordered: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  Scheduled: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "In Progress": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  Completed: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  Reported: "bg-muted text-muted-foreground",
};

export default function RadiologyDashboard() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(() => {
    if (!user?.orgId) return;
    supabase.from('radiology_orders').select('*').eq('org_id', user.orgId).order('order_time', { ascending: false })
      .then(({ data }) => setOrders(data || []));
  }, [user?.orgId]);

  const pending = orders.filter(o => o.status === 'Ordered' || o.status === 'Scheduled').length;
  const inProgress = orders.filter(o => o.status === 'In Progress').length;
  const completed = orders.filter(o => o.status === 'Completed' || o.status === 'Reported').length;

  const stats = [
    { label: "Pending Orders", value: String(pending), icon: Clock, trend: "Awaiting imaging" },
    { label: "In Progress", value: String(inProgress), icon: ScanLine, trend: "Currently imaging" },
    { label: "Completed Today", value: String(completed), icon: CheckCircle, trend: "Done" },
    { label: "Total Orders", value: String(orders.length), icon: Monitor, trend: "All orders" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Radiology Dashboard</h1>
        <p className="text-muted-foreground text-sm">Imaging operations overview and workflow tracking</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map(s => (
          <Card key={s.label}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                  <p className="text-3xl font-bold text-foreground mt-1">{s.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{s.trend}</p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <s.icon className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-lg">Recent Imaging Orders</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Study</TableHead>
                <TableHead>Modality</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No radiology orders yet.</TableCell></TableRow>
              ) : orders.slice(0, 10).map(o => (
                <TableRow key={o.id}>
                  <TableCell className="font-mono text-sm">{o.order_no}</TableCell>
                  <TableCell className="font-medium">{o.patient_name}</TableCell>
                  <TableCell>{o.study}</TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{o.modality}</Badge></TableCell>
                  <TableCell>
                    <Badge variant={o.priority === "Emergency" ? "destructive" : o.priority === "Urgent" ? "default" : "secondary"} className="text-xs">{o.priority}</Badge>
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor[o.status] || ''}`}>{o.status}</span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
