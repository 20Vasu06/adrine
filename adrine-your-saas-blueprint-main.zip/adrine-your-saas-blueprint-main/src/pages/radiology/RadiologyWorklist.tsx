import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, CheckCircle, Clock, ScanLine } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const statusColor: Record<string, string> = {
  Ordered: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  Scheduled: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  "In Progress": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  Completed: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  Reported: "bg-muted text-muted-foreground",
};

export default function RadiologyWorklist() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [modalityFilter, setModalityFilter] = useState("All");
  const [tab, setTab] = useState("active");

  useEffect(() => {
    if (!user?.orgId) return;
    supabase.from('radiology_orders').select('*').eq('org_id', user.orgId).order('order_time', { ascending: false })
      .then(({ data }) => setOrders(data || []));
  }, [user?.orgId]);

  const modalities = ["All", ...new Set(orders.map(o => o.modality))];

  const filtered = orders.filter(w => {
    const matchSearch = w.patient_name.toLowerCase().includes(search.toLowerCase()) || w.order_no.toLowerCase().includes(search.toLowerCase());
    const matchModality = modalityFilter === "All" || w.modality === modalityFilter;
    const matchTab = tab === "active" ? (w.status !== "Completed" && w.status !== "Reported") : (w.status === "Completed" || w.status === "Reported");
    return matchSearch && matchModality && matchTab;
  });

  const waiting = orders.filter(w => w.status === "Ordered" || w.status === "Scheduled").length;
  const inProgress = orders.filter(w => w.status === "In Progress").length;
  const completed = orders.filter(w => w.status === "Completed" || w.status === "Reported").length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Radiology Worklist</h1>
        <p className="text-muted-foreground text-sm">Track scheduled imaging procedures</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card><CardContent className="pt-6 flex items-center gap-3"><Clock className="h-8 w-8 text-yellow-600" /><div><p className="text-2xl font-bold">{waiting}</p><p className="text-xs text-muted-foreground">Waiting</p></div></CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3"><ScanLine className="h-8 w-8 text-purple-600" /><div><p className="text-2xl font-bold">{inProgress}</p><p className="text-xs text-muted-foreground">In Progress</p></div></CardContent></Card>
        <Card><CardContent className="pt-6 flex items-center gap-3"><CheckCircle className="h-8 w-8 text-green-600" /><div><p className="text-2xl font-bold">{completed}</p><p className="text-xs text-muted-foreground">Completed</p></div></CardContent></Card>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search patient or order ID..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={modalityFilter} onValueChange={setModalityFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>{modalities.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Study</TableHead>
                <TableHead>Modality</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No radiology orders found</TableCell></TableRow>
              ) : filtered.map(w => (
                <TableRow key={w.id}>
                  <TableCell className="font-mono text-sm">{w.order_no}</TableCell>
                  <TableCell className="font-medium">{w.patient_name}</TableCell>
                  <TableCell>{w.study}</TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{w.modality}</Badge></TableCell>
                  <TableCell>
                    <Badge variant={w.priority === "Emergency" ? "destructive" : w.priority === "Urgent" ? "default" : "secondary"} className="text-xs">{w.priority}</Badge>
                  </TableCell>
                  <TableCell><span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor[w.status] || ''}`}>{w.status}</span></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
