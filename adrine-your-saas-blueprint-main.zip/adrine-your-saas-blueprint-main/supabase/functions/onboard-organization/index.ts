import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { orgName, orgSlug, orgType, fullName, email, password, modules } =
      await req.json();

    if (!orgName || !orgSlug || !orgType || !fullName || !email || !password) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // 1. Create organization
    const { data: org, error: orgError } = await supabaseAdmin
      .from("organizations")
      .insert({
        name: orgName,
        slug: orgSlug,
        org_type: orgType,
      })
      .select()
      .single();

    if (orgError) {
      return new Response(
        JSON.stringify({ error: `Org creation failed: ${orgError.message}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 2. Create default branch
    const { data: branch } = await supabaseAdmin
      .from("branches")
      .insert({
        org_id: org.id,
        name: "Main Branch",
        code: "MAIN",
        is_active: true,
      })
      .select()
      .single();

    // 3. Create auth user
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        full_name: fullName,
        org_id: org.id,
      },
    });

    if (authError) {
      // Cleanup org if user creation fails
      await supabaseAdmin.from("organizations").delete().eq("id", org.id);
      return new Response(
        JSON.stringify({ error: `User creation failed: ${authError.message}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const userId = authData.user.id;

    // 4. Update profile with branch
    if (branch) {
      await supabaseAdmin
        .from("profiles")
        .update({ branch_id: branch.id })
        .eq("user_id", userId);
    }

    // 5. Assign org_admin role
    await supabaseAdmin.from("user_roles").insert({
      user_id: userId,
      org_id: org.id,
      role: "org_admin",
    });

    // 6. Enable selected modules
    if (modules && modules.length > 0) {
      const moduleRows = modules.map((m: string) => ({
        org_id: org.id,
        module: m,
        is_enabled: true,
      }));
      await supabaseAdmin.from("org_modules").insert(moduleRows);
    }

    // 7. Create default departments based on org type
    const defaultDepts: { name: string; code: string }[] = [];
    if (orgType === "dialysis_center") {
      defaultDepts.push(
        { name: "Dialysis", code: "DLY" },
        { name: "General Medicine", code: "GM" }
      );
    } else {
      defaultDepts.push(
        { name: "General Medicine", code: "GM" },
        { name: "Cardiology", code: "CARD" },
        { name: "Orthopedics", code: "ORTH" },
        { name: "Pediatrics", code: "PED" },
        { name: "Gynecology", code: "GYN" },
        { name: "ENT", code: "ENT" },
        { name: "Dermatology", code: "DERM" },
        { name: "Emergency", code: "ER" }
      );
    }

    if (defaultDepts.length > 0) {
      await supabaseAdmin.from("departments").insert(
        defaultDepts.map((d) => ({
          org_id: org.id,
          branch_id: branch?.id,
          name: d.name,
          code: d.code,
        }))
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        orgId: org.id,
        userId,
        message: "Organization onboarded successfully",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
