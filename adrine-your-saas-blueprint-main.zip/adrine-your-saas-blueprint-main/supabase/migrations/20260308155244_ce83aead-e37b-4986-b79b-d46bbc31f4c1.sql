
-- =============================================
-- INVENTORY MODULE TABLES
-- =============================================

CREATE TABLE public.inventory_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'General',
  unit TEXT NOT NULL DEFAULT 'Nos',
  current_stock NUMERIC NOT NULL DEFAULT 0,
  reorder_level NUMERIC NOT NULL DEFAULT 10,
  unit_price NUMERIC NOT NULL DEFAULT 0,
  hsn_code TEXT,
  manufacturer TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.stock_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  item_id UUID NOT NULL REFERENCES public.inventory_items(id),
  entry_type TEXT NOT NULL DEFAULT 'in', -- in, out, adjustment
  quantity NUMERIC NOT NULL,
  batch_no TEXT,
  expiry_date DATE,
  supplier TEXT,
  invoice_no TEXT,
  unit_cost NUMERIC DEFAULT 0,
  notes TEXT,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.purchase_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  po_no TEXT NOT NULL,
  supplier TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft', -- draft, approved, ordered, received, cancelled
  items JSONB NOT NULL DEFAULT '[]',
  total NUMERIC NOT NULL DEFAULT 0,
  order_date DATE NOT NULL DEFAULT CURRENT_DATE,
  expected_date DATE,
  received_date DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.requisitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  req_no TEXT NOT NULL,
  from_department TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, approved, fulfilled, rejected
  items JSONB NOT NULL DEFAULT '[]',
  priority TEXT NOT NULL DEFAULT 'normal',
  requested_by TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.equipment (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  name TEXT NOT NULL,
  asset_code TEXT NOT NULL,
  department TEXT,
  location TEXT,
  status TEXT NOT NULL DEFAULT 'operational', -- operational, maintenance, out_of_order
  last_maintenance DATE,
  next_maintenance DATE,
  vendor TEXT,
  warranty_expiry DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- OT MODULE TABLES
-- =============================================

CREATE TABLE public.ot_rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  room_name TEXT NOT NULL,
  room_type TEXT NOT NULL DEFAULT 'General', -- General, Cardiac, Neuro, Ortho, etc.
  status TEXT NOT NULL DEFAULT 'available', -- available, in_use, maintenance, cleaning
  equipment JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.ot_surgeries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  patient_id UUID NOT NULL REFERENCES public.patients(id),
  patient_name TEXT NOT NULL,
  room_id UUID REFERENCES public.ot_rooms(id),
  surgery_type TEXT NOT NULL,
  scheduled_date DATE NOT NULL,
  scheduled_time TIME NOT NULL,
  duration_minutes INTEGER DEFAULT 60,
  surgeon TEXT NOT NULL,
  anesthesiologist TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled', -- scheduled, preop, in_progress, postop, completed, cancelled
  preop_checklist JSONB DEFAULT '{}',
  intraop_notes JSONB DEFAULT '{}',
  postop_notes JSONB DEFAULT '{}',
  team JSONB DEFAULT '[]',
  diagnosis TEXT,
  priority TEXT NOT NULL DEFAULT 'elective', -- emergency, urgent, elective
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- NURSING MODULE TABLES
-- =============================================

CREATE TABLE public.nursing_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  patient_id UUID NOT NULL REFERENCES public.patients(id),
  patient_name TEXT NOT NULL,
  ward TEXT,
  bed_no TEXT,
  task_type TEXT NOT NULL, -- medication, vitals, wound_care, iv_fluids, monitoring, etc.
  description TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'normal', -- low, normal, high, urgent
  status TEXT NOT NULL DEFAULT 'pending', -- pending, in_progress, completed, skipped
  due_at TIMESTAMPTZ NOT NULL,
  completed_at TIMESTAMPTZ,
  assigned_to TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.vital_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  patient_id UUID NOT NULL REFERENCES public.patients(id),
  patient_name TEXT NOT NULL,
  temperature NUMERIC,
  pulse INTEGER,
  bp_systolic INTEGER,
  bp_diastolic INTEGER,
  spo2 NUMERIC,
  respiratory_rate INTEGER,
  blood_sugar NUMERIC,
  weight NUMERIC,
  height NUMERIC,
  pain_score INTEGER,
  notes TEXT,
  recorded_by TEXT,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- EMERGENCY MODULE TABLES
-- =============================================

CREATE TABLE public.emergency_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  patient_id UUID REFERENCES public.patients(id),
  patient_name TEXT NOT NULL,
  case_no TEXT NOT NULL,
  arrival_mode TEXT NOT NULL DEFAULT 'walk_in', -- walk_in, ambulance, referred, police
  triage_level TEXT NOT NULL DEFAULT 'green', -- red, orange, yellow, green, black
  chief_complaint TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'triaged', -- triaged, treating, observation, admitted, discharged, referred, doa
  is_mlc BOOLEAN DEFAULT false,
  mlc_details JSONB DEFAULT '{}',
  vitals JSONB DEFAULT '{}',
  treatment_notes TEXT,
  attending_doctor TEXT,
  arrival_time TIMESTAMPTZ NOT NULL DEFAULT now(),
  discharge_time TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- HR MODULE TABLES
-- =============================================

CREATE TABLE public.staff_attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  user_id UUID NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  check_in TIMESTAMPTZ,
  check_out TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'present', -- present, absent, late, half_day, on_leave
  shift TEXT DEFAULT 'general',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.leave_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  user_id UUID NOT NULL,
  employee_name TEXT NOT NULL,
  leave_type TEXT NOT NULL DEFAULT 'casual', -- casual, sick, earned, maternity, compensatory
  from_date DATE NOT NULL,
  to_date DATE NOT NULL,
  days NUMERIC NOT NULL DEFAULT 1,
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, approved, rejected, cancelled
  approved_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- SCHEDULING MODULE TABLES
-- =============================================

CREATE TABLE public.doctor_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  doctor_name TEXT NOT NULL,
  doctor_user_id UUID,
  department TEXT NOT NULL,
  day_of_week INTEGER NOT NULL, -- 0=Sun, 6=Sat
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  slot_duration INTEGER NOT NULL DEFAULT 15,
  max_patients INTEGER DEFAULT 20,
  is_active BOOLEAN DEFAULT true,
  room TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- DIALYSIS MODULE TABLES
-- =============================================

CREATE TABLE public.dialysis_machines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  machine_name TEXT NOT NULL,
  machine_no TEXT NOT NULL,
  model TEXT,
  manufacturer TEXT,
  status TEXT NOT NULL DEFAULT 'available', -- available, in_use, maintenance, out_of_order
  last_maintenance DATE,
  next_maintenance DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.dialysis_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  patient_id UUID NOT NULL REFERENCES public.patients(id),
  patient_name TEXT NOT NULL,
  machine_id UUID REFERENCES public.dialysis_machines(id),
  session_date DATE NOT NULL DEFAULT CURRENT_DATE,
  start_time TIME,
  end_time TIME,
  duration_minutes INTEGER DEFAULT 240,
  dialyzer_type TEXT,
  blood_flow_rate NUMERIC,
  dialysate_flow_rate NUMERIC,
  pre_weight NUMERIC,
  post_weight NUMERIC,
  uf_goal NUMERIC,
  pre_vitals JSONB DEFAULT '{}',
  post_vitals JSONB DEFAULT '{}',
  complications TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled', -- scheduled, in_progress, completed, cancelled
  technician TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- PHARMACY STOCK TABLE
-- =============================================

CREATE TABLE public.pharmacy_stock (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  branch_id UUID REFERENCES public.branches(id),
  drug_name TEXT NOT NULL,
  generic_name TEXT,
  drug_code TEXT,
  category TEXT NOT NULL DEFAULT 'General',
  formulation TEXT, -- tablet, capsule, syrup, injection, etc.
  manufacturer TEXT,
  batch_no TEXT,
  expiry_date DATE,
  current_stock INTEGER NOT NULL DEFAULT 0,
  reorder_level INTEGER NOT NULL DEFAULT 10,
  unit_price NUMERIC NOT NULL DEFAULT 0,
  mrp NUMERIC NOT NULL DEFAULT 0,
  schedule_type TEXT, -- H, H1, X, etc.
  rack_location TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.suppliers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id),
  name TEXT NOT NULL,
  contact_person TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  gst_no TEXT,
  drug_license_no TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- RLS POLICIES FOR ALL NEW TABLES
-- =============================================

ALTER TABLE public.inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.requisitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.equipment ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ot_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ot_surgeries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nursing_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vital_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.emergency_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.doctor_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dialysis_machines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dialysis_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pharmacy_stock ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

-- Org-scoped SELECT policies
CREATE POLICY "Org members can view inventory_items" ON public.inventory_items FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view stock_entries" ON public.stock_entries FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view purchase_orders" ON public.purchase_orders FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view requisitions" ON public.requisitions FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view equipment" ON public.equipment FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view ot_rooms" ON public.ot_rooms FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view ot_surgeries" ON public.ot_surgeries FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view nursing_tasks" ON public.nursing_tasks FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view vital_records" ON public.vital_records FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view emergency_cases" ON public.emergency_cases FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view staff_attendance" ON public.staff_attendance FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view leave_requests" ON public.leave_requests FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view doctor_schedules" ON public.doctor_schedules FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view dialysis_machines" ON public.dialysis_machines FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view dialysis_sessions" ON public.dialysis_sessions FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view pharmacy_stock" ON public.pharmacy_stock FOR SELECT USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can view suppliers" ON public.suppliers FOR SELECT USING (org_id = get_user_org_id(auth.uid()));

-- Org-scoped INSERT policies
CREATE POLICY "Org members can insert inventory_items" ON public.inventory_items FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert stock_entries" ON public.stock_entries FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert purchase_orders" ON public.purchase_orders FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert requisitions" ON public.requisitions FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert equipment" ON public.equipment FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert ot_rooms" ON public.ot_rooms FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert ot_surgeries" ON public.ot_surgeries FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert nursing_tasks" ON public.nursing_tasks FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert vital_records" ON public.vital_records FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert emergency_cases" ON public.emergency_cases FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert staff_attendance" ON public.staff_attendance FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert leave_requests" ON public.leave_requests FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert doctor_schedules" ON public.doctor_schedules FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert dialysis_machines" ON public.dialysis_machines FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert dialysis_sessions" ON public.dialysis_sessions FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert pharmacy_stock" ON public.pharmacy_stock FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert suppliers" ON public.suppliers FOR INSERT WITH CHECK (org_id = get_user_org_id(auth.uid()));

-- Org-scoped UPDATE policies
CREATE POLICY "Org members can update inventory_items" ON public.inventory_items FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update stock_entries" ON public.stock_entries FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update purchase_orders" ON public.purchase_orders FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update requisitions" ON public.requisitions FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update equipment" ON public.equipment FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update ot_rooms" ON public.ot_rooms FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update ot_surgeries" ON public.ot_surgeries FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update nursing_tasks" ON public.nursing_tasks FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update vital_records" ON public.vital_records FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update emergency_cases" ON public.emergency_cases FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update staff_attendance" ON public.staff_attendance FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update leave_requests" ON public.leave_requests FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update doctor_schedules" ON public.doctor_schedules FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update dialysis_machines" ON public.dialysis_machines FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update dialysis_sessions" ON public.dialysis_sessions FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update pharmacy_stock" ON public.pharmacy_stock FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update suppliers" ON public.suppliers FOR UPDATE USING (org_id = get_user_org_id(auth.uid()));

-- Enable realtime on key clinical tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.queue_entries;
ALTER PUBLICATION supabase_realtime ADD TABLE public.appointments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.lab_orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.prescriptions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.radiology_orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.admissions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.beds;
ALTER PUBLICATION supabase_realtime ADD TABLE public.nursing_tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE public.emergency_cases;
ALTER PUBLICATION supabase_realtime ADD TABLE public.ot_surgeries;
ALTER PUBLICATION supabase_realtime ADD TABLE public.dialysis_sessions;
