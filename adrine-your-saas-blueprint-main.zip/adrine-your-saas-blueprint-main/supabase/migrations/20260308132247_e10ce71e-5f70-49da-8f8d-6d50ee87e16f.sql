
-- ============================================
-- ADRINE MULTI-TENANT HOSPITAL SAAS SCHEMA
-- Part 2: Clinical Data Tables
-- ============================================

-- Patient category enum
CREATE TYPE public.patient_category AS ENUM ('general', 'corporate', 'insurance', 'government', 'vip');
CREATE TYPE public.patient_type AS ENUM ('OPD', 'IPD', 'Emergency');
CREATE TYPE public.appointment_status AS ENUM ('scheduled', 'confirmed', 'checked-in', 'in-consultation', 'completed', 'cancelled', 'no-show');
CREATE TYPE public.appointment_type AS ENUM ('new', 'follow-up', 'teleconsultation');
CREATE TYPE public.queue_status AS ENUM ('waiting', 'called', 'in-consultation', 'completed', 'skipped');
CREATE TYPE public.priority_level AS ENUM ('Routine', 'Urgent', 'Emergency');
CREATE TYPE public.lab_stage AS ENUM ('Pending Analysis', 'In Analysis', 'Awaiting Validation', 'Validated', 'Reported');
CREATE TYPE public.sample_status AS ENUM ('Ordered', 'Collected', 'Received', 'Processing', 'Analysis Complete');
CREATE TYPE public.rx_status AS ENUM ('Pending', 'Verified', 'Dispensed', 'Partially dispensed', 'Cancelled');
CREATE TYPE public.radiology_status AS ENUM ('Ordered', 'Scheduled', 'In Progress', 'Completed', 'Reported');
CREATE TYPE public.invoice_category AS ENUM ('OPD', 'IPD', 'Emergency', 'Lab', 'Pharmacy', 'Radiology');
CREATE TYPE public.invoice_status AS ENUM ('paid', 'partial', 'pending', 'overdue');

-- ============================================
-- 7. Patients
-- ============================================
CREATE TABLE public.patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  uhid TEXT NOT NULL,
  name TEXT NOT NULL,
  age INTEGER NOT NULL,
  gender TEXT NOT NULL,
  phone TEXT NOT NULL,
  blood_group TEXT,
  abha_id TEXT,
  aadhaar TEXT,
  category public.patient_category NOT NULL DEFAULT 'general',
  patient_type public.patient_type NOT NULL DEFAULT 'OPD',
  department TEXT,
  assigned_doctor TEXT,
  allergies TEXT,
  chronic_diseases TEXT,
  insurance_provider TEXT,
  policy_no TEXT,
  is_mlc BOOLEAN DEFAULT false,
  registered_on TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_visit TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(org_id, uhid)
);

-- ============================================
-- 8. Appointments
-- ============================================
CREATE TABLE public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  appointment_no TEXT NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  phone TEXT,
  doctor TEXT NOT NULL,
  department TEXT NOT NULL,
  date DATE NOT NULL,
  time TIME NOT NULL,
  duration INTEGER DEFAULT 30,
  status public.appointment_status NOT NULL DEFAULT 'scheduled',
  type public.appointment_type NOT NULL DEFAULT 'new',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(org_id, appointment_no)
);

-- ============================================
-- 9. Queue
-- ============================================
CREATE TABLE public.queue_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  token_no INTEGER NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  doctor TEXT NOT NULL,
  department TEXT NOT NULL,
  status public.queue_status NOT NULL DEFAULT 'waiting',
  appointment_id UUID REFERENCES public.appointments(id),
  checked_in_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  complaint TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================
-- 10. Lab Orders
-- ============================================
CREATE TABLE public.lab_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  order_no TEXT NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  tests TEXT NOT NULL,
  category TEXT NOT NULL,
  priority public.priority_level NOT NULL DEFAULT 'Routine',
  doctor TEXT NOT NULL,
  order_time TIMESTAMPTZ NOT NULL DEFAULT now(),
  stage public.lab_stage NOT NULL DEFAULT 'Pending Analysis',
  sample_status public.sample_status NOT NULL DEFAULT 'Ordered',
  results JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(org_id, order_no)
);

-- ============================================
-- 11. Prescriptions
-- ============================================
CREATE TABLE public.prescriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  rx_no TEXT NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  doctor TEXT NOT NULL,
  department TEXT NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  priority public.priority_level NOT NULL DEFAULT 'Routine',
  status public.rx_status NOT NULL DEFAULT 'Pending',
  medications JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(org_id, rx_no)
);

-- ============================================
-- 12. Radiology Orders
-- ============================================
CREATE TABLE public.radiology_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  order_no TEXT NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  study TEXT NOT NULL,
  modality TEXT NOT NULL,
  priority public.priority_level NOT NULL DEFAULT 'Routine',
  doctor TEXT NOT NULL,
  order_time TIMESTAMPTZ NOT NULL DEFAULT now(),
  status public.radiology_status NOT NULL DEFAULT 'Ordered',
  report JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(org_id, order_no)
);

-- ============================================
-- 13. Billing Invoices
-- ============================================
CREATE TABLE public.invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  invoice_no TEXT NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  category public.invoice_category NOT NULL DEFAULT 'OPD',
  items JSONB NOT NULL DEFAULT '[]',
  total NUMERIC(12,2) NOT NULL DEFAULT 0,
  paid NUMERIC(12,2) NOT NULL DEFAULT 0,
  status public.invoice_status NOT NULL DEFAULT 'pending',
  payment_mode TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(org_id, invoice_no)
);

-- ============================================
-- 14. Consultations (visit records)
-- ============================================
CREATE TABLE public.consultations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  doctor TEXT NOT NULL,
  department TEXT NOT NULL,
  date TIMESTAMPTZ NOT NULL DEFAULT now(),
  complaints TEXT,
  examination TEXT,
  diagnosis TEXT,
  vitals JSONB,
  notes TEXT,
  consultation_fee NUMERIC(10,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================
-- 15. Beds & Admissions (IPD)
-- ============================================
CREATE TABLE public.beds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  ward TEXT NOT NULL,
  bed_no TEXT NOT NULL,
  bed_type TEXT NOT NULL DEFAULT 'General',
  is_occupied BOOLEAN NOT NULL DEFAULT false,
  patient_id UUID REFERENCES public.patients(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(org_id, ward, bed_no)
);

CREATE TABLE public.admissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
  admission_no TEXT NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  doctor TEXT NOT NULL,
  department TEXT NOT NULL,
  bed_id UUID REFERENCES public.beds(id),
  admission_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  discharge_date TIMESTAMPTZ,
  diagnosis TEXT,
  status TEXT NOT NULL DEFAULT 'admitted',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(org_id, admission_no)
);

-- ============================================
-- RLS for all clinical tables
-- ============================================
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.queue_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lab_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.radiology_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.consultations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.beds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admissions ENABLE ROW LEVEL SECURITY;

-- All clinical tables: org-scoped read access
CREATE POLICY "Org members can view patients" ON public.patients FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert patients" ON public.patients FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update patients" ON public.patients FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view appointments" ON public.appointments FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert appointments" ON public.appointments FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update appointments" ON public.appointments FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view queue" ON public.queue_entries FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert queue" ON public.queue_entries FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update queue" ON public.queue_entries FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view lab orders" ON public.lab_orders FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert lab orders" ON public.lab_orders FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update lab orders" ON public.lab_orders FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view prescriptions" ON public.prescriptions FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert prescriptions" ON public.prescriptions FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update prescriptions" ON public.prescriptions FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view radiology orders" ON public.radiology_orders FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert radiology orders" ON public.radiology_orders FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update radiology orders" ON public.radiology_orders FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view invoices" ON public.invoices FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert invoices" ON public.invoices FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update invoices" ON public.invoices FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view consultations" ON public.consultations FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert consultations" ON public.consultations FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update consultations" ON public.consultations FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view beds" ON public.beds FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can manage beds" ON public.beds FOR ALL TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

CREATE POLICY "Org members can view admissions" ON public.admissions FOR SELECT TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can insert admissions" ON public.admissions FOR INSERT TO authenticated WITH CHECK (org_id = public.get_user_org_id(auth.uid()));
CREATE POLICY "Org members can update admissions" ON public.admissions FOR UPDATE TO authenticated USING (org_id = public.get_user_org_id(auth.uid()));

-- Updated_at triggers for clinical tables
CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_queue_entries_updated_at BEFORE UPDATE ON public.queue_entries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_lab_orders_updated_at BEFORE UPDATE ON public.lab_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_prescriptions_updated_at BEFORE UPDATE ON public.prescriptions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_radiology_orders_updated_at BEFORE UPDATE ON public.radiology_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_consultations_updated_at BEFORE UPDATE ON public.consultations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_beds_updated_at BEFORE UPDATE ON public.beds FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_admissions_updated_at BEFORE UPDATE ON public.admissions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Performance indexes
CREATE INDEX idx_patients_org ON public.patients(org_id);
CREATE INDEX idx_patients_uhid ON public.patients(org_id, uhid);
CREATE INDEX idx_appointments_org_date ON public.appointments(org_id, date);
CREATE INDEX idx_appointments_doctor ON public.appointments(org_id, doctor, date);
CREATE INDEX idx_queue_org_status ON public.queue_entries(org_id, status);
CREATE INDEX idx_lab_orders_org ON public.lab_orders(org_id, stage);
CREATE INDEX idx_prescriptions_org ON public.prescriptions(org_id, status);
CREATE INDEX idx_invoices_org ON public.invoices(org_id, status);
CREATE INDEX idx_consultations_patient ON public.consultations(patient_id);
CREATE INDEX idx_admissions_org ON public.admissions(org_id, status);
